# Build the APK with GitHub Actions

This project ships with a ready workflow: `.github/workflows/build-android-apk.yml`. It builds a standalone, installable APK
and publishes it as a downloadable **artifact** (and, for tags like `v1.0.0`, as a **GitHub Release** file).

## What went wrong before, and how it is fixed

| Error you saw | Real cause | Fix in this version |
|---|---|---|
| `ENOENT` / `Could not read package.json` | The workflow ran `npm`/`pnpm` at the repository root, but the app lives in `artifacts/kabir-ai/`, and the ZIP's own top folder added another level. | The workflow **finds** `pnpm-workspace.yaml` (up to 4 folders deep) and uses `<root>/artifacts/kabir-ai` from there, so it works wherever the files were uploaded. It stops with a clear message listing the folders if the project is truly missing. |
| Dependency install / node-cache failures ("missing lock files") | This project uses **pnpm**, with `pnpm-lock.yaml` at the project root. Caching or installing with npm/yarn keys looks for `package-lock.json` / `yarn.lock`, which don't exist. Also, the earlier master added a dependency without updating the lockfile, so a frozen install could not match. | No `cache:` key on setup-node; pnpm is installed explicitly (v10); the pnpm store is cached with a key that never fails; `pnpm-lock.yaml` is **updated** and verified against all 10 workspace projects; the install falls back to a normal install if the lockfile is ever out of date. |
| The `.apk` could not be found, so no download link | The uploader was given a path relative to a folder (or to the wrong folder) while Gradle writes to `artifacts/kabir-ai/android/app/build/outputs/apk/release/`. | The APK is **found by search** after the build, copied to `<workspace>/dist-apk/kabir-ai-release.apk`, verified (valid zip, signed), and uploaded from that fixed workspace path. The upload step fails loudly if the file is missing, and the run summary prints the download link. |

## Setup (5 minutes, once)

1. **Put the project in your repository** so that these exist (extract the ZIP first; GitHub does not unzip files):
   - `.github/workflows/build-android-apk.yml`
   - `pnpm-workspace.yaml`, `pnpm-lock.yaml`, `artifacts/`, `lib/`, …

   Best: use **git** or **GitHub Desktop** (`git add -A && git commit && git push`).
   Two traps with the website uploader: it accepts only **100 files per upload**, and the **hidden `.github` folder is often skipped** by drag-and-drop.
   If `.github` didn't arrive: on GitHub choose *Add file → Create new file*, type the name
   `.github/workflows/build-android-apk.yml`, and paste the contents of `github-workflow/build-android-apk.yml` (a visible copy included in the ZIP).
   If you uploaded the ZIP's contents inside a subfolder, that's fine for the build, **but the workflow file itself must still be at the repository root** (`.github/workflows/` at the top level) or GitHub will not see it.

2. **Set your API host.** Repository → *Settings → Secrets and variables → Actions → **Variables** tab → New repository variable*:
   Name `EXPO_PUBLIC_DOMAIN`, value = your API server's public HTTPS host, **host only**, e.g. `my-api.example.com`
   (no `https://`; the app talks HTTPS only). You can also type it when you start a run. The server must be running the code from this ZIP
   (it has new routes) with `OPENAI_API_KEY` set; see `BUILD_APK.md` §3 for tunnel/deploy options.

3. **Run it.** *Actions* tab → **Build Android APK** → **Run workflow**. (It also runs on pushes to `main`/`master`, and on tags `v*`.)
   The first run takes about **25–45 minutes** (it compiles React Native for two CPU types); later runs are faster thanks to caches.

4. **Download.** Open the finished run → the **summary** shows a download link, and the **Artifacts** section at the bottom lists
   **kabir-ai-apk**. Unzip it → `kabir-ai-release.apk`. Artifacts are kept 14 days. For a permanent link, push a tag
   (`git tag v1.0.0 && git push --tags`): the APK is attached to a GitHub **Release**.

5. **Install** on the phone: copy the APK over and open it (allow *install unknown apps*), or `adb install -r kabir-ai-release.apk`.
   Then follow `BUILD_APK.md` §7 (accessibility → *Allow restricted settings*, etc.).

## Options (when you press "Run workflow")
- **api_domain**: overrides the repository variable for this run.
- **abis**: default `arm64-v8a,armeabi-v7a` (every real phone). Use `arm64-v8a` alone for a faster, smaller build (phones from ~2017+).

## If a run fails
The workflow is built to tell you *why*:
1. Open the run → the red step shows the message. Compile errors from the native code are also listed as **annotations** at the top of the run page.
2. The full Gradle log is attached as artifact **build-logs**.
3. Send me those annotations (or the `build-logs` file). I'll fix the exact line.

## When Gradle says "BUILD FAILED" / "exit code 1"

Those two lines are only the wrapper: they say *that* the build failed, never *why*. (`DaemonCommandExecution` is just a stack
frame that appears in every failing Gradle run.) The real reason is a line like `e: ...Foo.kt`, `Unable to resolve module`,
`OutOfMemoryError: Metaspace`, `Execution failed for task ':...'`. This workflow finds it for you. After a failed run, open the run's
**summary page**: the **Failure analysis** section names the stage that broke (Kotlin, JavaScript bundling, resources, native C++,
SDK/NDK, network, memory), explains the fix, and quotes Gradle's "What went wrong" block, the failing task and the first Kotlin errors.
The same text is attached as artifact **build-diagnostics** together with the full Gradle log, the memory samples and the exact
configuration Expo generated.

### What the workflow does about memory and the Gradle daemon
| Setting | Value | Why |
|---|---|---|
| Runner | `ubuntu-24.04` (pinned) | `ubuntu-latest` moves; a moved image changes SDK/NDK under you. |
| Gradle heap / **Metaspace** | 6g / 2g on a 16 GB runner, 3g / 1536m on a 7 GB runner (auto-detected) | React Native's template sets Metaspace to **512m**, too small for Android Gradle Plugin + Kotlin; raising only `-Xmx` does not help. The template's lines are *removed*, not just overridden. |
| Kotlin daemon | its own heap (`kotlin.daemon.jvmargs`) | Otherwise it silently inherits the Gradle heap and doubles memory use. |
| Swap | 8 GB on `/mnt` | Stops the Linux OOM-killer from ending the build (that kills processes with no Java error message). |
| `--no-daemon`, `org.gradle.daemon=false`, `--stop` before a retry | | Every attempt is a fresh single-use Gradle process; nothing survives to be reused. |
| `workers.max`, `kotlin.incremental=false`, `caching=false`, `vfs.watch=false` | | Fewer simultaneous compilers, no stale incremental state. |
| Node heap for Metro | 3-4 GB (`NODE_OPTIONS`) | The JavaScript bundler runs inside Gradle and needs headroom too. |
| Download timeouts and retries | 120 s, 6 retries | Survives a flaky mirror. |
| Memory monitor | samples RAM every 15 s into `mem.log`, detached from the step's output | Lets a RAM problem be proven afterwards; a background process holding the step's pipes would make the step wait for it. |
| Lint tasks | disabled through an init script | Not needed for an APK; works whatever the task names are. |
| **Automatic retry** | only if the log shows a *memory* failure | JVM out-of-memory: retry with a bigger heap. RAM kill: retry with smaller heaps. Both: one CPU type, no parallelism. A real compile error is *not* retried (it would fail the same way after another 20 minutes). |
| JavaScript pre-check | `expo export` before Gradle | A bad import or syntax error shows up in about two minutes with Metro's own message. |

### Your earlier setup vs. this one
Your run used Node 20, **pnpm 9** and a `MaxMetaspaceSize=512m` flag. This project's `pnpm-workspace.yaml` uses pnpm 10 features
(`overrides`, `onlyBuiltDependencies`, `minimumReleaseAge`); pnpm 9 silently ignores them and installs a different dependency set than
the lockfile describes. Use this workflow as is (Node 22, pnpm 10, Java 17). Flags such as `-x lint -x test` are not needed.

### The honest limit
If the failure is a **Kotlin compile error in my native module**, no memory or daemon setting can fix it. The module has never been compiled
by anyone, and I have no Kotlin compiler here. The Failure analysis will say so and show the exact `e:` lines; send them to me and I fix those lines.

## What is and isn't verified
- ✅ The workflow's shell logic was tested by running every step against simulated repositories and a fake Gradle: layouts (root, inside a folder, two levels deep, project still in a ZIP), memory profiles for 16 GB / 7 GB / 1-CPU runners, the retry logic for 11 memory signatures, deterministic errors that must *not* retry, 13 failure-cause detectors, APK collection (signed, unsigned, odd locations, corrupt): **97 checks**, repeated 20 times to rule out flakiness (the ZIP-detection step was also hammered 60 times with the real archive; an earlier version failed 1 time in 3 and is fixed).
- ✅ Lockfile verified against all workspace `package.json` files; 117 app/server tests; native Kotlin reviewed line by line for compile risks.
- ❌ **Not verified:** a real run on GitHub, and the Kotlin compile. I can't run either from here, so I can't promise a first-try success. What I can promise is that a failure now tells you exactly where and why.
