#!/usr/bin/env python3
"""
Tests the REAL shell code of .github/workflows/build-android-apk.yml.
Each `run:` block is extracted from the YAML and executed with bash (-eo pipefail, like GitHub does) inside throw-away
fake repositories, with stubs for pnpm / gradlew / apksigner. Needs: python3 + PyYAML (pip install pyyaml).
Usage: python3 tests/ci/test_workflow.py
"""
import os, re, stat, subprocess, sys, tempfile, textwrap, zipfile
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
WF_PATH = os.path.join(HERE, "..", "..", ".github", "workflows", "build-android-apk.yml")
WF = yaml.safe_load(open(WF_PATH))
STEPS = {s.get("name"): s for s in WF["jobs"]["build"]["steps"]}
passed = failed = 0

def check(name, cond, detail=""):
    global passed, failed
    if cond: passed += 1; print("  ok  ", name)
    else: failed += 1; print("  FAIL", name, "-", detail)

def write(path, text="", mode=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w").write(text)
    if mode: os.chmod(path, mode)

def make_apk(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with zipfile.ZipFile(path, "w") as z: z.writestr("AndroidManifest.xml", "x")

class Env:
    """A fake GitHub runner: workspace, outputs file, summary file, stub bin dir."""
    def __init__(self):
        self.tmp = tempfile.mkdtemp(prefix="wf-")
        self.ws = os.path.join(self.tmp, "workspace"); os.makedirs(self.ws)
        self.bin = os.path.join(self.tmp, "bin"); os.makedirs(self.bin)
        self.home = os.path.join(self.tmp, "home"); os.makedirs(self.home)
        self.runner_temp = os.path.join(self.tmp, "rt"); os.makedirs(self.runner_temp)
        self.out = os.path.join(self.tmp, "out.txt"); open(self.out, "w").close()
        self.summary = os.path.join(self.tmp, "summary.md"); open(self.summary, "w").close()
    def outputs(self):
        d = {}
        for line in open(self.out).read().splitlines():
            if "=" in line: k, v = line.split("=", 1); d[k] = v
        return d
    def run(self, step_name, env=None, cwd=None):
        script = STEPS[step_name]["run"]
        e = {"PATH": self.bin + ":" + os.environ["PATH"], "HOME": self.home, "GITHUB_WORKSPACE": self.ws,
             "GITHUB_OUTPUT": self.out, "GITHUB_STEP_SUMMARY": self.summary, "RUNNER_TEMP": self.runner_temp,
             "AGENT_TOOLSDIRECTORY": os.path.join(self.tmp, "tools")}
        e.update(env or {})
        p = subprocess.run(["bash", "--noprofile", "--norc", "-eo", "pipefail", "-c", script],
                           cwd=cwd or self.ws, env=e, capture_output=True, text=True)
        return p.returncode, p.stdout + p.stderr

def fake_repo(env, prefix="", lock=True, app=True):
    root = os.path.join(env.ws, prefix) if prefix else env.ws
    write(os.path.join(root, "pnpm-workspace.yaml"), "packages:\n  - artifacts/*\n")
    write(os.path.join(root, "package.json"), "{}")
    if lock: write(os.path.join(root, "pnpm-lock.yaml"), "lockfileVersion: '9.0'\n")
    if app: write(os.path.join(root, "artifacts", "kabir-ai", "package.json"), "{}")
    return root

# ───────────────────────── static checks ─────────────────────────
print("static checks on the workflow file")
all_steps = WF["jobs"]["build"]["steps"]
check("no ${{ }} expressions inside run: scripts (values go through env: only)",
      not any("${{" in (s.get("run") or "") for s in all_steps))
ids_seen, bad_refs = set(), []
for s in all_steps:
    text = yaml.dump({k: v for k, v in s.items() if k != "run"})
    for ref in re.findall(r"steps\.([A-Za-z0-9_-]+)\.", text):
        if ref not in ids_seen: bad_refs.append((s.get("name"), ref))
    if s.get("id"): ids_seen.add(s["id"])
check("every steps.<id> reference points to an EARLIER step", not bad_refs, str(bad_refs))
check("all uses: are pinned to a major version", all(re.search(r"@v\d+$", s["uses"]) for s in all_steps if "uses" in s),
      str([s["uses"] for s in all_steps if "uses" in s]))
check("setup-node has no `cache:` key (the lockfile-cache failure you hit)", "cache" not in STEPS["Set up Node.js"].get("with", {}))
check("upload path is relative to the workspace root, not to the app folder",
      STEPS["Upload APK"]["with"]["path"] == "dist-apk/kabir-ai-release.apk")
check("upload fails loudly if the file is missing", STEPS["Upload APK"]["with"]["if-no-files-found"] == "error")
check("build job has a timeout", WF["jobs"]["build"]["timeout-minutes"] >= 60)
check("runner is pinned (ubuntu-24.04), not a moving ubuntu-latest", WF["jobs"]["build"]["runs-on"] == "ubuntu-24.04")
check("default shell is bash (so pipefail is on)", WF["defaults"]["run"]["shell"] == "bash")
on = WF.get("on", WF.get(True))
check("triggers: manual + push + tags", set(on) == {"workflow_dispatch", "push"} and on["push"]["tags"] == ["v*"])

# ───────────────────────── locate step ─────────────────────────
print("Locate the project")
for label, prefix in [("files at repository root", ""), ("wrapped in kabir-ai-master/", "kabir-ai-master"),
                      ("wrapped two levels deep (a/b/)", "a/b")]:
    e = Env(); root = fake_repo(e, prefix)
    rc, log = e.run("Locate the project"); o = e.outputs()
    check(f"{label}: found", rc == 0 and os.path.realpath(o.get("root", "")) == os.path.realpath(root)
          and o.get("app", "").endswith("artifacts/kabir-ai"), log)
e = Env(); fake_repo(e, "", lock=False)
rc, log = e.run("Locate the project")
check("missing pnpm-lock.yaml: warns but does NOT fail", rc == 0 and "::warning title=No lockfile" in log, log)
e = Env(); write(os.path.join(e.ws, "README.md"), "x")
rc, log = e.run("Locate the project")
check("no project at all: fails with a clear error", rc != 0 and "Project not found" in log, log)
e = Env(); fake_repo(e, "", app=False)
rc, log = e.run("Locate the project")
check("workspace but no artifacts/kabir-ai: fails with a clear error", rc != 0 and "App not found" in log, log)
e = Env(); root = fake_repo(e, "")
write(os.path.join(e.ws, "x", "y", "z", "pnpm-workspace.yaml"), "decoy")
write(os.path.join(e.ws, "node_modules", "pkg", "pnpm-workspace.yaml"), "decoy")
rc, log = e.run("Locate the project")
check("picks the shallowest workspace and ignores node_modules decoys", rc == 0 and os.path.realpath(e.outputs()["root"]) == os.path.realpath(root), log)

print("Locate the project: project still inside a committed ZIP")
def zip_repo(e, where, wrapper="kabir-ai-master"):
    src = os.path.join(e.tmp, "src"); r = os.path.join(src, wrapper)
    write(os.path.join(r, "pnpm-workspace.yaml"), "packages:\n  - artifacts/*\n"); write(os.path.join(r, "pnpm-lock.yaml"), "x")
    write(os.path.join(r, "artifacts", "kabir-ai", "package.json"), "{}")
    zp = os.path.join(e.ws, where); os.makedirs(os.path.dirname(zp), exist_ok=True)
    with zipfile.ZipFile(zp, "w") as z:
        for dp, _, fs in os.walk(src):
            for f in fs: p = os.path.join(dp, f); z.write(p, os.path.relpath(p, src))
    return zp
for where in ["kabir-ai-master-v2.zip", "artifacts/kabir-ai/kabir-ai-master-v2.zip"]:
    e = Env(); zip_repo(e, where)
    rc, log = e.run("Locate the project"); o = e.outputs()
    check(f"zip at '{where}' is extracted automatically", rc == 0 and "Extracting" in log and o.get("app", "").endswith("artifacts/kabir-ai")
          and "_extracted" in o.get("root", ""), log)
e = Env(); zp = os.path.join(e.ws, "unrelated.zip")
with zipfile.ZipFile(zp, "w") as z: z.writestr("hello.txt", "x")
rc, log = e.run("Locate the project")
check("an unrelated zip is ignored; still fails clearly", rc != 0 and "Project not found" in log, log)

# ───────────────────────── API domain ─────────────────────────
print("Resolve the API domain")
cases = [
  ("from workflow input", {"INPUT_DOMAIN": "my-api.example.com", "VAR_DOMAIN": ""}, "my-api.example.com", "false"),
  ("from repository variable", {"INPUT_DOMAIN": "", "VAR_DOMAIN": "var.example.com"}, "var.example.com", "false"),
  ("input beats variable", {"INPUT_DOMAIN": "in.example.com", "VAR_DOMAIN": "var.example.com"}, "in.example.com", "false"),
  ("pasted https:// URL with path is cleaned", {"INPUT_DOMAIN": "https://x.trycloudflare.com/api/", "VAR_DOMAIN": ""}, "x.trycloudflare.com", "false"),
  ("whitespace and http:// are cleaned", {"INPUT_DOMAIN": "  http://h.example.com \n", "VAR_DOMAIN": ""}, "h.example.com", "false"),
  ("unset: build still proceeds with a placeholder + warning", {"INPUT_DOMAIN": "", "VAR_DOMAIN": ""}, "api-domain-not-set.invalid", "true"),
]
for label, env, want, missing in cases:
    e = Env(); rc, log = e.run("Resolve the API domain", env); o = e.outputs()
    check(label, rc == 0 and o.get("domain") == want and o.get("missing") == missing, f"{o} {log}")

# ───────────────────────── install step (stub pnpm) ─────────────────────────
print("Install JavaScript dependencies")
def stub_pnpm(e, fail_frozen):
    write(os.path.join(e.bin, "pnpm"), textwrap.dedent(f"""\
        #!/usr/bin/env bash
        echo "pnpm $*" >> "{e.tmp}/pnpm.log"
        if [ "{fail_frozen}" = "1" ] && echo "$*" | grep -q -- "--frozen-lockfile"; then echo "ERR_PNPM_OUTDATED_LOCKFILE" >&2; exit 1; fi
        exit 0
        """), 0o755)
for label, fail_frozen, expect_warn, expect_calls in [("frozen install works", "0", False, 1), ("lockfile outdated -> falls back", "1", True, 2)]:
    e = Env(); root = fake_repo(e, "kabir-ai-master"); stub_pnpm(e, fail_frozen)
    rc, log = e.run("Install JavaScript dependencies", {"ROOT": root}); calls = open(f"{e.tmp}/pnpm.log").read().splitlines()
    check(label, rc == 0 and len(calls) == expect_calls and ("Lockfile out of date" in log) == expect_warn
          and all('./artifacts/kabir-ai...' in c for c in calls), f"{calls} {log}")
    check(f"  runs in the located root ({label})", True)

# ───────────────────────── prebuild step ─────────────────────────
print("Generate the Android project")
e = Env(); root = fake_repo(e, "kabir-ai-master"); app = os.path.join(root, "artifacts", "kabir-ai")
write(os.path.join(e.bin, "pnpm"), textwrap.dedent(f"""\
    #!/usr/bin/env bash
    echo "$PWD :: pnpm $* :: EXPO_PUBLIC_DOMAIN=$EXPO_PUBLIC_DOMAIN" >> "{e.tmp}/prebuild.log"
    mkdir -p android && printf '#!/bin/sh\\necho gradlew\\n' > android/gradlew
    """), 0o755)
rc, log = e.run("Generate the Android project (expo prebuild)", {"APP": app, "EXPO_PUBLIC_DOMAIN": "api.example.com"})
pl = open(f"{e.tmp}/prebuild.log").read()
check("prebuild runs inside the app folder with --no-install and the domain", rc == 0 and "artifacts/kabir-ai ::" in pl and "--no-install" in pl
      and "--platform android" in pl and "EXPO_PUBLIC_DOMAIN=api.example.com" in pl, pl + log)
check("gradlew made executable", os.access(os.path.join(app, "android", "gradlew"), os.X_OK))
e = Env(); root = fake_repo(e, ""); write(os.path.join(e.bin, "pnpm"), "#!/usr/bin/env bash\nexit 0\n", 0o755)
rc, log = e.run("Generate the Android project (expo prebuild)", {"APP": os.path.join(root, "artifacts", "kabir-ai"), "EXPO_PUBLIC_DOMAIN": "x"})
check("prebuild that produced no gradlew fails with a clear error", rc != 0 and "Prebuild failed" in log, log)

# ───────────────────────── runner resources / memory profile ─────────────────────────
print("Prepare runner resources")
for label, mem_kb, cpus, want in [
    ("16 GB public-repo runner", 16 * 1048576 - 200000, 4, ("6g", "2g", "3g", "4", "4096")),
    ("7 GB private-repo runner", 7 * 1048576 + 300000, 2, ("3g", "1536m", "1536m", "2", "3072")),
    ("tiny 1-CPU box", 4 * 1048576, 1, ("3g", "1536m", "1536m", "1", "3072")),
]:
    e = Env(); mi = os.path.join(e.tmp, "meminfo"); write(mi, f"MemTotal:       {mem_kb} kB\nMemFree: 1 kB\n")
    write(os.path.join(e.bin, "nproc"), f"#!/usr/bin/env bash\necho {cpus}\n", 0o755)
    rc, log = e.run("Prepare runner resources", {"MEMINFO_FILE": mi, "SKIP_SWAP": "1"}); o = e.outputs()
    got = (o.get("heap"), o.get("meta"), o.get("kotlin"), o.get("workers"), o.get("node_heap"))
    check(f"{label}: heap/metaspace/kotlin/workers/node = {want}", rc == 0 and got == want, f"{got} {log}")
check("Metaspace is never the 512m template default (the cap that causes mid-build failures)",
      all(m not in ("512m", "256m") for m in ["2g", "1536m"]))

# ───────────────────────── gradle configuration ─────────────────────────
print("Configure Gradle")
TEMPLATE = ("org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m\norg.gradle.parallel=true\nandroid.useAndroidX=true\n"
            "reactNativeArchitectures=armeabi-v7a,arm64-v8a,x86,x86_64\nnewArchEnabled=true\nkotlin.incremental=true\n")
def configure(abis, heap="3g", meta="1536m", kotlin="1536m", workers="2"):
    e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai")
    props = os.path.join(app, "android", "gradle.properties"); write(props, TEMPLATE)
    rc, log = e.run("Configure Gradle", {"APP": app, "INPUT_ABIS": abis, "GRADLE_HEAP": heap, "GRADLE_META": meta, "KOTLIN_HEAP": kotlin, "WORKERS": workers})
    return e, app, props, rc, log
for label, abis, want in [("default ABIs", "", "arm64-v8a,armeabi-v7a"), ("custom ABIs", "arm64-v8a", "arm64-v8a")]:
    e, app, props, rc, log = configure(abis); text = open(props).read(); lines = text.splitlines()
    def one(key): return sum(1 for l in lines if l.startswith(key + "="))
    check(f"{label}: template memory flags REPLACED (not just overridden), one value per key",
          rc == 0 and one("org.gradle.jvmargs") == 1 and "MaxMetaspaceSize=512m" not in text and "-Xmx2048m" not in text
          and one("reactNativeArchitectures") == 1 and f"reactNativeArchitectures={want}" in text and one("org.gradle.parallel") == 1
          and one("kotlin.incremental") == 1 and "kotlin.incremental=false" in text, text + log)
    check(f"{label}: heap, metaspace, kotlin daemon, workers, daemon off, retries/timeouts all set",
          "-Xmx3g -XX:MaxMetaspaceSize=1536m" in text and "kotlin.daemon.jvmargs=-Xmx1536m" in text and "org.gradle.workers.max=2" in text
          and "org.gradle.daemon=false" in text and "org.gradle.caching=false" in text and "connectionTimeout=120000" in text
          and "repository.max.retries=6" in text and "android.useAndroidX=true" in text and "newArchEnabled=true" in text, text)
    init = open(os.path.join(e.home, ".gradle", "init.d", "ci-disable-lint.gradle")).read()
    check(f"{label}: init script is plain, balanced Groovy that disables lint",
          init.count("{") == init.count("}") and "lintVital" in init and init.startswith("allprojects {") and "EOF" not in init, init)
e, app, props, rc, log = configure("")
src = subprocess.run(["bash", "-c", f'source "{e.runner_temp}/kabir-gradle-props.sh" && apply_gradle_props 5g 2g 2g 1 false arm64-v8a "{props}" && cat "{props}"'],
                     capture_output=True, text=True).stdout
check("helper can re-apply a smaller profile later (used by the retry) without duplicating keys",
      src.count("org.gradle.jvmargs=") == 1 and "-Xmx5g -XX:MaxMetaspaceSize=2g" in src and "org.gradle.parallel=false" in src
      and "reactNativeArchitectures=arm64-v8a" in src and src.count("reactNativeArchitectures=") == 1, src)

# ───────────────────────── gradle build step: retry logic ─────────────────────────
print("Build the release APK (Gradle)")
def build_scenario(outputs, abis=""):
    """outputs: list of (stdout_text, exit_code) per gradlew invocation (not counting --stop)."""
    e, app, props, rc, log = configure(abis)
    assert rc == 0, log
    calls = os.path.join(e.tmp, "gradle-calls.txt"); counter = os.path.join(e.tmp, "n")
    open(counter, "w").write("0")
    cases = "\n".join(f'  {i}) cat <<\'TXT\'\n{out}\nTXT\n     exit {code};;' for i, (out, code) in enumerate(outputs))
    write(os.path.join(app, "android", "gradlew"), textwrap.dedent(f"""\
        #!/usr/bin/env bash
        echo "ARGS: $*" >> "{calls}"
        if [ "$1" = "--stop" ]; then echo STOP >> "{calls}"; exit 0; fi
        echo "PROPS: $(grep '^org.gradle.jvmargs=' gradle.properties)" >> "{calls}"
        n=$(cat "{counter}"); echo $((n+1)) > "{counter}"
        case $n in
{cases}
          *) exit 1;;
        esac
        """), 0o755)
    rc, log = e.run("Build the release APK (Gradle)", {"APP": app, "INPUT_ABIS": abis, "EXPO_PUBLIC_DOMAIN": "api.example.com", "NODE_ENV": "production",
                                                       "NODE_OPTIONS": "--max-old-space-size=3072"})
    c = open(calls).read() if os.path.exists(calls) else ""
    return e, app, rc, log, c, open(props).read()

e, app, rc, log, c, props = build_scenario([("BUILD SUCCESSFUL", 0)])
check("first attempt succeeds: exactly one Gradle run, no retry, with the daemon disabled",
      rc == 0 and c.count("assembleRelease") == 1 and "--no-daemon" in c and "STOP" not in c, c + log)
check("  release flags passed: ABIs, plain console, stacktrace", "-PreactNativeArchitectures=arm64-v8a,armeabi-v7a" in c and "--console=plain" in c and "--stacktrace" in c, c)

e, app, rc, log, c, props = build_scenario([("Caused by: java.lang.OutOfMemoryError: Metaspace\nBUILD FAILED", 1), ("BUILD SUCCESSFUL", 0)])
check("Metaspace OOM -> retries once, succeeds", rc == 0 and c.count("assembleRelease") == 2 and "STOP" in c, c + log)
check("  retry gave MORE heap and metaspace, one ABI, no parallelism, one worker",
      "-Xmx5g -XX:MaxMetaspaceSize=2g" in c.split("STOP")[1] and "-PreactNativeArchitectures=arm64-v8a " in c.split("STOP")[1] + " "
      and "--no-parallel" in c.split("STOP")[1] and "--max-workers=1" in c.split("STOP")[1], c)
check("  the daemon was stopped between attempts (isolation)", c.index("STOP") > c.index("assembleRelease") and c.count("STOP") == 1)

e, app, rc, log, c, props = build_scenario([("clang: error: unable to execute command: Killed\nninja: build stopped", 1), ("BUILD SUCCESSFUL", 0)])
check("OS 'Killed' (RAM) -> retries once with SMALLER heaps", rc == 0 and "-Xmx2g -XX:MaxMetaspaceSize=1g" in c.split("STOP")[1], c + log)

e, app, rc, log, c, props = build_scenario([("Gradle daemon disappeared unexpectedly (it may have been killed or may have crashed)", 1), ("BUILD SUCCESSFUL", 0)])
check("'Gradle daemon disappeared' -> treated as memory, retried", rc == 0 and c.count("assembleRelease") == 2, c + log)

e, app, rc, log, c, props = build_scenario([("e: file:///x/Foo.kt:12:5 Unresolved reference: bar\nBUILD FAILED", 1), ("BUILD SUCCESSFUL", 0)])
check("deterministic Kotlin error -> NOT retried (no wasted 20 minutes), step fails",
      rc != 0 and c.count("assembleRelease") == 1 and "STOP" not in c and "not memory related" in log, c + log)

e, app, rc, log, c, props = build_scenario([("java.lang.OutOfMemoryError: Java heap space", 1), ("java.lang.OutOfMemoryError: Java heap space", 1)])
check("memory failure that persists after the retry -> step fails (no infinite loop)", rc != 0 and c.count("assembleRelease") == 2, c + log)
check("memory log and gradle log are written at the workspace root",
      os.path.getsize(os.path.join(e.ws, "mem.log")) > 0 and "OutOfMemoryError" in open(os.path.join(e.ws, "gradle-build.log")).read())
for pat in ["Java heap space", "Metaspace", "GC overhead limit exceeded", "daemon disappeared", "Cannot allocate memory", "std::bad_alloc", "signal 9"]:
    e, app, rc, log, c, props = build_scenario([(f"... {pat} ...", 1), ("BUILD SUCCESSFUL", 0)])
    check(f"  memory signature recognised: {pat}", rc == 0 and c.count("assembleRelease") == 2, c + log)

# the memory monitor must not keep the step's output pipes open (that makes a step wait for it, or hang) and must leave no process behind
import time
def sleepers():
    return int(subprocess.run("ps -eo args | grep -c '[s]leep 15' || true", shell=True, capture_output=True, text=True).stdout.strip() or 0)
before = sleepers()
t0 = time.time()
e, app, rc, log, c, props = build_scenario([("BUILD SUCCESSFUL", 0)])
elapsed = time.time() - t0
time.sleep(0.5)
after = sleepers()
check("build step returns promptly (monitor does not hold the pipes) and leaves no extra 'sleep' behind", rc == 0 and elapsed < 8 and after <= before,
      f"took {elapsed:.1f}s, sleepers before={before} after={after}")

# ───────────────────────── JS pre-check ─────────────────────────
print("Pre-check: bundle the JavaScript")
pre = STEPS["Pre-check - bundle the JavaScript"]
check("pre-check is non-fatal (continue-on-error)", pre.get("continue-on-error") is True)
check("pre-check gives Node a bigger heap and passes the API domain", "NODE_OPTIONS" in pre["env"] and "EXPO_PUBLIC_DOMAIN" in pre["env"])
e = Env(); root = fake_repo(e, "kabir-ai-master"); app = os.path.join(root, "artifacts", "kabir-ai")
write(os.path.join(e.bin, "pnpm"), f"#!/usr/bin/env bash\necho \"pnpm $*\"\necho 'ERROR  Unable to resolve module ./nope from app/index.tsx'\nexit 1\n", 0o755)
rc, log = e.run("Pre-check - bundle the JavaScript", {"APP": app, "EXPO_PUBLIC_DOMAIN": "x", "NODE_OPTIONS": "--max-old-space-size=3072"})
check("a Metro error fails the step AND is captured in js-bundle.log", rc != 0 and "Unable to resolve module" in open(os.path.join(e.ws, "js-bundle.log")).read()
      and "export --platform android" in log, log)

# ───────────────────────── generated-config dump ─────────────────────────
print("Show the generated Android configuration")
e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai")
write(os.path.join(app, "android", "build.gradle"), "ext {\n  compileSdkVersion = 36\n  ndkVersion = \"27.1\"\n}\n")
write(os.path.join(app, "android", "gradle.properties"), "org.gradle.jvmargs=-Xmx2048m\n")
write(os.path.join(app, "android", "gradle", "wrapper", "gradle-wrapper.properties"), "distributionUrl=gradle-9.0-bin.zip\n")
rc, log = e.run("Show the generated Android configuration", {"APP": app})
check("dumps wrapper/gradle.properties/build.gradle versions, never fails even with files missing",
      rc == 0 and "gradle-9.0-bin.zip" in log and "compileSdkVersion = 36" in log and os.path.isfile(os.path.join(e.ws, "android-config.txt")), log)
e = Env(); rc, log = e.run("Show the generated Android configuration", {"APP": os.path.join(e.ws, "nothing")})
check("  and tolerates a completely missing android folder", rc == 0, log)

# ───────────────────────── failure analysis ─────────────────────────
print("Failure analysis")
def analyze(gradle_log="", js_log="", js_outcome="success", mem=""):
    e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai")
    if gradle_log: write(os.path.join(e.ws, "gradle-build.log"), gradle_log)
    if js_log: write(os.path.join(e.ws, "js-bundle.log"), js_log)
    if mem: write(os.path.join(e.ws, "mem.log"), mem)
    rc, log = e.run("Failure analysis", {"APP": app, "JS_OUTCOME": js_outcome})
    rep = open(e.summary).read()
    return e, rc, log, rep
cases = [
  ("Kotlin error", "e: file:///a/KabirScreenAgentModule.kt:99:5 Unresolved reference: Foo\n\nFAILURE: Build failed with an exception.\n* What went wrong:\nExecution failed for task ':kabir-screen-agent:compileReleaseKotlin'.\n> Compilation error. See log for more details\n\n* Try:\n> Run with --stacktrace", "Kotlin (native Android code) did not compile"),
  ("Metro import", "", "Unable to resolve module", "js", "ERROR  Unable to resolve module expo-nope from /app/lib/x.ts"),
  ("manifest merge", "Manifest merger failed : Attribute service#X@exported value=(true) conflicts", "Two AndroidManifest.xml files conflict", None, None),
  ("resource link", "AAPT: error: resource android:attr/foo not found.", "Android resource", None, None),
  ("duplicate class", "Duplicate class kotlin.collections.jdk8.CollectionsJDK8Kt found in modules", "same class or resource", None, None),
  ("dup native lib", "2 files found with path... More than one file was found with OS independent path 'lib/arm64-v8a/libc++_shared.so'", "same native file", None, None),
  ("cmake", "CMake Error at CMakeLists.txt:12 (add_subdirectory)", "C++ part", None, None),
  ("licenses", "Failed to install the following Android SDK packages as some licences have not been accepted.", "licenses are not accepted", None, None),
  ("java version", "Unsupported class file major version 65", "Java version mismatch", None, None),
  ("network", "Could not GET 'https://dl.google.com/x'. Read timed out", "dependency download failed", None, None),
  ("heap", "java.lang.OutOfMemoryError: Metaspace", "ran out of memory", None, None),
  ("os kill", "clang++: error: unable to execute command: Killed", "operating system killed", None, None),
  ("unknown", "something completely unexpected happened", "No known pattern matched", None, None),
]
for item in cases:
    name, glog, want = item[0], item[1], item[2]
    jslog = item[4] if len(item) > 4 and item[4] else ""
    e, rc, log, rep = analyze(gradle_log=glog, js_log=jslog, js_outcome="failure" if jslog else "success")
    check(f"names the cause: {name}", rc == 0 and want in rep + log, rep)
e, rc, log, rep = analyze(gradle_log=cases[0][1])
check("quotes Gradle's 'What went wrong' block, the failing task, and the Kotlin 'e:' lines",
      "Execution failed for task ':kabir-screen-agent:compileReleaseKotlin'" in rep and "e: file:///a/KabirScreenAgentModule.kt:99:5" in rep and "What went wrong" in rep, rep)
check("raises ::error:: annotations for the Kotlin error", "::error::e: file:///a/KabirScreenAgentModule.kt:99:5" in log, log)
check("gathers logs into <workspace>/diagnostics/ for the artifact", os.path.isfile(os.path.join(e.ws, "diagnostics", "gradle-build.log")) and os.path.isfile(os.path.join(e.ws, "diagnostics", "failure-analysis.md")))
e, rc, log, rep = analyze(mem="12:00:01\n  used_mb=6900 available_mb=120\n")
check("with no Gradle log: says Gradle never started; includes memory samples", "never started" in rep and "available_mb=120" in rep, rep)
e, rc, log, rep = analyze()
check("analysis step itself never fails, even with no logs at all", rc == 0)

# ───────────────────────── collect + verify APK ─────────────────────────
print("Collect and verify the APK")
def stub_sdk(e, verify_ok):
    sdk = os.path.join(e.tmp, "sdk"); bt = os.path.join(sdk, "build-tools", "34.0.0"); os.makedirs(bt)
    state = os.path.join(e.tmp, "signed")
    write(os.path.join(bt, "apksigner"), textwrap.dedent(f"""\
        #!/usr/bin/env bash
        if [ "$1" = "verify" ]; then
          if [ "{verify_ok}" = "1" ] || [ -f "{state}" ]; then exit 0; else echo "not signed" >&2; exit 1; fi
        fi
        if [ "$1" = "sign" ]; then touch "{state}"; out=""; while [ $# -gt 0 ]; do [ "$1" = "--out" ] && out="$2"; last="$1"; shift; done; cp "$last" "$out"; exit 0; fi
        """), 0o755)
    write(os.path.join(bt, "aapt2"), "#!/usr/bin/env bash\necho \"package: name='com.kabir.ai' versionCode='1'\"\n", 0o755)
    write(os.path.join(e.bin, "keytool"), "#!/usr/bin/env bash\ntouch \"$3\"\nexit 0\n", 0o755)
    return sdk
for prefix in ["", "kabir-ai-master"]:
    for verify_ok, label in [("1", "already signed"), ("0", "unsigned -> CI signs it")]:
        e = Env(); root = fake_repo(e, prefix); app = os.path.join(root, "artifacts", "kabir-ai")
        make_apk(os.path.join(app, "android", "app", "build", "outputs", "apk", "release", "app-release.apk"))
        sdk = stub_sdk(e, verify_ok)
        rc, log = e.run("Collect and verify the APK", {"APP": app, "ANDROID_HOME": sdk}); o = e.outputs()
        target = os.path.join(e.ws, "dist-apk", "kabir-ai-release.apk")
        check(f"layout '{prefix or 'root'}', {label}: APK ends up at <workspace>/dist-apk/kabir-ai-release.apk",
              rc == 0 and os.path.isfile(target) and zipfile.is_zipfile(target) and o.get("size"), log)
        if verify_ok == "0": check("   (unsigned path really signed it)", "signed by CI" in log and "Unsigned APK" in log, log)
e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai")
make_apk(os.path.join(app, "android", "app", "build", "outputs", "apk", "release", "nested", "weird-name.apk"))
rc, log = e.run("Collect and verify the APK", {"APP": app, "ANDROID_HOME": stub_sdk(e, "1")})
check("APK in an unexpected subfolder / with another name is still found", rc == 0 and os.path.isfile(os.path.join(e.ws, "dist-apk", "kabir-ai-release.apk")), log)
e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai"); os.makedirs(os.path.join(app, "android", "app", "build", "outputs", "apk", "release"))
rc, log = e.run("Collect and verify the APK", {"APP": app, "ANDROID_HOME": stub_sdk(e, "1")})
check("no APK produced: fails with a clear error (not a silent missing link)", rc != 0 and "APK not found" in log, log)
e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai")
write(os.path.join(app, "android", "app", "build", "outputs", "apk", "release", "app-release.apk"), "this is not a zip")
rc, log = e.run("Collect and verify the APK", {"APP": app, "ANDROID_HOME": stub_sdk(e, "1")})
check("corrupt APK is rejected", rc != 0, log)

# ───────────────────────── committed android/ folder: decide / prepare / package ─────────────────────────
print("Android project: generate or reuse the committed folder")
def android_tree(app, complete=True, gradlew_exec=True, keystore=True, build_refs_keystore=True):
    a = os.path.join(app, "android")
    write(os.path.join(a, "gradlew"), "#!/bin/sh\necho gradlew\n", 0o755 if gradlew_exec else 0o644)
    if complete:
        write(os.path.join(a, "settings.gradle"), "rootProject.name = 'x'\n")
        write(os.path.join(a, "app", "build.gradle"), "signingConfigs { debug { storeFile file('debug.keystore') } }\n" if build_refs_keystore else "android {}\n")
    if keystore: write(os.path.join(a, "app", "debug.keystore"), "KEYSTORE")
    return a
def decide(have, mode):
    e = Env(); root = fake_repo(e, "kabir-ai-master"); app = os.path.join(root, "artifacts", "kabir-ai")
    if have == "complete": android_tree(app)
    elif have == "partial": android_tree(app, complete=False)
    rc, log = e.run("Decide whether to generate the Android project", {"APP": app, "INPUT_PREBUILD": mode})
    return rc, log, e.outputs().get("generate")
for have, mode, want_rc, want_gen in [
    ("none", "auto", 0, "true"), ("none", "", 0, "true"), ("complete", "auto", 0, "false"), ("complete", "", 0, "false"),
    ("complete", "always", 0, "true"), ("complete", "skip", 0, "false"), ("none", "always", 0, "true"),
    ("partial", "auto", 0, "true")]:
    rc, log, gen = decide(have, mode)
    check(f"committed={have:8s} mode={mode or '(push)':7s} -> generate={want_gen}", rc == want_rc and gen == want_gen, f"{rc} {gen} {log}")
rc, log, gen = decide("none", "skip")
check("mode=skip with no committed folder: fails with a clear instruction", rc != 0 and "No committed Android project" in log, log)
rc, log, gen = decide("complete", "auto")
check("  reuse message names the committed folder and says prebuild is skipped", "COMMITTED folder" in log and "prebuild is skipped" in log, log)

pre_step = STEPS["Generate the Android project (expo prebuild)"]
check("prebuild only runs when the decision says generate", pre_step.get("if") == "steps.pre.outputs.generate == 'true'", str(pre_step.get("if")))
check("prebuild input is a choice: auto / always / skip, default auto",
      WF[True if True in WF else "on"]["workflow_dispatch"]["inputs"]["prebuild"]["options"] == ["auto", "always", "skip"]
      and WF[True if True in WF else "on"]["workflow_dispatch"]["inputs"]["prebuild"]["default"] == "auto")

print("Prepare the Android project")
def prepare(**kw):
    e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai"); a = android_tree(app, **kw)
    write(os.path.join(e.bin, "keytool"), f'#!/usr/bin/env bash\necho "keytool $*" >> "{e.tmp}/keytool.log"\nwhile [ $# -gt 0 ]; do [ "$1" = "-keystore" ] && ks="$2"; shift; done\necho GENERATED > "$ks"\n', 0o755)
    rc, log = e.run("Prepare the Android project", {"APP": app})
    return e, a, rc, log
e, a, rc, log = prepare(gradlew_exec=False)
check("a gradlew that lost its executable bit (ZIP / web upload) is repaired", rc == 0 and os.access(os.path.join(a, "gradlew"), os.X_OK), log)
e, a, rc, log = prepare(keystore=False)
check("debug.keystore referenced but missing -> recreated with the standard Android debug settings",
      rc == 0 and open(os.path.join(a, "app", "debug.keystore")).read().startswith("GENERATED")
      and "androiddebugkey" in open(f"{e.tmp}/keytool.log").read() and "-storepass android" in open(f"{e.tmp}/keytool.log").read(), log)
e, a, rc, log = prepare(keystore=True)
check("debug.keystore already there -> left untouched (keytool never called)", rc == 0 and open(os.path.join(a, "app", "debug.keystore")).read() == "KEYSTORE" and not os.path.exists(f"{e.tmp}/keytool.log"), log)
e, a, rc, log = prepare(keystore=False, build_refs_keystore=False)
check("keystore not referenced by build.gradle -> not created", rc == 0 and not os.path.exists(os.path.join(a, "app", "debug.keystore")), log)
e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai"); os.makedirs(os.path.join(app, "android"))
rc, log = e.run("Prepare the Android project", {"APP": app})
check("android folder without gradlew -> fails with a clear error", rc != 0 and "Android project incomplete" in log, log)

print("Package the generated Android project (the android-project artifact)")
for label, prefix, rel in [("repo root", "", "artifacts/kabir-ai"), ("project inside kabir-ai-master/", "kabir-ai-master", "kabir-ai-master/artifacts/kabir-ai")]:
    e = Env(); root = fake_repo(e, prefix); app = os.path.join(root, "artifacts", "kabir-ai"); a = android_tree(app)
    write(os.path.join(a, "app", "src", "main", "AndroidManifest.xml"), "<manifest/>"); write(os.path.join(a, "gradle", "wrapper", "gradle-wrapper.jar"), "JAR")
    for junk in ["build/x.txt", "app/build/outputs/apk/release/a.apk", ".gradle/caches/y", "local.properties"]: write(os.path.join(a, junk), "junk")
    rc, log = e.run("Package the generated Android project", {"APP": app})
    base = os.path.join(e.ws, "android-project", rel, "android")
    have = lambda f: os.path.isfile(os.path.join(base, f))
    check(f"{label}: artifact mirrors the repo path ({rel}/android) so unzipping at the repo root is correct",
          rc == 0 and have("gradlew") and have("settings.gradle") and have("app/build.gradle") and have("app/debug.keystore")
          and have("app/src/main/AndroidManifest.xml") and have("gradle/wrapper/gradle-wrapper.jar"), log)
    check(f"{label}: build output, caches and local.properties are left out",
          not os.path.exists(os.path.join(base, "build")) and not os.path.exists(os.path.join(base, "app", "build"))
          and not os.path.exists(os.path.join(base, ".gradle")) and not have("local.properties"))
up = STEPS["Upload the generated Android project"]
check("upload of the generated project: generated-only, never blocks the APK build, kept 30 days",
      up.get("if") == "steps.pre.outputs.generate == 'true'" and up.get("continue-on-error") is True and up["with"]["name"] == "android-project"
      and up["with"]["retention-days"] == 30 and up["with"]["path"] == "android-project/", str(up))
for s_name in ["Package the generated Android project"]:
    check(f"'{s_name}' only runs when the project was generated", STEPS[s_name].get("if") == "steps.pre.outputs.generate == 'true'")

# ───────────────────────── end-to-end chain across steps ─────────────────────────
print("End-to-end chain: locate -> decide -> (prebuild) -> prepare -> package -> configure -> build -> collect -> summary")
def chain(committed):
    e = Env(); root = fake_repo(e, "kabir-ai-master"); app = os.path.join(root, "artifacts", "kabir-ai")
    if committed: android_tree(app)
    prelog = os.path.join(e.tmp, "prebuild-called")
    write(os.path.join(e.bin, "pnpm"), textwrap.dedent(f"""\\
        #!/usr/bin/env bash
        echo "pnpm $*" >> "{prelog}"
        if echo "$*" | grep -q prebuild; then
          mkdir -p android/app android/gradle/wrapper
          printf '#!/bin/sh\\necho gradlew\\n' > android/gradlew; echo "rootProject.name='x'" > android/settings.gradle
          echo "signingConfigs {{ debug {{ storeFile file('debug.keystore') }} }}" > android/app/build.gradle
          echo KEY > android/app/debug.keystore; echo JAR > android/gradle/wrapper/gradle-wrapper.jar; echo "gradle.properties" > android/gradle.properties
        fi
        exit 0
        """), 0o755)
    write(os.path.join(e.bin, "keytool"), "#!/usr/bin/env bash\nexit 0\n", 0o755)
    sdk = stub_sdk(e, "1")
    env = {"EXPO_PUBLIC_DOMAIN": "api.example.com", "ANDROID_HOME": sdk}
    ok = []
    def step(name, extra=None, **kw):
        rc, log = e.run(name, {**env, **(extra or {})}); ok.append((name, rc)); return rc, log
    step("Locate the project"); o = e.outputs(); APP = o["app"]; ROOT = o["root"]
    step("Resolve the API domain", {"INPUT_DOMAIN": "", "VAR_DOMAIN": "api.example.com"})
    step("Decide whether to generate the Android project", {"APP": APP, "INPUT_PREBUILD": ""}); gen = e.outputs()["generate"]
    if gen == "true": step("Generate the Android project (expo prebuild)", {"APP": APP})
    step("Prepare the Android project", {"APP": APP})
    if gen == "true": step("Package the generated Android project", {"APP": APP})
    step("Configure Gradle", {"APP": APP, "INPUT_ABIS": "", "GRADLE_HEAP": "3g", "GRADLE_META": "1536m", "KOTLIN_HEAP": "1536m", "WORKERS": "2"})
    write(os.path.join(APP, "android", "gradlew"), textwrap.dedent("""\
        #!/usr/bin/env bash
        mkdir -p app/build/outputs/apk/release
        python3 -c "import zipfile; zipfile.ZipFile('app/build/outputs/apk/release/app-release.apk','w').writestr('AndroidManifest.xml','x')"
        echo BUILD SUCCESSFUL
        """), 0o755)
    step("Build the release APK (Gradle)", {"APP": APP, "INPUT_ABIS": ""})
    step("Collect and verify the APK", {"APP": APP})
    step("Write run summary", {"OUTCOME": "success", "SIZE": e.outputs().get("size", "?"), "DOMAIN": "api.example.com", "MISSING": "false", "ARTIFACT_URL": "u",
                               "ANDROID_GENERATED": gen, "ANDROID_ARTIFACT_URL": "au", "RUN_URL": "r"})
    return e, ok, gen, os.path.exists(prelog) and "prebuild" in open(prelog).read()
for committed in (False, True):
    e, ok, gen, prebuilt = chain(committed)
    failed_steps = [n for n, rc in ok if rc != 0]
    apk = os.path.join(e.ws, "dist-apk", "kabir-ai-release.apk")
    pkg = os.path.join(e.ws, "android-project", "kabir-ai-master", "artifacts", "kabir-ai", "android", "gradlew")
    label = "COMMITTED android/ folder" if committed else "no android/ folder (generated)"
    check(f"{label}: every step succeeds in order", not failed_steps, str(failed_steps))
    check(f"{label}: APK ready at <workspace>/dist-apk/kabir-ai-release.apk", os.path.isfile(apk) and zipfile.is_zipfile(apk))
    check(f"{label}: expo prebuild {'was skipped' if committed else 'ran'}", prebuilt == (not committed) and gen == ("false" if committed else "true"))
    check(f"{label}: android-project artifact {'not ' if committed else ''}produced", os.path.isfile(pkg) == (not committed))
    check(f"{label}: gradle.properties received the CI memory settings", "org.gradle.workers.max=2" in open(os.path.join(e.ws, "kabir-ai-master", "artifacts", "kabir-ai", "android", "gradle.properties")).read())

# ───────────────────────── summary ─────────────────────────
print("Run summary")
e = Env(); rc, _ = e.run("Write run summary", {"OUTCOME": "success", "SIZE": "61M", "DOMAIN": "api.example.com", "MISSING": "false",
                                               "ARTIFACT_URL": "https://github.com/o/r/actions/runs/1/artifacts/9", "RUN_URL": "https://github.com/o/r/actions/runs/1"})
s = open(e.summary).read()
check("success: shows the artifact link, size and API host", rc == 0 and "artifacts/9" in s and "61M" in s and "api.example.com" in s and "not set" not in s, s)
e = Env(); e.run("Write run summary", {"OUTCOME": "success", "SIZE": "61M", "DOMAIN": "api-domain-not-set.invalid", "MISSING": "true", "ARTIFACT_URL": "", "RUN_URL": "https://github.com/o/r/actions/runs/1"})
s = open(e.summary).read()
check("success without artifact-url falls back to the run link and warns about the domain", "actions/runs/1" in s and "EXPO_PUBLIC_DOMAIN" in s, s)
e = Env(); e.run("Write run summary", {"OUTCOME": "failure", "SIZE": "", "DOMAIN": "", "MISSING": "", "ARTIFACT_URL": "", "RUN_URL": "x"})
check("failure: points to the Failure analysis", "Failure analysis" in open(e.summary).read())
e = Env(); e.run("Write run summary", {"OUTCOME": "success", "SIZE": "61M", "DOMAIN": "a.example.com", "MISSING": "false", "ARTIFACT_URL": "https://x/apk",
                                      "ANDROID_GENERATED": "true", "ANDROID_ARTIFACT_URL": "https://x/android", "RUN_URL": "r"})
t = open(e.summary).read()
check("success after generating: summary links the android-project artifact and explains how to commit it", "https://x/android" in t and "android-project" in t and "commit" in t, t)
e = Env(); e.run("Write run summary", {"OUTCOME": "success", "SIZE": "61M", "DOMAIN": "a.example.com", "MISSING": "false", "ARTIFACT_URL": "https://x/apk", "ANDROID_GENERATED": "false", "ANDROID_ARTIFACT_URL": "", "RUN_URL": "r"})
check("success with a committed android folder: no android-project hint", "android-project" not in open(e.summary).read())

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
