# Kabir AI: master package

One project containing **everything built so far**, already integrated and ready to build into an APK.
**Build in the cloud: [`GITHUB_ACTIONS.md`](GITHUB_ACTIONS.md). Build on your own computer: [`BUILD_APK.md`](BUILD_APK.md).**

## What's inside

| Part | What it does | Where |
|---|---|---|
| **Your original app + API server** | Voice assistant, wake phrases, learning memory, theme, **Smart diagnostics** | `artifacts/kabir-ai`, `artifacts/api-server`, `lib/*` (unchanged except where noted below) |
| **Screen Agent** (native Android, Kotlin) | Screen capture + on-device OCR, accessibility reading, exact-pixel taps/swipes/pinch/typing, teach-mode recorder | `artifacts/kabir-ai/modules/kabir-screen-agent/` |
| **Voice → screen commands** | "Open Settings and scroll", validated step whitelist, precise verified taps, confirmation for risky actions | `lib/screen-commands/`, `hooks/useVoiceCommands.ts`, `api-server/src/routes/command.ts` |
| **App automation** | YouTube search-and-play workflow; chess-style board moves; gestures | `lib/workflows/`, `lib/screen-commands/grid.ts` |
| **Self-learning routines** | Teach by showing, learn from tutorial text, supervised first run, success tracking, repair proposals | `lib/learning/`, `hooks/useWorkflows.ts`, `app/routines.tsx`, `api-server/src/routes/learn-workflow.ts` |
| **Diagnostics** | Your existing diagnostic system, now also catching screen-control problems with fix steps | `lib/error-monitor.ts` (new rules), `lib/screen-commands/diagnostics.ts` |
| **Tools & tests** | Build preflight, one-command APK build, **GitHub Actions workflow**, 165 automated checks | `tools/`, `.github/workflows/`, `tests/` |

> **About "the diagnostic system":** that is the one already in your project (`lib/error-monitor.ts`, shown in
> *Settings → Smart diagnostics*). I did not build a separate one earlier. In this master I connected the new automation
> code to it, and added fix-step rules for accessibility-off, missing permissions, blocked apps, "couldn't find it on
> screen" and routines needing repair. A full in-app status screen for the Screen Agent would be a good next addition.

## Quick start
```bash
unzip kabir-ai-master.zip && cd kabir-ai-master
export EXPO_PUBLIC_DOMAIN="your-api-host.example.com"    # your API server's public HTTPS host (see BUILD_APK.md §3)
bash tools/check-env.sh                                  # preflight: tells you what to install/fix
bash tools/build-apk.sh --install                        # builds dist-apk/kabir-ai-release.apk and installs it
```

## Changes made to your original files (and why)
| File | Change |
|---|---|
| `artifacts/kabir-ai/app.json` | Added `android.package = com.kabir.ai` and `versionCode` (required to build an Android app) |
| `artifacts/kabir-ai/package.json` | Added `expo-modules-core` (the native module imports it; pnpm hides transitive packages) and a `prebuild:android` script |
| `artifacts/kabir-ai/app/(tabs)/index.tsx` | Voice requests go through the command planner when screen access is on; otherwise unchanged |
| `artifacts/kabir-ai/app/(tabs)/settings.tsx`, `app/_layout.tsx` | "Routines" card + screen registration |
| `artifacts/kabir-ai/lib/error-monitor.ts` | New diagnosis rules (placed before the old ones; old rules unchanged, covered by tests) |
| `artifacts/api-server/src/routes/index.ts`, `kabir.ts` | Mount the two new routers; export two helpers |
| `lib/api-client-react/src/index.ts` | Also export `customFetch` |
| `.gitignore`, `.gitattributes` | Ignore generated `android/`, `*.apk`; keep LF line endings for scripts and workflows |
| `pnpm-lock.yaml` | Lockfile updated for the added `expo-modules-core` dependency (verified against all 10 workspace packages) |
| `.github/workflows/build-android-apk.yml` | NEW: cloud APK build (see `GITHUB_ACTIONS.md`) |
Removed from the package (not needed to build): `.git`, `static-build/` output, browser config folders, an empty `.conversation`.

## Verified vs. not verified
- ✅ **117 automated tests** + TypeScript type-check: `bash tests/run-all.sh` (mocked phone, fake YouTube and chessboard, mocked OpenAI, your real `error-monitor.ts`).
- ✅ Preflight script behaviour; JSON configs valid; ZIP extracts and the tests pass from the extracted copy.
- ❌ **The Kotlin has never been compiled**, and nothing has run on a real phone. Expect to possibly fix a native compile error on the first build (see `BUILD_APK.md` §9).
- ❌ The YouTube workflow has not been tried against the real YouTube app; it matches by meaning with fallbacks, but may need tuning.

## Safety principles (kept throughout)
Fixed whitelist of actions (LLM output is untrusted, validated on server *and* app) · confirmation for payments/deletions/permissions ·
visible notifications while reading/recording · password fields never read, recorded or typed · blocklist for apps Kabir must not touch ·
screen contents stay on the phone unless you opt in · learning is from text or your own demonstration (no video download) ·
chess support has no engine: use it for puzzles/practice, not for assistance in live games against people.

More detail: `docs/` (Screen Agent, voice commands, file map incl. every Kotlin file).
