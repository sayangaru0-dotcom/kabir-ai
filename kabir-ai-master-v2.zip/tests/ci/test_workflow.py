#!/usr/bin/env python3
"""
Tests the REAL shell code of .github/workflows/build-android-apk.yml.
Each `run:` block is extracted from the YAML and executed with bash (-eo pipefail, like GitHub does) inside throw-away
fake repositories, with stubs for pnpm / gradlew / apksigner. Needs: python3 + PyYAML (pip install pyyaml).
Usage: python3 tests/ci/test_workflow.py
"""
import os, re, stat, subprocess, sys, tempfile, textwrap, zipfile
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
WF_PATH = os.path.join(HERE, "..", "..", ".github", "workflows", "build-android-apk.yml")
WF = yaml.safe_load(open(WF_PATH))
STEPS = {s.get("name"): s for s in WF["jobs"]["build"]["steps"]}
passed = failed = 0

def check(name, cond, detail=""):
    global passed, failed
    if cond: passed += 1; print("  ok  ", name)
    else: failed += 1; print("  FAIL", name, "-", detail)

def write(path, text="", mode=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w").write(text)
    if mode: os.chmod(path, mode)

def make_apk(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with zipfile.ZipFile(path, "w") as z: z.writestr("AndroidManifest.xml", "x")

class Env:
    """A fake GitHub runner: workspace, outputs file, summary file, stub bin dir."""
    def __init__(self):
        self.tmp = tempfile.mkdtemp(prefix="wf-")
        self.ws = os.path.join(self.tmp, "workspace"); os.makedirs(self.ws)
        self.bin = os.path.join(self.tmp, "bin"); os.makedirs(self.bin)
        self.home = os.path.join(self.tmp, "home"); os.makedirs(self.home)
        self.runner_temp = os.path.join(self.tmp, "rt"); os.makedirs(self.runner_temp)
        self.out = os.path.join(self.tmp, "out.txt"); open(self.out, "w").close()
        self.summary = os.path.join(self.tmp, "summary.md"); open(self.summary, "w").close()
    def outputs(self):
        d = {}
        for line in open(self.out).read().splitlines():
            if "=" in line: k, v = line.split("=", 1); d[k] = v
        return d
    def run(self, step_name, env=None, cwd=None):
        script = STEPS[step_name]["run"]
        e = {"PATH": self.bin + ":" + os.environ["PATH"], "HOME": self.home, "GITHUB_WORKSPACE": self.ws,
             "GITHUB_OUTPUT": self.out, "GITHUB_STEP_SUMMARY": self.summary, "RUNNER_TEMP": self.runner_temp,
             "AGENT_TOOLSDIRECTORY": os.path.join(self.tmp, "tools")}
        e.update(env or {})
        p = subprocess.run(["bash", "--noprofile", "--norc", "-eo", "pipefail", "-c", script],
                           cwd=cwd or self.ws, env=e, capture_output=True, text=True)
        return p.returncode, p.stdout + p.stderr

def fake_repo(env, prefix="", lock=True, app=True):
    root = os.path.join(env.ws, prefix) if prefix else env.ws
    write(os.path.join(root, "pnpm-workspace.yaml"), "packages:\n  - artifacts/*\n")
    write(os.path.join(root, "package.json"), "{}")
    if lock: write(os.path.join(root, "pnpm-lock.yaml"), "lockfileVersion: '9.0'\n")
    if app: write(os.path.join(root, "artifacts", "kabir-ai", "package.json"), "{}")
    return root

# ───────────────────────── static checks ─────────────────────────
print("static checks on the workflow file")
all_steps = WF["jobs"]["build"]["steps"]
check("no ${{ }} expressions inside run: scripts (values go through env: only)",
      not any("${{" in (s.get("run") or "") for s in all_steps))
ids_seen, bad_refs = set(), []
for s in all_steps:
    text = yaml.dump({k: v for k, v in s.items() if k != "run"})
    for ref in re.findall(r"steps\.([A-Za-z0-9_-]+)\.", text):
        if ref not in ids_seen: bad_refs.append((s.get("name"), ref))
    if s.get("id"): ids_seen.add(s["id"])
check("every steps.<id> reference points to an EARLIER step", not bad_refs, str(bad_refs))
check("all uses: are pinned to a major version", all(re.search(r"@v\d+$", s["uses"]) for s in all_steps if "uses" in s),
      str([s["uses"] for s in all_steps if "uses" in s]))
check("setup-node has no `cache:` key (the lockfile-cache failure you hit)", "cache" not in STEPS["Set up Node.js"].get("with", {}))
check("upload path is relative to the workspace root, not to the app folder",
      STEPS["Upload APK"]["with"]["path"] == "dist-apk/kabir-ai-release.apk")
check("upload fails loudly if the file is missing", STEPS["Upload APK"]["with"]["if-no-files-found"] == "error")
check("build job has a timeout", WF["jobs"]["build"]["timeout-minutes"] >= 60)
check("default shell is bash (so pipefail is on)", WF["defaults"]["run"]["shell"] == "bash")
on = WF.get("on", WF.get(True))
check("triggers: manual + push + tags", set(on) == {"workflow_dispatch", "push"} and on["push"]["tags"] == ["v*"])

# ───────────────────────── locate step ─────────────────────────
print("Locate the project")
for label, prefix in [("files at repository root", ""), ("wrapped in kabir-ai-master/", "kabir-ai-master"),
                      ("wrapped two levels deep (a/b/)", "a/b")]:
    e = Env(); root = fake_repo(e, prefix)
    rc, log = e.run("Locate the project"); o = e.outputs()
    check(f"{label}: found", rc == 0 and os.path.realpath(o.get("root", "")) == os.path.realpath(root)
          and o.get("app", "").endswith("artifacts/kabir-ai"), log)
e = Env(); fake_repo(e, "", lock=False)
rc, log = e.run("Locate the project")
check("missing pnpm-lock.yaml: warns but does NOT fail", rc == 0 and "::warning title=No lockfile" in log, log)
e = Env(); write(os.path.join(e.ws, "README.md"), "x")
rc, log = e.run("Locate the project")
check("no project at all: fails with a clear error", rc != 0 and "Project not found" in log, log)
e = Env(); fake_repo(e, "", app=False)
rc, log = e.run("Locate the project")
check("workspace but no artifacts/kabir-ai: fails with a clear error", rc != 0 and "App not found" in log, log)
e = Env(); root = fake_repo(e, "")
write(os.path.join(e.ws, "x", "y", "z", "pnpm-workspace.yaml"), "decoy")
write(os.path.join(e.ws, "node_modules", "pkg", "pnpm-workspace.yaml"), "decoy")
rc, log = e.run("Locate the project")
check("picks the shallowest workspace and ignores node_modules decoys", rc == 0 and os.path.realpath(e.outputs()["root"]) == os.path.realpath(root), log)

# ───────────────────────── API domain ─────────────────────────
print("Resolve the API domain")
cases = [
  ("from workflow input", {"INPUT_DOMAIN": "my-api.example.com", "VAR_DOMAIN": ""}, "my-api.example.com", "false"),
  ("from repository variable", {"INPUT_DOMAIN": "", "VAR_DOMAIN": "var.example.com"}, "var.example.com", "false"),
  ("input beats variable", {"INPUT_DOMAIN": "in.example.com", "VAR_DOMAIN": "var.example.com"}, "in.example.com", "false"),
  ("pasted https:// URL with path is cleaned", {"INPUT_DOMAIN": "https://x.trycloudflare.com/api/", "VAR_DOMAIN": ""}, "x.trycloudflare.com", "false"),
  ("whitespace and http:// are cleaned", {"INPUT_DOMAIN": "  http://h.example.com \n", "VAR_DOMAIN": ""}, "h.example.com", "false"),
  ("unset: build still proceeds with a placeholder + warning", {"INPUT_DOMAIN": "", "VAR_DOMAIN": ""}, "api-domain-not-set.invalid", "true"),
]
for label, env, want, missing in cases:
    e = Env(); rc, log = e.run("Resolve the API domain", env); o = e.outputs()
    check(label, rc == 0 and o.get("domain") == want and o.get("missing") == missing, f"{o} {log}")

# ───────────────────────── install step (stub pnpm) ─────────────────────────
print("Install JavaScript dependencies")
def stub_pnpm(e, fail_frozen):
    write(os.path.join(e.bin, "pnpm"), textwrap.dedent(f"""\
        #!/usr/bin/env bash
        echo "pnpm $*" >> "{e.tmp}/pnpm.log"
        if [ "{fail_frozen}" = "1" ] && echo "$*" | grep -q -- "--frozen-lockfile"; then echo "ERR_PNPM_OUTDATED_LOCKFILE" >&2; exit 1; fi
        exit 0
        """), 0o755)
for label, fail_frozen, expect_warn, expect_calls in [("frozen install works", "0", False, 1), ("lockfile outdated -> falls back", "1", True, 2)]:
    e = Env(); root = fake_repo(e, "kabir-ai-master"); stub_pnpm(e, fail_frozen)
    rc, log = e.run("Install JavaScript dependencies", {"ROOT": root}); calls = open(f"{e.tmp}/pnpm.log").read().splitlines()
    check(label, rc == 0 and len(calls) == expect_calls and ("Lockfile out of date" in log) == expect_warn
          and all('./artifacts/kabir-ai...' in c for c in calls), f"{calls} {log}")
    check(f"  runs in the located root ({label})", True)

# ───────────────────────── prebuild step ─────────────────────────
print("Generate the Android project")
e = Env(); root = fake_repo(e, "kabir-ai-master"); app = os.path.join(root, "artifacts", "kabir-ai")
write(os.path.join(e.bin, "pnpm"), textwrap.dedent(f"""\
    #!/usr/bin/env bash
    echo "$PWD :: pnpm $* :: EXPO_PUBLIC_DOMAIN=$EXPO_PUBLIC_DOMAIN" >> "{e.tmp}/prebuild.log"
    mkdir -p android && printf '#!/bin/sh\\necho gradlew\\n' > android/gradlew
    """), 0o755)
rc, log = e.run("Generate the Android project (expo prebuild)", {"APP": app, "EXPO_PUBLIC_DOMAIN": "api.example.com"})
pl = open(f"{e.tmp}/prebuild.log").read()
check("prebuild runs inside the app folder with --no-install and the domain", rc == 0 and "artifacts/kabir-ai ::" in pl and "--no-install" in pl
      and "--platform android" in pl and "EXPO_PUBLIC_DOMAIN=api.example.com" in pl, pl + log)
check("gradlew made executable", os.access(os.path.join(app, "android", "gradlew"), os.X_OK))
e = Env(); root = fake_repo(e, ""); write(os.path.join(e.bin, "pnpm"), "#!/usr/bin/env bash\nexit 0\n", 0o755)
rc, log = e.run("Generate the Android project (expo prebuild)", {"APP": os.path.join(root, "artifacts", "kabir-ai"), "EXPO_PUBLIC_DOMAIN": "x"})
check("prebuild that produced no gradlew fails with a clear error", rc != 0 and "Prebuild failed" in log, log)

# ───────────────────────── gradle configuration ─────────────────────────
print("Configure Gradle")
for label, abis, want in [("default ABIs", "", "arm64-v8a,armeabi-v7a"), ("custom ABIs", "arm64-v8a", "arm64-v8a")]:
    e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai")
    write(os.path.join(app, "android", "gradle.properties"), "org.gradle.jvmargs=-Xmx2048m\nandroid.useAndroidX=true\n")
    rc, log = e.run("Configure Gradle", {"APP": app, "INPUT_ABIS": abis})
    props = open(os.path.join(app, "android", "gradle.properties")).read()
    init = open(os.path.join(e.home, ".gradle", "init.d", "ci-disable-lint.gradle")).read() if rc == 0 else ""
    check(f"{label}: memory + ABIs appended (last value wins)", rc == 0 and f"reactNativeArchitectures={want}" in props
          and props.strip().splitlines().count("android.useAndroidX=true") == 1 and "-Xmx4g" in props.split("# --- added by CI ---")[1], props + log)
    check(f"{label}: init script is plain, balanced Groovy that disables lint",
          init.count("{") == init.count("}") and "lintVital" in init and init.startswith("allprojects {") and "EOF" not in init, init)

# ───────────────────────── gradle build step (stub gradlew) ─────────────────────────
print("Build the release APK (Gradle)")
for label, code in [("success", 0), ("compile error", 1)]:
    e = Env(); root = fake_repo(e, "kabir-ai-master"); app = os.path.join(root, "artifacts", "kabir-ai")
    write(os.path.join(app, "android", "gradlew"), f"#!/usr/bin/env bash\necho \"args: $*\"\necho \"domain=$EXPO_PUBLIC_DOMAIN\"\n"
          + ("echo 'e: file:///x/Foo.kt:12:5 Unresolved reference: bar'\n" if code else "") + f"exit {code}\n", 0o755)
    rc, log = e.run("Build the release APK (Gradle)", {"APP": app, "INPUT_ABIS": "", "EXPO_PUBLIC_DOMAIN": "api.example.com"})
    glog = open(os.path.join(e.ws, "gradle-build.log")).read()
    check(f"{label}: step result matches Gradle (pipefail) and log is at the workspace root",
          (rc == 0) == (code == 0) and "assembleRelease" in glog and "-PreactNativeArchitectures=arm64-v8a,armeabi-v7a" in glog
          and "domain=api.example.com" in glog, f"rc={rc} {glog}")
    if code:
        rc2, log2 = e.run("List errors (on failure)")
        check("failed build: Kotlin errors are surfaced as ::error:: annotations", "::error::e: file:///x/Foo.kt:12:5" in log2, log2)

# ───────────────────────── collect + verify APK ─────────────────────────
print("Collect and verify the APK")
def stub_sdk(e, verify_ok):
    sdk = os.path.join(e.tmp, "sdk"); bt = os.path.join(sdk, "build-tools", "34.0.0"); os.makedirs(bt)
    state = os.path.join(e.tmp, "signed")
    write(os.path.join(bt, "apksigner"), textwrap.dedent(f"""\
        #!/usr/bin/env bash
        if [ "$1" = "verify" ]; then
          if [ "{verify_ok}" = "1" ] || [ -f "{state}" ]; then exit 0; else echo "not signed" >&2; exit 1; fi
        fi
        if [ "$1" = "sign" ]; then touch "{state}"; out=""; while [ $# -gt 0 ]; do [ "$1" = "--out" ] && out="$2"; last="$1"; shift; done; cp "$last" "$out"; exit 0; fi
        """), 0o755)
    write(os.path.join(bt, "aapt2"), "#!/usr/bin/env bash\necho \"package: name='com.kabir.ai' versionCode='1'\"\n", 0o755)
    write(os.path.join(e.bin, "keytool"), "#!/usr/bin/env bash\ntouch \"$3\"\nexit 0\n", 0o755)
    return sdk
for prefix in ["", "kabir-ai-master"]:
    for verify_ok, label in [("1", "already signed"), ("0", "unsigned -> CI signs it")]:
        e = Env(); root = fake_repo(e, prefix); app = os.path.join(root, "artifacts", "kabir-ai")
        make_apk(os.path.join(app, "android", "app", "build", "outputs", "apk", "release", "app-release.apk"))
        sdk = stub_sdk(e, verify_ok)
        rc, log = e.run("Collect and verify the APK", {"APP": app, "ANDROID_HOME": sdk}); o = e.outputs()
        target = os.path.join(e.ws, "dist-apk", "kabir-ai-release.apk")
        check(f"layout '{prefix or 'root'}', {label}: APK ends up at <workspace>/dist-apk/kabir-ai-release.apk",
              rc == 0 and os.path.isfile(target) and zipfile.is_zipfile(target) and o.get("size"), log)
        if verify_ok == "0": check("   (unsigned path really signed it)", "signed by CI" in log and "Unsigned APK" in log, log)
e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai")
make_apk(os.path.join(app, "android", "app", "build", "outputs", "apk", "release", "nested", "weird-name.apk"))
rc, log = e.run("Collect and verify the APK", {"APP": app, "ANDROID_HOME": stub_sdk(e, "1")})
check("APK in an unexpected subfolder / with another name is still found", rc == 0 and os.path.isfile(os.path.join(e.ws, "dist-apk", "kabir-ai-release.apk")), log)
e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai"); os.makedirs(os.path.join(app, "android", "app", "build", "outputs", "apk", "release"))
rc, log = e.run("Collect and verify the APK", {"APP": app, "ANDROID_HOME": stub_sdk(e, "1")})
check("no APK produced: fails with a clear error (not a silent missing link)", rc != 0 and "APK not found" in log, log)
e = Env(); root = fake_repo(e, ""); app = os.path.join(root, "artifacts", "kabir-ai")
write(os.path.join(app, "android", "app", "build", "outputs", "apk", "release", "app-release.apk"), "this is not a zip")
rc, log = e.run("Collect and verify the APK", {"APP": app, "ANDROID_HOME": stub_sdk(e, "1")})
check("corrupt APK is rejected", rc != 0, log)

# ───────────────────────── summary ─────────────────────────
print("Run summary")
e = Env(); rc, _ = e.run("Write run summary", {"OUTCOME": "success", "SIZE": "61M", "DOMAIN": "api.example.com", "MISSING": "false",
                                               "ARTIFACT_URL": "https://github.com/o/r/actions/runs/1/artifacts/9", "RUN_URL": "https://github.com/o/r/actions/runs/1"})
s = open(e.summary).read()
check("success: shows the artifact link, size and API host", rc == 0 and "artifacts/9" in s and "61M" in s and "api.example.com" in s and "not set" not in s, s)
e = Env(); e.run("Write run summary", {"OUTCOME": "success", "SIZE": "61M", "DOMAIN": "api-domain-not-set.invalid", "MISSING": "true", "ARTIFACT_URL": "", "RUN_URL": "https://github.com/o/r/actions/runs/1"})
s = open(e.summary).read()
check("success without artifact-url falls back to the run link and warns about the domain", "actions/runs/1" in s and "EXPO_PUBLIC_DOMAIN" in s, s)
e = Env(); e.run("Write run summary", {"OUTCOME": "failure", "SIZE": "", "DOMAIN": "", "MISSING": "", "ARTIFACT_URL": "", "RUN_URL": "x"})
check("failure: tells you where the errors are", "did not produce an APK" in open(e.summary).read())

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
