# Build the APK with GitHub Actions

This project ships with a ready workflow: `.github/workflows/build-android-apk.yml`. It builds a standalone, installable APK
and publishes it as a downloadable **artifact** (and, for tags like `v1.0.0`, as a **GitHub Release** file).

## What went wrong before, and how it is fixed

| Error you saw | Real cause | Fix in this version |
|---|---|---|
| `ENOENT` / `Could not read package.json` | The workflow ran `npm`/`pnpm` at the repository root, but the app lives in `artifacts/kabir-ai/`, and the ZIP's own top folder added another level. | The workflow **finds** `pnpm-workspace.yaml` (up to 4 folders deep) and uses `<root>/artifacts/kabir-ai` from there, so it works wherever the files were uploaded. It stops with a clear message listing the folders if the project is truly missing. |
| Dependency install / node-cache failures ("missing lock files") | This project uses **pnpm**, with `pnpm-lock.yaml` at the project root. Caching or installing with npm/yarn keys looks for `package-lock.json` / `yarn.lock`, which don't exist. Also, the earlier master added a dependency without updating the lockfile, so a frozen install could not match. | No `cache:` key on setup-node; pnpm is installed explicitly (v10); the pnpm store is cached with a key that never fails; `pnpm-lock.yaml` is **updated** and verified against all 10 workspace projects; the install falls back to a normal install if the lockfile is ever out of date. |
| The `.apk` could not be found, so no download link | The uploader was given a path relative to a folder (or to the wrong folder) while Gradle writes to `artifacts/kabir-ai/android/app/build/outputs/apk/release/`. | The APK is **found by search** after the build, copied to `<workspace>/dist-apk/kabir-ai-release.apk`, verified (valid zip, signed), and uploaded from that fixed workspace path. The upload step fails loudly if the file is missing, and the run summary prints the download link. |

## Setup (5 minutes, once)

1. **Put the project in your repository** so that these exist (extract the ZIP first; GitHub does not unzip files):
   - `.github/workflows/build-android-apk.yml`
   - `pnpm-workspace.yaml`, `pnpm-lock.yaml`, `artifacts/`, `lib/`, …

   Best: use **git** or **GitHub Desktop** (`git add -A && git commit && git push`).
   Two traps with the website uploader: it accepts only **100 files per upload**, and the **hidden `.github` folder is often skipped** by drag-and-drop.
   If `.github` didn't arrive: on GitHub choose *Add file → Create new file*, type the name
   `.github/workflows/build-android-apk.yml`, and paste the contents of `github-workflow/build-android-apk.yml` (a visible copy included in the ZIP).
   If you uploaded the ZIP's contents inside a subfolder, that's fine for the build, **but the workflow file itself must still be at the repository root** (`.github/workflows/` at the top level) or GitHub will not see it.

2. **Set your API host.** Repository → *Settings → Secrets and variables → Actions → **Variables** tab → New repository variable*:
   Name `EXPO_PUBLIC_DOMAIN`, value = your API server's public HTTPS host, **host only**, e.g. `my-api.example.com`
   (no `https://`; the app talks HTTPS only). You can also type it when you start a run. The server must be running the code from this ZIP
   (it has new routes) with `OPENAI_API_KEY` set; see `BUILD_APK.md` §3 for tunnel/deploy options.

3. **Run it.** *Actions* tab → **Build Android APK** → **Run workflow**. (It also runs on pushes to `main`/`master`, and on tags `v*`.)
   The first run takes about **25–45 minutes** (it compiles React Native for two CPU types); later runs are faster thanks to caches.

4. **Download.** Open the finished run → the **summary** shows a download link, and the **Artifacts** section at the bottom lists
   **kabir-ai-apk**. Unzip it → `kabir-ai-release.apk`. Artifacts are kept 14 days. For a permanent link, push a tag
   (`git tag v1.0.0 && git push --tags`): the APK is attached to a GitHub **Release**.

5. **Install** on the phone: copy the APK over and open it (allow *install unknown apps*), or `adb install -r kabir-ai-release.apk`.
   Then follow `BUILD_APK.md` §7 (accessibility → *Allow restricted settings*, etc.).

## Options (when you press "Run workflow")
- **api_domain**: overrides the repository variable for this run.
- **abis**: default `arm64-v8a,armeabi-v7a` (every real phone). Use `arm64-v8a` alone for a faster, smaller build (phones from ~2017+).

## If a run fails
The workflow is built to tell you *why*:
1. Open the run → the red step shows the message. Compile errors from the native code are also listed as **annotations** at the top of the run page.
2. The full Gradle log is attached as artifact **build-logs**.
3. Send me those annotations (or the `build-logs` file). I'll fix the exact line.

## What is and isn't verified
- ✅ The workflow's shell logic was tested by running every step against simulated repositories (files at the root, inside a folder, two levels deep, missing lockfile, missing app, unsigned/odd APK locations, failed builds): **48 checks**.
- ✅ Lockfile verified against all workspace `package.json` files (so the frozen install matches).
- ✅ 117 app/server tests, and a line-by-line review of the native Kotlin for compile risks (5 version-sensitive constructs were made conservative).
- ❌ **I cannot run GitHub's servers or an Android compiler.** The first real run is the first time the Kotlin is compiled and the first time Expo generates the Android project here. I removed every failure I could predict, and the workflow makes any remaining failure visible and reportable, but I can't honestly promise "zero errors"; no one can without running it.
