package expo.modules.kabirscreenagent

/** Process-wide shared state between the capture service, accessibility service and JS module. */
object AgentState {
  @Volatile var accessibilityConnected = false
  @Volatile var captureRunning = false
  @Volatile var demonstrating = false   // "teach mode": user steps are being recorded
  @Volatile var demoCount = 0
  @Volatile var foregroundPackage: String? = null
  @Volatile var blockedPackages: Set<String> = emptySet()

  @Volatile var screenWidth = 0
  @Volatile var screenHeight = 0
  @Volatile var frameWidth = 0
  @Volatile var frameHeight = 0

  /** Bumped on every visual/window/content change. Lets callers wait for "the screen reacted" without polling content. */
  val changeSeq = java.util.concurrent.atomic.AtomicLong(0)

  @Volatile var lastFrameAt = 0L      // SystemClock.elapsedRealtime()
  @Volatile var lastChangeScore = 0f
  @Volatile var measuredFps = 0f
  @Volatile var lastOcrMs = 0L        // latency of last OCR pass
  @Volatile var ocrItems: List<OcrItem> = emptyList()
  @Volatile var ocrAt = 0L

  fun isForegroundBlocked(): Boolean = foregroundPackage?.let { it in blockedPackages } ?: false

  // Small in-memory audit trail of every action Kabir performed (never persisted, never sent anywhere).
  private val log = ArrayDeque<Map<String, Any?>>()

  @Synchronized
  fun logAction(kind: String, detail: String, ok: Boolean) {
    log.addLast(
      mapOf(
        "at" to System.currentTimeMillis(), "kind" to kind, "detail" to detail,
        "ok" to ok, "package" to foregroundPackage,
      ),
    )
    while (log.size > 200) log.removeFirst()
  }

  @Synchronized
  fun recentActions(): List<Map<String, Any?>> = log.toList()
}

object AgentEvents {
  @Volatile var sink: ((String, Map<String, Any?>) -> Unit)? = null

  fun emit(name: String, body: Map<String, Any?>) {
    try {
      sink?.invoke(name, body)
    } catch (_: Throwable) {
      // JS side may be reloading; never crash a service because of it.
    }
  }
}
