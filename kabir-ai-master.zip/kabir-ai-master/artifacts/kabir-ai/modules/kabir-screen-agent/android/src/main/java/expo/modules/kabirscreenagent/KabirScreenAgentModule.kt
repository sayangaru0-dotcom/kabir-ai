package expo.modules.kabirscreenagent

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.SystemClock
import java.util.Locale
import android.provider.Settings
import androidx.core.content.ContextCompat
import expo.modules.kotlin.Promise
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

private const val REQ_CAPTURE = 7341

private fun Map<String, Any?>?.int(key: String, def: Int) = (this?.get(key) as? Number)?.toInt() ?: def
private fun Map<String, Any?>?.long(key: String, def: Long) = (this?.get(key) as? Number)?.toLong() ?: def
private fun Map<String, Any?>?.float(key: String, def: Float) = (this?.get(key) as? Number)?.toFloat() ?: def
private fun Map<String, Any?>?.bool(key: String, def: Boolean) = (this?.get(key) as? Boolean) ?: def

class KabirScreenAgentModule : Module() {
  private var capturePromise: Promise? = null
  private var pendingOptions: Map<String, Any?>? = null

  private val context: Context
    get() = appContext.reactContext ?: throw IllegalStateException("React context unavailable")

  override fun definition() = ModuleDefinition {
    Name("KabirScreenAgent")

    Events("onFrameAnalysis", "onScreenChanged", "onServiceState", "onAgentError")

    OnCreate { AgentEvents.sink = { name, body -> sendEvent(name, body) } }
    OnDestroy { AgentEvents.sink = null }

    // ── Setup & status ─────────────────────────────────────────────

    Function("getStatus") {
      val now = SystemClock.elapsedRealtime()
      mapOf(
        "apiLevel" to Build.VERSION.SDK_INT,
        "ownPackage" to context.packageName,
        "accessibilityEnabled" to (KabirAccessibilityService.instance != null),
        "captureRunning" to AgentState.captureRunning,
        "foregroundPackage" to AgentState.foregroundPackage,
        "screenWidth" to screenSize().first, "screenHeight" to screenSize().second,
        "demonstrating" to AgentState.demonstrating, "demoEventCount" to AgentState.demoCount,
        "frameWidth" to AgentState.frameWidth, "frameHeight" to AgentState.frameHeight,
        "fps" to AgentState.measuredFps,
        "lastFrameAgeMs" to if (AgentState.lastFrameAt == 0L) null else now - AgentState.lastFrameAt,
        "lastOcrMs" to AgentState.lastOcrMs,
        "ocrItemCount" to AgentState.ocrItems.size,
      )
    }

    Function("openAccessibilitySettings") {
      context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    Function("setBlockedPackages") { packages: List<String> ->
      AgentState.blockedPackages = packages.toSet()
    }

    Function("getActionLog") { AgentState.recentActions() }

    /** Monotonic counter that increases whenever the screen visibly changes (see AgentState.changeSeq). */
    Function("getChangeSeq") { AgentState.changeSeq.get() }

    /** Sends Kabir to the background so the app the user was in is on screen again. */
    Function("minimizeApp") {
      val activity = appContext.currentActivity
      activity?.runOnUiThread { activity.moveTaskToBack(true) }
      activity != null
    }

    /** Launches an installed app by its launcher label (fuzzy). Refuses apps on the blocklist. */
    Function("openApp") { name: String ->
      val pm = context.packageManager
      @Suppress("DEPRECATION")
      val apps = pm.queryIntentActivities(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0,
      )
      val q = name.trim().lowercase(Locale.ROOT)
      var bestPkg: String? = null
      var bestLabel = ""
      var bestScore = 0f
      for (ri in apps) {
        val label = ri.loadLabel(pm).toString()
        val l = label.lowercase(Locale.ROOT)
        val s = when {
          l == q -> 1f
          l.startsWith(q) -> 0.85f
          l.contains(q) -> 0.7f
          l.length >= 3 && q.contains(l) -> 0.6f
          else -> 0f
        }
        if (s > bestScore) { bestScore = s; bestPkg = ri.activityInfo.packageName; bestLabel = label }
      }
      val pkg = bestPkg
      when {
        pkg == null -> mapOf("ok" to false, "reason" to "app_not_found")
        pkg in AgentState.blockedPackages -> mapOf("ok" to false, "reason" to "blocked_app")
        else -> {
          val launch = pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          if (launch == null) {
            mapOf("ok" to false, "reason" to "not_launchable")
          } else {
            // Prefer the accessibility service context: it is allowed to start activities while Kabir is in the background.
            (KabirAccessibilityService.instance ?: context).startActivity(launch)
            AgentState.logAction("openApp", pkg, true)
            mapOf("ok" to true, "package" to pkg, "label" to bestLabel)
          }
        }
      }
    }

    // ── Capture lifecycle ──────────────────────────────────────────

    AsyncFunction("requestScreenCapture") { options: Map<String, Any?>?, promise: Promise ->
      val activity = appContext.currentActivity
      if (activity == null) {
        promise.reject("E_NO_ACTIVITY", "No foreground activity to show the screen capture prompt.", null)
      } else if (capturePromise != null) {
        promise.reject("E_BUSY", "A screen capture request is already pending.", null)
      } else {
        capturePromise = promise
        pendingOptions = options
        activity.runOnUiThread {
          val mpm = activity.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
          activity.startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
        }
      }
    }

    OnActivityResult { _, payload ->
      if (payload.requestCode != REQ_CAPTURE) return@OnActivityResult
      val promise = capturePromise ?: return@OnActivityResult
      capturePromise = null
      val data = payload.data
      if (payload.resultCode == Activity.RESULT_OK && data != null) {
        val o = pendingOptions
        val intent = Intent(context, ScreenCaptureService::class.java).apply {
          action = ScreenCaptureService.ACTION_START
          putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, payload.resultCode)
          putExtra(ScreenCaptureService.EXTRA_DATA, data)
          putExtra(ScreenCaptureService.EXTRA_MAX_DIM, o.int("maxFrameDimension", 720))
          putExtra(ScreenCaptureService.EXTRA_FPS, o.int("targetFps", 8))
          putExtra(ScreenCaptureService.EXTRA_OCR, o.bool("ocr", true))
          putExtra(ScreenCaptureService.EXTRA_DEVA, o.bool("devanagari", false))
          putExtra(ScreenCaptureService.EXTRA_CHANGE, o.float("changeThreshold", 0.02f))
          putExtra(ScreenCaptureService.EXTRA_OCR_INTERVAL, o.long("ocrMinIntervalMs", 400L))
        }
        ContextCompat.startForegroundService(context, intent)
        promise.resolve(true)
      } else {
        promise.resolve(false) // user declined
      }
      pendingOptions = null
    }

    Function("stopScreenCapture") {
      context.stopService(Intent(context, ScreenCaptureService::class.java))
    }

    // ── Reading the screen ─────────────────────────────────────────

    Function("getScreenSnapshot") { options: Map<String, Any?>? ->
      val svc = KabirAccessibilityService.instance
      val now = SystemClock.elapsedRealtime()
      mapOf(
        "foregroundPackage" to AgentState.foregroundPackage,
        "screenWidth" to screenSize().first, "screenHeight" to screenSize().second,
        "nodes" to if (options.bool("includeNodes", true)) (svc?.snapshot()?.map { it.toMap() } ?: emptyList()) else emptyList(),
        "ocr" to if (options.bool("includeOcr", true)) AgentState.ocrItems.map { it.toMap() } else emptyList(),
        "ocrAgeMs" to if (AgentState.ocrAt == 0L) null else now - AgentState.ocrAt,
      )
    }

    Function("findTargets") { query: String, options: Map<String, Any?>? ->
      resolve(query, options.long("maxOcrAgeMs", 1500)).map { it.toMap() }
    }

    // ── Virtual touch ──────────────────────────────────────────────

    AsyncFunction("tap") { x: Double, y: Double, promise: Promise ->
      withService(promise) { svc ->
        svc.gestureTap(x.toFloat(), y.toFloat(), 50) { ok, err -> finish(promise, ok, err) }
      }
    }

    AsyncFunction("longPress") { x: Double, y: Double, durationMs: Double?, promise: Promise ->
      withService(promise) { svc ->
        svc.gestureTap(x.toFloat(), y.toFloat(), (durationMs ?: 700.0).toLong().coerceAtLeast(501)) { ok, err -> finish(promise, ok, err) }
      }
    }

    AsyncFunction("swipe") { x1: Double, y1: Double, x2: Double, y2: Double, durationMs: Double?, promise: Promise ->
      withService(promise) { svc ->
        svc.gestureSwipe(x1.toFloat(), y1.toFloat(), x2.toFloat(), y2.toFloat(), (durationMs ?: 300.0).toLong()) { ok, err -> finish(promise, ok, err) }
      }
    }

    /** Find text on screen (accessibility tree + OCR) and tap its exact centre. */
    AsyncFunction("tapText") { query: String, options: Map<String, Any?>?, promise: Promise ->
      withService(promise) { svc ->
        val minConf = options.float("minConfidence", 0.6f)
        val best = resolve(query, options.long("maxOcrAgeMs", 1500)).firstOrNull()
        if (best == null || best.confidence < minConf) {
          promise.resolve(mapOf("ok" to false, "reason" to "not_found", "confidence" to (best?.confidence ?: 0f)))
        } else if (options.bool("preferNodeAction", false) && svc.clickNodeAt(best.x, best.y)) {
          promise.resolve(result(true, null, best))
        } else {
          svc.gestureTap(best.x, best.y, 50) { ok, err -> promise.resolve(result(ok, err, best)) }
        }
      }
    }

    /** direction: "up" | "down" | "left" | "right" = which way the CONTENT moves to reveal more. */
    AsyncFunction("scroll") { direction: String, promise: Promise ->
      withService(promise) { svc ->
        val (sw, sh) = screenSize()   // real size: must work even when screen capture is off
        val w = sw.toFloat()
        val h = sh.toFloat()
        val (cx, cy) = w / 2f to h / 2f
        val (x1, y1, x2, y2) = when (direction) {
          "down" -> listOf(cx, h * 0.7f, cx, h * 0.3f)   // finger up  -> see content below
          "up" -> listOf(cx, h * 0.3f, cx, h * 0.7f)
          "right" -> listOf(w * 0.75f, cy, w * 0.25f, cy)
          "left" -> listOf(w * 0.25f, cy, w * 0.75f, cy)
          else -> { promise.reject("E_ARG", "direction must be up|down|left|right", null); return@withService }
        }
        svc.gestureSwipe(x1, y1, x2, y2, 350) { ok, err -> finish(promise, ok, err) }
      }
    }

    AsyncFunction("typeText") { text: String, append: Boolean?, promise: Promise ->
      withService(promise) { svc ->
        val err = svc.setFocusedText(text, append ?: false)
        promise.resolve(mapOf("ok" to (err == null), "reason" to err))
      }
    }

    /** Two-finger pinch. spans are in px: start > end = pinch in (zoom out), start < end = spread (zoom in). */
    AsyncFunction("pinch") { cx: Double, cy: Double, startSpan: Double, endSpan: Double, durationMs: Double?, promise: Promise ->
      withService(promise) { svc ->
        svc.gesturePinch(cx.toFloat(), cy.toFloat(), startSpan.toFloat(), endSpan.toFloat(), (durationMs ?: 400.0).toLong()) { ok, err -> finish(promise, ok, err) }
      }
    }

    /** Presses the keyboard's Search/Go/Enter key on the focused field (Android 11+). */
    Function("pressEnter") {
      val svc = KabirAccessibilityService.instance
      if (svc == null) {
        mapOf("ok" to false, "reason" to "accessibility_off")
      } else {
        val err = svc.pressEnter()
        mapOf("ok" to (err == null), "reason" to err)
      }
    }

    // ── Teach mode: learn a routine from the user's own demonstration ──

    AsyncFunction("startDemonstration") { promise: Promise ->
      withService(promise) { svc ->
        svc.startDemonstration()
        promise.resolve(true)
      }
    }

    /** Stops recording and returns (and clears) the recorded events. Safe to call when not recording. */
    AsyncFunction("stopDemonstration") { promise: Promise ->
      val svc = KabirAccessibilityService.instance
      if (svc != null) svc.stopDemonstration() else DemoRecorder.stop()
      promise.resolve(DemoRecorder.take())
    }

    AsyncFunction("globalAction") { name: String, promise: Promise ->
      withService(promise) { svc -> promise.resolve(mapOf("ok" to svc.global(name))) }
    }
  }

  // ───────────────────────────── helpers ─────────────────────────────

  private fun screenSize(): Pair<Int, Int> = ScreenMetrics.realSize(context)

  private fun resolve(query: String, maxOcrAgeMs: Long): List<Target> {
    val nodes = KabirAccessibilityService.instance?.snapshot() ?: emptyList()
    val fresh = AgentState.captureRunning && AgentState.ocrAt != 0L &&
      SystemClock.elapsedRealtime() - AgentState.ocrAt <= maxOcrAgeMs
    return TargetResolver.find(query, nodes, if (fresh) AgentState.ocrItems else emptyList())
  }

  private inline fun withService(promise: Promise, block: (KabirAccessibilityService) -> Unit) {
    val svc = KabirAccessibilityService.instance
    if (svc == null) {
      promise.reject("E_A11Y_OFF", "Kabir's Accessibility Service is not enabled. Call openAccessibilitySettings().", null)
    } else {
      try { block(svc) } catch (t: Throwable) { promise.reject("E_ACTION", t.message, t) }
    }
  }

  private fun finish(promise: Promise, ok: Boolean, err: String?) =
    promise.resolve(mapOf("ok" to ok, "reason" to err))

  private fun result(ok: Boolean, err: String?, t: Target) = mapOf(
    "ok" to ok, "reason" to err, "x" to t.x, "y" to t.y,
    "source" to t.source, "label" to t.label, "confidence" to t.confidence,
  )
}
