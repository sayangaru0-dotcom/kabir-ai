# File map: every native (Kotlin) and app file

This master contains everything below, already integrated (no patches to apply).


## 2. Native code: Kotlin files (there are no Java files)

All native code is Kotlin and lives in one folder. This folder is auto-linked as a local Expo module:
`artifacts/kabir-ai/modules/kabir-screen-agent/` (nothing to register).

`…/android/src/main/java/expo/modules/kabirscreenagent/`

| File | Lines | Status vs. previous delivery | What it does |
|---|---:|---|---|
| `KabirAccessibilityService.kt` | 310 | **UPDATED** | UI-tree reading, tap/long-press/swipe, **+ pinch, + IME Enter, + teach-mode start/stop & notification** |
| `DemoRecorder.kt` | 124 | **NEW** | Records the user's own taps/scrolls/typing as replayable events (password-safe, capped, in memory) |
| `DemoStopReceiver.kt` | 12 | **NEW** | Handles the Stop button of the "recording your steps" notification |
| `KabirScreenAgentModule.kt` | 311 | **UPDATED** | JS bridge: **+ pinch, pressEnter, start/stopDemonstration; fixed screen size (scroll no longer needs capture running)** |
| `AgentState.kt` | 57 | **UPDATED** | Shared state: **+ demonstrating / demoCount flags** |
| `Models.kt` | 122 | **UPDATED** | **Bounds now include width/height** (the JS side relies on it) |
| `ScreenCaptureService.kt` | 273 | unchanged | Screen capture foreground service |
| `FrameAnalyzer.kt` | 168 | unchanged | Change detection + on-device OCR |
| `TargetResolver.kt` | 95 | unchanged | Fuses accessibility nodes + OCR into tap coordinates |

Non-Kotlin native files (same folder tree, also replaced by the folder swap):

| File | Status |
|---|---|
| `android/src/main/AndroidManifest.xml` | **UPDATED**: + `DemoStopReceiver`, + `<queries>` for launcher apps (done in the previous delivery) |
| `android/src/main/res/values/strings.xml` | **UPDATED**: + teach-mode notification strings |
| `android/src/main/res/xml/kabir_accessibility_config.xml`, `android/build.gradle`, `expo-module.config.json` | unchanged |
| `index.ts` (JS bindings) | **UPDATED**: + `pinch`, `pressEnter`, `startDemonstration`, `stopDemonstration`, `DemoEvent`, `Bounds.width/height` |

## 3. App + server files (all NEW or UPDATED; copy as-is)

| Path (under `artifacts/`) | Status | Purpose |
|---|---|---|
| `kabir-ai/lib/workflows/youtube.ts`, `index.ts`, `types.ts` | NEW | **YouTube search-and-play** (adaptive, with fallbacks) + workflow registry |
| `kabir-ai/lib/learning/recipe.ts` | NEW | Recipe model, `{{param}}` templating, plain-language step descriptions |
| `kabir-ai/lib/learning/demo-to-steps.ts` | NEW | Turns a recorded demonstration into a routine |
| `kabir-ai/lib/learning/tutorial-learner.ts` | NEW | Tutorial text → draft routine; self-repair proposals |
| `kabir-ai/lib/learning/recipe-store.ts` | NEW | Saves routines on the phone (re-validated on every read) |
| `kabir-ai/lib/learning/run-recipe.ts` | NEW | Supervised run: approval, sensitive-action guard, success/failure tracking |
| `kabir-ai/lib/screen-commands/steps.ts` | UPDATED | + `tapAt, dragAt, pinch, pressEnter, boardMove, workflow` |
| `kabir-ai/lib/screen-commands/executor.ts` | UPDATED | Runs the new steps (incl. board moves) |
| `kabir-ai/lib/screen-commands/grid.ts` | NEW | Board detection + square→pixel math |
| `kabir-ai/lib/screen-commands/approval.ts` | NEW | Shared confirm dialogs (moved out of the hook) |
| `kabir-ai/lib/screen-commands/planner.ts`, `precise-touch.ts` | UPDATED | Recipe calls; `waitFor` helper |
| `kabir-ai/hooks/useVoiceCommands.ts` | UPDATED | Voice can now call saved routines |
| `kabir-ai/hooks/useWorkflows.ts` | NEW | Teach / learn / run / repair for the UI |
| `kabir-ai/app/routines.tsx` | NEW | The **Routines** screen |
| `api-server/src/routes/step-schema.ts` | NEW | Server-side step whitelist (single source of truth) |
| `api-server/src/routes/command.ts` | UPDATED | Planner: new steps, YouTube rule, saved-routine calls |
| `api-server/src/routes/learn-workflow.ts` | NEW | `/api/kabir/learn-workflow` (learn from text, repair) |


## 5. What you can do now

**YouTube (autonomous).** Say "play lofi hip hop beats on YouTube". The planner emits one step,
`workflow youtube.searchPlay`, which: opens YouTube → finds the search entry → taps it → types the query through the
accessibility service → submits (keyboard Enter on Android 11+, otherwise taps the matching suggestion) → picks the
result whose text best matches your words (skipping ads and Shorts; falls back to the top result and says so) →
waits for the list to stop moving → taps it → checks a player appeared.

**Teach by showing (most reliable learning path).** Routines → *Start teaching*, do the task in your apps, come back →
*Finish*. Labelled taps become `tapText`, typed text becomes a parameter, scroll bursts become one scroll.
**Learn from a tutorial.** Paste a transcript / notes / article → a *draft* routine. **Run it by voice**: "run my lofi
routine for jazz".

**Self-learning loop.** Every routine starts as *draft*: you see a plain-language step list and approve it before
the first run. A full successful run marks it *verified*. Two failures in a row (the app's UI changed) mark it
*needs repair*; with the opt-in label sharing, Kabir proposes replacement steps and asks before saving a new revision.

## 6. Safety model (unchanged principles, extended)
- Every step, from the LLM, a tutorial, storage or a demonstration, goes through the same whitelist, on both server and app.
- Sensitive labels (pay/delete/reset/allow/install/sign-out…) always need your confirmation, upfront and again at tap time.
- Teach mode: persistent notification with Stop; extra accessibility events are enabled **only while recording**;
  password fields are never recorded or replayed; Kabir's own screens, system UI and blocked apps are ignored;
  600 events / 10 minutes max; in memory until you save.
- Tutorial text and screen labels are sent to the model only as data, with prompts that say so; labels are opt-in.

## 7. Honest limits
- **Not verified on a device.** The Kotlin has not been compiled (no Android SDK here) and the YouTube labels/layout were
  never checked against the real app. The workflow matches by meaning (search/"play video"/ad words) instead of fixed
  labels, with a precise failure reason per stage (`search_not_found`, `no_results`, …), but expect tuning on real phones.
- **Tutorial *videos*:** Kabir learns from text (transcript, notes, article) or from your demonstration. It does not download
  or watch video. (A video-capable pipeline would be a separate feature.) Learning from a transcript means guessing button
  names: that is why drafts need approval + a supervised first run, and why teach-by-showing is preferred.
- **Chess:** `boardMove` executes moves that a lesson *explicitly gives*, on a board it can detect through accessibility
  bounds (canvas/WebView boards need another route). There is no engine and no position recognition, so it cannot work out
  tactics itself. Use it for puzzles, practice, analysis boards and replaying lessons. Don't use it for live games where
  assistance is prohibited; that is cheating, and platforms ban accounts for it.
- Orientation (`white`/`black` at the bottom) is part of the step; wrong orientation = wrong squares.
- Enter-key submit needs Android 11+; older versions use the suggestion-tap fallback.
- Running from the background depends on the capture service keeping the process alive (see the voice-commands notes).
- AccessibilityService use for automation is restricted on Google Play (fine for sideloading/testing).


## Added in the master (beyond the earlier packages)
| File | Change |
|---|---|
| `artifacts/kabir-ai/lib/error-monitor.ts` | UPDATED: 6 new diagnosis rules (screen access, permissions, blocked app, not found, routine repair, module missing) |
| `artifacts/kabir-ai/lib/screen-commands/diagnostics.ts` | NEW: reports automation problems to the diagnostic history (skips user cancels/declines) |
| `artifacts/kabir-ai/hooks/useVoiceCommands.ts`, `useWorkflows.ts`, `useScreenAgent.ts` | UPDATED: report problems to diagnostics |
| `artifacts/kabir-ai/app/routines.tsx` | UPDATED: **Start/Stop screen reading** card |
| `artifacts/kabir-ai/app.json`, `package.json` | UPDATED: Android package name; `expo-modules-core` dependency |
| `tools/check-env.sh`, `tools/build-apk.sh`, `BUILD_APK.md` | NEW: preflight and build tooling |
| `tests/client/run-tests3.js` | NEW: diagnostics tests |
