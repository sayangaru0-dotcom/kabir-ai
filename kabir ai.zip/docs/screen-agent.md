> **Reference document.** Any install/patch steps below are already applied in this master; use `BUILD_APK.md` to build.

# Kabir Screen Agent (Android native module)

Screen capture → on-device OCR/change detection → exact pixel coordinates → injected touch.
Drop-in for your repo: unzip at the repo root (`HTML-CSS-JS-Starter/`); files land in
`artifacts/kabir-ai/modules/kabir-screen-agent/` and `artifacts/kabir-ai/hooks/useScreenAgent.ts`.

> **Not compiled or run yet.** I had no Android SDK here. Expect to fix a few compile errors on first build
> (most likely the Gradle plugin line, see Troubleshooting).

## Install
```bash
cd artifacts/kabir-ai
npx expo prebuild --platform android --clean
npx expo run:android            # development build; Expo Go cannot load native modules
```
Expo autolinks anything under `modules/` that has an `expo-module.config.json`. Manifest entries, permissions and
resources are merged from the module automatically; `app.json` needs no change.

## First-run flow (user must do both; Android forbids skipping them)
1. `openAccessibilitySettings()` → Installed apps → *Kabir screen assistant* → turn on.
2. `startScreenCapture({ targetFps: 8, maxFrameDimension: 720 })` → approve the system prompt.
   A persistent notification with a **Stop** button appears while capture is on.

## Usage
```ts
import * as Agent from "@/modules/kabir-screen-agent";

Agent.setBlockedPackages(["com.your.bank.app", "com.google.android.apps.authenticator2"]); // invisible + untouchable

const [best] = Agent.findTargets("Send");            // { x, y, source, confidence, bounds }
await Agent.tap(best.x, best.y);                     // exact float pixels
await Agent.tapText("Continue", { minConfidence: 0.7 });
await Agent.typeText("hello");                       // focused field; password fields refused
await Agent.scroll("down");
await Agent.globalAction("back");

Agent.addScreenAgentListener("onScreenChanged", e => { /* visual | window | content */ });
Agent.getActionLog();                                // audit trail of everything Kabir did
```

## How it works
| Stage | Where | Cost |
|---|---|---|
| Frame grab (MediaProjection → VirtualDisplay → ImageReader, downscaled, stale frames dropped) | `ScreenCaptureService` | ~ms |
| Change detection (32×56 luminance grid diff) | `FrameAnalyzer.changeScore` | well under 1–2 ms |
| OCR (ML Kit, on-device, async, only when screen changed) | `FrameAnalyzer.runOcr` | **~50–300 ms** device-dependent |
| Coordinates: `screen = frame × (screenSize / frameSize)`, box centre in float px | `CoordinateMapper` | ~µs |
| Fusion: accessibility node bounds (exact) + OCR boxes snapped to the clickable node under them | `TargetResolver` | ~ms |
| Tap / swipe injection | `KabirAccessibilityService.dispatchGesture` | ~10–50 ms |

Honest expectations: change detection is millisecond-fast; OCR is not. For screens with standard UI, accessibility
nodes give exact bounds with no OCR at all. A custom UI-element detector (TFLite/ONNX) can be added later inside
`FrameAnalyzer.process`; `CoordinateMapper` and `TargetResolver` already accept any box source.

## Built-in safeguards (please keep them)
- Visible foreground notification + Stop button; ends when the app is swiped away; the OS "stop sharing" chip also works.
- Frames live in memory only: no disk writes, no network code anywhere in the module.
- Password fields: text never read, never typed into.
- `setBlockedPackages`: matching foreground apps return no UI tree, no OCR, and reject gestures. Persist your list in app
  storage and re-apply on launch. It relies on the Accessibility Service to know the foreground app.
- Secure windows (`FLAG_SECURE`, e.g. many banking apps) are blank in captures by OS design.
- `getActionLog()` keeps the last 200 actions.

## Limits
- Android only (iOS has no equivalent API). Android 7.0+ for gestures; capture works from 5.0 but this code targets modern foreground-service rules (Android 14 tested in design only).
- ML Kit text models: Latin and Devanagari only. **No Bengali OCR**; for Bengali screens rely on accessibility nodes.
- Google Play restricts non-accessibility use of AccessibilityService; fine for sideloading/testing, but plan for the policy declaration before a Play release.
- Some games/WebViews expose no nodes and block gestures on certain surfaces; OCR path covers reading, taps may still be ignored by anti-bot protections.

## Troubleshooting
- `Plugin 'expo-module-gradle-plugin' not found`: your SDK's module template differs. Copy the `build.gradle` header from
  `npx create-expo-module@latest --local` and keep the `dependencies {}` block.
- `E_A11Y_OFF` → service not enabled (some OEMs auto-disable it; re-enable and exempt the app from battery optimisation).
- `SecurityException` on capture start (Android 14) → the permission result can be used once; call `startScreenCapture` again.
- Taps land offset → check `getStatus().screenWidth/Height` equals the device's real resolution.

## v2 additions
`openApp(name)` launch by launcher label (blocklist-aware) · `minimizeApp()` step aside to the previous app ·
`getChangeSeq()` counter that advances whenever the screen visibly changes (used to verify taps and wait for settle) ·
`getStatus().ownPackage`. See `kabir-voice-commands/` for the voice → action layer built on these.
