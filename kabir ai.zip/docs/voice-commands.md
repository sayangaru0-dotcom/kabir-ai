> **Reference document.** Any install/patch steps below are already applied in this master; use `BUILD_APK.md` to build.

# Kabir voice commands → screen actions

Turns "Hey Kabir, open Settings and turn on Wi-Fi" into real taps and scrolls, using the Screen Agent module.
Requires `kabir-screen-agent` (updated in this delivery: adds `openApp`, `minimizeApp`, `getChangeSeq`).

## Install
```bash
# from the repo root (HTML-CSS-JS-Starter/)
unzip kabir-screen-agent.zip -d .          # updated native module (overwrites the earlier version)
unzip kabir-voice-commands.zip -d .        # new files
patch -p1 < patches/kabir-voice-commands.patch
cd artifacts/kabir-ai && npx expo prebuild --platform android --clean && npx expo run:android
```
The patch touches 4 existing files: `index.tsx` (dashboard), `routes/index.ts`, `routes/kabir.ts` (2 `export`s),
`api-client-react/src/index.ts` (exports `customFetch`). It was dry-run against your original files and applies cleanly.
If the Screen Agent's Accessibility Service is **off**, nothing changes: the dashboard keeps using the old voice flow.

## How one command runs
```
voice → transcribe → POST /api/kabir/command ──(one LLM call)──► { kind, speak, steps[], audio }
   kind "chat"   → speak/play the answer (same as before)
   kind "screen" → validate steps (whitelist) → confirm sensitive ones → say "Opening Wi-Fi settings"
                 → minimize Kabir → run steps:  openApp → scrollUntilVisible → tapText → …
```
Each step is **precise and verified** (`lib/screen-commands/precise-touch.ts`):
1. `findTargets` fuses accessibility nodes + OCR into exact float pixel coordinates.
2. **Stability check:** resolve twice ~60 ms apart; tap only when both agree within 6 px (no taps on moving UI).
3. Tap through `dispatchGesture` at that point.
4. **Verify:** the native `changeSeq` counter must advance (screen reacted). If a clickable control ignored the touch,
   retry once with a semantic `ACTION_CLICK`.
5. Between steps it waits until the screen is quiet (adaptive), not a fixed sleep.
`scrollUntilVisible` scrolls, waits for settle, and stops at "end of content" (two scrolls that change nothing).

## Safety model (important)
- The LLM output is **untrusted**. Server and client both validate against a fixed whitelist
  (`openApp, global, tapText, longPressText, scroll, scrollUntilVisible, typeText, waitForText, wait`).
  One invalid step rejects the whole plan; unknown types, extra fields, >25 steps, bad enums are refused.
- **Sensitive actions** (pay/buy/transfer, delete/erase/reset/uninstall, allow/grant/install, sign-out; Hindi + Bengali terms too)
  always need your tap on "Continue": once up front for the plan, and again at run time for the label that is *actually*
  about to be tapped (so "OK" that resolves to "Delete all" still asks). No confirm callback = refused.
- Screen text is never sent to the cloud by default. `useVoiceCommands({ shareScreenLabels: true })` enables one
  re-plan after a failure that sends up to 60 visible labels; the prompt marks them as data, not instructions.
  Expose this as a Settings toggle before enabling it for users.
- Blocked apps (`setBlockedPackages`) can't be opened, read or touched. Password fields are never read or typed into.
- Cancel any time: `voiceCommands.cancel()` (wire to a button) or the notification's Stop; 90 s hard time limit.

## Tested here vs. not
- ✅ TypeScript type-checks (against stubs for React Native/Expo).
- ✅ 28 logic tests running the real validator, sensitivity guard, precise-tap and executor against a mocked phone
  (stability wait, verify + node-click retry, scroll-to-find, end-of-list, refuse/confirm, cancel, minimize-first).
- ✅ 10 tests of the `/kabir/command` route with a mocked OpenAI client (bad plans downgraded to chat, 400s on bad input).
- ❌ **Not run:** the Kotlin (no Android SDK here), anything on a real device, and real LLM plan quality.

## Known limits
- **Background execution:** Kabir steps aside, so its JS keeps driving the steps from the background. Keep screen capture
  running (its foreground service keeps the process alive) or Android may throttle long plans. A fully native executor
  would remove this; say if you want it.
- Kabir's confirmation audio can be cut when it backgrounds; it waits ~0.4 s + 55 ms/char first to limit that.
- `openApp` matches launcher labels (device language). Starting an app from the background may be blocked by some OEMs.
- Label language: the planner is told the phone's UI language; wrong guesses show up as `not_found`.
- Bengali screens: no OCR, so only accessibility-tree text is matched.
- Sensitive-word list is a safety net, not a guarantee; tune `SENSITIVE_*` in `steps.ts`.
