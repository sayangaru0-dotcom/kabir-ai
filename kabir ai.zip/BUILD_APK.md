# Build and install Kabir AI on your Android phone

You will: set up tools once → extract the master ZIP → start the API server → build the APK → install it → test.
**Time:** about 45–90 minutes the first time (most of it downloads). **Disk:** about 10 GB free.
**Computer:** macOS or Linux is simplest. On Windows use **WSL2 (Ubuntu)** and follow the Linux steps; native-Windows
commands are in the box at the end of step 5.

> **Read this first.** The app's Kotlin code (screen reading, touch, routines) has never been compiled; I had no Android
> SDK when writing it. The JavaScript/TypeScript side is covered by 117 automated tests (`bash tests/run-all.sh`), but the
> first Android build is where any remaining native error will show. Section 9 explains how to capture and send me
> the error if that happens. That is normal for a first build, not a sign you did something wrong.

---

> **Don't want to install Android tools?** Build in the cloud with GitHub Actions instead: see **`GITHUB_ACTIONS.md`**
> (ready-made workflow included; you only set one variable and click *Run workflow*). The rest of this file is for building on your own computer.

---

## 1. Install the tools (one time)

| Tool | Version | Get it |
|---|---|---|
| Node.js | 22 or 24 (LTS) | https://nodejs.org |
| pnpm | 9.5 or newer (10 is fine) | `npm i -g pnpm` |
| JDK | **17** (Temurin) | https://adoptium.net |
| Android Studio | current | https://developer.android.com/studio |

Then in **Android Studio → More Actions → SDK Manager**:
- *SDK Platforms:* tick the newest **Android API level** shown (Gradle downloads exact versions it needs later).
- *SDK Tools:* tick **Android SDK Build-Tools**, **Android SDK Command-line Tools (latest)**, **Android SDK Platform-Tools**, **NDK (Side by side)**, then **Apply**.

Set the environment variables (add to `~/.zshrc` or `~/.bashrc`, then open a new terminal):
```bash
# macOS
export ANDROID_HOME="$HOME/Library/Android/sdk"
# Linux / WSL2:  export ANDROID_HOME="$HOME/Android/Sdk"
export PATH="$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin"
```
Accept the Android licenses (type `y` when asked, or `yes |` to answer all):
```bash
yes | sdkmanager --licenses
```

**Your phone:** Settings → About phone → tap **Build number** 7 times → back → **Developer options** → turn on **USB debugging**.

## 2. Extract the master ZIP

```bash
unzip kabir-ai-master.zip
cd kabir-ai-master
```
Everything below is run from this folder (the "project root", where `package.json` and `tools/` live).

## 3. Start the API server (the app needs it)

The app sends your voice to a small server, which calls OpenAI. The app talks to it over **HTTPS** only, and the address is
fixed into the APK when you build it. You need one public HTTPS address. Pick **one** option.

**Option A: run it on your computer + a free tunnel (fastest for testing)**
```bash
pnpm install --no-frozen-lockfile
export OPENAI_API_KEY="sk-...your key..."
export PORT=5000
pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/api-server run start        # leave this terminal open
```
In a **second terminal**, expose it:
```bash
# install once: macOS `brew install cloudflared` · Windows `winget install Cloudflare.cloudflared` · Linux: https://github.com/cloudflare/cloudflared/releases
cloudflared tunnel --url http://localhost:5000
```
It prints an address like `https://random-words.trycloudflare.com`. Your **API host** is the part after `https://`:
`random-words.trycloudflare.com`. Keep both terminals running while you test.
> A free tunnel gets a **new address every time you restart it**, and the APK has the address baked in, so after a
> restart you must rebuild the APK (or use a stable address: a named Cloudflare tunnel, or Option B).

**Option B: you already host the server (for example on Replit)**
Use that host name (for example `your-app.replit.app`). **You must redeploy the server from this master first**, because it
now has new routes (`/api/kabir/command`, `/api/kabir/learn-workflow`). Keep `OPENAI_API_KEY` in its secrets.

**Check that it works** (replace HOST):
```bash
curl -s https://HOST/api/healthz                       # → {"status":"ok"}
curl -s -X POST https://HOST/api/kabir/command -H 'content-type: application/json' \
  -d '{"transcript":"say hello","responseLanguage":"English","uiLanguage":"en"}' | head -c 300
```
The second command should return JSON containing `"kind":"chat"`. A `404` means the server is still the old version; an
error mentioning `OPENAI_API_KEY` means the key is not set.

## 4. Tell the build your API host and run the preflight

```bash
export EXPO_PUBLIC_DOMAIN="random-words.trycloudflare.com"     # host only: no https://, no slash
bash tools/check-env.sh
```
Every line should say `[ ok ]` (a few `[warn]` lines are fine). Each `[FAIL]` line says what to fix. Run it again until it is clean.

## 5. Build the APK

**One command (recommended):**
```bash
bash tools/build-apk.sh --install      # leave off --install to just build the file
```
It runs: install packages → generate the Android project → compile with Gradle (**10–25 min the first time**, it
downloads a lot) → copy the result to `dist-apk/kabir-ai-release.apk` → install it on your phone if you passed `--install`
and the phone is connected.

**Same thing by hand:**
```bash
pnpm install --no-frozen-lockfile
cd artifacts/kabir-ai
pnpm exec expo prebuild --platform android --clean --no-install
cd android
./gradlew assembleRelease
# APK: artifacts/kabir-ai/android/app/build/outputs/apk/release/app-release.apk
```
<details><summary><b>Native Windows (PowerShell) instead of WSL2</b></summary>

```powershell
$env:EXPO_PUBLIC_DOMAIN = "random-words.trycloudflare.com"
pnpm install --no-frozen-lockfile
cd artifacts\kabir-ai
pnpm exec expo prebuild --platform android --clean --no-install
cd android
.\gradlew.bat assembleRelease
# APK: artifacts\kabir-ai\android\app\build\outputs\apk\release\app-release.apk
```
Set `ANDROID_HOME` in *System Properties → Environment Variables* (usually `%LOCALAPPDATA%\Android\Sdk`).
</details>

Notes: the release APK carries the JavaScript inside it, so it runs without your computer (it only needs the API server
reachable). It is signed with Expo's default debug key, fine for testing, but not for Google Play.
The package name is `com.kabir.app` (change it in `artifacts/kabir-ai/app.json` → `expo.android.package` before building if you want another).

## 6. Install on the phone

Either `bash tools/build-apk.sh --install`, or:
```bash
adb devices                                   # phone must be listed as "device" (accept the prompt on the phone)
adb install -r dist-apk/kabir-ai-release.apk
```
No cable? Copy the `.apk` to the phone (cloud drive, chat, USB file transfer), open it, and allow *install unknown apps*
for that file manager when Android asks.

## 7. First run on the phone (do these in order)

1. Open **Kabir AI** → allow the **microphone**. Try a normal question first: tap the big **mic button** ("Record a voice request"), speak, tap it again to finish.
   This proves the phone → API server → OpenAI chain works.
2. **Settings → Routines.** The "Screen access is off" card appears → **Open accessibility settings** →
   find **Kabir screen assistant** → turn it **on**.
   - **If the switch is greyed out** (normal for APKs you installed yourself, Android 13+): leave, go to
     *Settings → Apps → Kabir AI → ⋮ (top right) → **Allow restricted settings***, then repeat.
   - Android shows a warning about accessibility; that's expected. Kabir only uses it to read what's on screen and perform
     the taps/typing you ask for.
3. Back in Routines, tap **Start screen reading** → allow **notifications** → in Android's prompt choose **Start now**.
   (Optional but recommended: it keeps Kabir running while it works in other apps. A notification with **Stop** shows while on.)
4. **Test 1, simple** (use the mic button each time): say *"go to the home screen"*, then *"open Settings and scroll down"*.
5. **Test 2, YouTube:** say *"play lofi hip hop beats on YouTube"*. Kabir should open YouTube, search, and play a matching
   video. If it stops, **Settings → Smart diagnostics** will say where and what to try.
6. **Test 3, teaching:** Routines → type a name → **Start teaching**, do a small task in another app (for example open an app,
   tap something, scroll), come back to Kabir → **Finish**. Then say *"run my <name> routine"*.

Anything involving payments, deletions, permissions or sign-out always asks you to confirm first.

## 8. When something goes wrong: the diagnostic tools

**In the app.** **Settings → Smart diagnostics** lists recent problems with plain-language fix steps. Screen-control
problems (accessibility off, permission missing, "couldn't find it on screen", routine needs repair) are now reported there
too. **Settings → Routines** shows each routine's steps, status and last problem.

**From your computer** (phone connected by USB):
```bash
adb logcat -s ReactNativeJS:V AndroidRuntime:E      # app errors, live
adb logcat -d | grep -i -E "kabir|expo|AndroidRuntime" | tail -100 > kabir-log.txt
```

| Symptom | Likely cause → fix |
|---|---|
| Voice does nothing / "Connection issue" | API server or tunnel not running, or the APK was built with an old `EXPO_PUBLIC_DOMAIN`. Re-check step 3; rebuild if the address changed. |
| `curl …/api/kabir/command` gives 404 | Server is the old version. Rebuild/redeploy from this master. |
| "AI service credentials" | `OPENAI_API_KEY` missing or wrong on the **server**; restart the server after setting it. |
| Accessibility switch greyed out | *Settings → Apps → Kabir AI → ⋮ → Allow restricted settings* (step 7.2). |
| Accessibility turns itself off | Phone's battery saver. Exempt Kabir from battery optimization. |
| "Screen control isn't in this build" | You are running Expo Go / a web preview. Use the installed APK. |
| Kabir can't find a button | Phone language or the app's screens differ from what Kabir learned. Re-teach the routine (Routines screen). |
| Stops partway when in other apps | Start **screen reading** (step 7.3) so Android keeps Kabir alive. |

## 9. If the build fails

The first Android build is the first time the native Kotlin code is compiled, so an error there is plausible. Capture it
and send it to me:
```bash
cd artifacts/kabir-ai/android
./gradlew assembleRelease --stacktrace 2>&1 | tail -120 > ../../../build-error.txt
```
Send me `build-error.txt` (it contains no secrets) and I'll fix the exact line. Common first-build issues:

- **`Plugin 'expo-module-gradle-plugin' not found`** (in `modules/kabir-screen-agent/android/build.gradle`): your Expo SDK's module
  template differs. Run `npx create-expo-module@latest --local` in a scratch folder, copy the top of its `build.gradle` over
  ours, and keep our `dependencies { … }` block.
- **Kotlin errors in `KabirScreenAgentModule.kt`** such as "unresolved reference" on `Function`, `AsyncFunction` or
  `OnActivityResult`: the Expo Modules Kotlin API changed names in your SDK; send me the error.
- **Gradle can't find a React Native or Expo package** (pnpm's folder layout): add `node-linker=hoisted` as a new line to
  the root `.npmrc`, delete `node_modules`, run `pnpm install --no-frozen-lockfile`, and rebuild.
- **"SDK location not found"**: `ANDROID_HOME` is not set in the terminal you're building from.
- **Out of memory in Gradle**: close other programs, or add `org.gradle.jvmargs=-Xmx4g` to
  `artifacts/kabir-ai/android/gradle.properties` (regenerated by `prebuild`, so re-add after `--clean`).

## 10. Rebuilding later

Changed only JavaScript/TypeScript (screens, hooks, `lib/`)? Run the same `bash tools/build-apk.sh --install` (about 3–6 min
once Gradle has its caches). For faster edit–reload cycles use a development build: `cd artifacts/kabir-ai && pnpm exec expo run:android`
(keeps a Metro server running; the phone must reach your computer, e.g. `adb reverse tcp:8081 tcp:8081`).
To remove everything: uninstall **Kabir AI** from the phone; routines and settings live only on the phone.
**Privacy:** the only data leaving the phone is what the app already sent before (your voice clips/transcripts to *your*
API server → OpenAI); screen contents stay on the device unless you opt in to label sharing, which is off by default.
