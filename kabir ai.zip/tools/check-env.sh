#!/usr/bin/env bash
# Kabir AI: build preflight. Checks everything the APK build needs and tells you exactly what to fix.
# Usage: bash tools/check-env.sh [--quiet]      Exit code 1 if a hard requirement is missing.
QUIET=0; [ "${1:-}" = "--quiet" ] && QUIET=1
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FAIL=0; WARN=0
ok()   { [ "$QUIET" = 1 ] || printf '  [ ok ] %s\n' "$1"; }
warn() { WARN=$((WARN+1)); printf '  [warn] %s\n' "$1"; }
bad()  { FAIL=$((FAIL+1)); printf '  [FAIL] %s\n' "$1"; }
# ver_ge A B  ->  true if version A >= version B
ver_ge() { [ "$(printf '%s\n%s\n' "$2" "$1" | sort -V | head -n1)" = "$2" ]; }

[ "$QUIET" = 1 ] || echo "Kabir AI build preflight"

# Node
if command -v node >/dev/null 2>&1; then
  v="$(node -v | sed 's/^v//')"
  if ver_ge "$v" "20.0.0"; then ok "Node $v"; else bad "Node $v is too old. Install Node 22 or 24 LTS (https://nodejs.org)."; fi
else bad "Node.js not found. Install Node 22 or 24 LTS (https://nodejs.org)."; fi

# pnpm
if command -v pnpm >/dev/null 2>&1; then
  v="$(pnpm -v)"
  if ver_ge "$v" "9.5.0"; then ok "pnpm $v"; else bad "pnpm $v is too old (this workspace uses 'catalog:' which needs 9.5+). Run: npm i -g pnpm"; fi
else bad "pnpm not found. Run: npm i -g pnpm   (or: corepack enable && corepack prepare pnpm@latest --activate)"; fi

# Java
if command -v java >/dev/null 2>&1; then
  major="$(java -version 2>&1 | head -1 | sed -E 's/.*"([0-9]+)(\.([0-9]+))?.*/\1/')"
  [ "$major" = "1" ] && major=8
  if [ "${major:-0}" -ge 17 ] 2>/dev/null; then ok "Java $major"; else bad "Java ${major:-?} found; the Android build needs JDK 17 or newer (Temurin 17 recommended: https://adoptium.net)."; fi
else bad "Java not found. Install JDK 17 (Temurin: https://adoptium.net) and make sure 'java -version' works."; fi

# Android SDK
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ]; then
  bad "ANDROID_HOME is not set. Install Android Studio, then export ANDROID_HOME (macOS: \$HOME/Library/Android/sdk, Linux: \$HOME/Android/Sdk)."
elif [ ! -d "$SDK" ]; then
  bad "ANDROID_HOME points to '$SDK' which does not exist."
else
  ok "Android SDK at $SDK"
  if [ -x "$SDK/platform-tools/adb" ] || [ -x "$SDK/platform-tools/adb.exe" ]; then ok "adb found"; else bad "Android platform-tools missing. In Android Studio: Settings > SDK Manager > SDK Tools > Android SDK Platform-Tools."; fi
  if [ -d "$SDK/licenses" ] && [ -n "$(ls -A "$SDK/licenses" 2>/dev/null)" ]; then ok "SDK licenses accepted"; else bad "SDK licenses not accepted. Run: yes | \$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses"; fi
fi

# API domain baked into the app at build time
D="${EXPO_PUBLIC_DOMAIN:-}"
if [ -z "$D" ]; then
  bad "EXPO_PUBLIC_DOMAIN is not set. It must be your API server's public HTTPS host, e.g. export EXPO_PUBLIC_DOMAIN=my-tunnel.trycloudflare.com"
elif echo "$D" | grep -Eq '^https?://|/'; then
  bad "EXPO_PUBLIC_DOMAIN must be a bare host name (no https:// and no slashes). Current value: $D"
elif ! echo "$D" | grep -q '\.'; then
  warn "EXPO_PUBLIC_DOMAIN='$D' has no dot; is it a real public host?"
else ok "EXPO_PUBLIC_DOMAIN=$D"; fi

# Disk space (first Android build needs several GB)
free_kb="$(df -Pk "$ROOT" 2>/dev/null | awk 'NR==2{print $4}')"
if [ -n "$free_kb" ]; then
  if [ "$free_kb" -ge 10485760 ]; then ok "free disk $((free_kb/1048576)) GB"; else warn "only $((free_kb/1048576)) GB free; the first build downloads and compiles ~8 GB."; fi
fi

# Phone (optional)
ADB="$(command -v adb || true)"; [ -z "$ADB" ] && [ -n "$SDK" ] && ADB="$SDK/platform-tools/adb"
if [ -n "$ADB" ] && [ -x "$ADB" ]; then
  n="$("$ADB" devices 2>/dev/null | awk 'NR>1 && $2=="device"' | wc -l | tr -d ' ')"
  if [ "$n" -ge 1 ]; then ok "$n Android device connected"; else warn "no phone detected by adb (needed only for --install). Enable USB debugging and plug it in."; fi
fi

[ -n "${OPENAI_API_KEY:-}" ] || { [ "$QUIET" = 1 ] || echo "  [info] OPENAI_API_KEY is only needed by the API server, not for building the APK."; }

echo
if [ "$FAIL" -gt 0 ]; then echo "$FAIL problem(s) to fix before building."; exit 1; fi
[ "$WARN" -gt 0 ] && echo "Ready to build (with $WARN warning(s))." || echo "Ready to build."
exit 0
