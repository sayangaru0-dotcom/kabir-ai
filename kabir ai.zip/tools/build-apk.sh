#!/usr/bin/env bash
# Kabir AI: build a standalone Android APK (JavaScript bundled inside; no PC needed to run it).
# Usage:  export EXPO_PUBLIC_DOMAIN=your-api-host.example.com
#         bash tools/build-apk.sh [--install]        (--install also installs on the connected phone)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/artifacts/kabir-ai"
OUT="$ROOT/dist-apk"
INSTALL=0; [ "${1:-}" = "--install" ] && INSTALL=1

echo "== 1/5  Preflight =="
bash "$ROOT/tools/check-env.sh"

echo; echo "== 2/5  Installing JavaScript dependencies =="
( cd "$ROOT" && pnpm install --no-frozen-lockfile )

echo; echo "== 3/5  Generating the Android project (expo prebuild) =="
( cd "$APP" && pnpm exec expo prebuild --platform android --clean --no-install )

echo; echo "== 4/5  Compiling the APK (first build: 10-25 minutes) =="
( cd "$APP/android" && ./gradlew assembleRelease )

APK="$APP/android/app/build/outputs/apk/release/app-release.apk"
[ -f "$APK" ] || { echo "Build finished but the APK was not found at: $APK" >&2; exit 1; }
mkdir -p "$OUT"; cp "$APK" "$OUT/kabir-ai-release.apk"

echo; echo "== 5/5  Done =="
ls -lh "$OUT/kabir-ai-release.apk"
if [ "$INSTALL" = 1 ]; then
  SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"; ADB="$(command -v adb || echo "$SDK/platform-tools/adb")"
  echo "Installing on the connected phone..."; "$ADB" install -r "$OUT/kabir-ai-release.apk"
  echo "Installed. Open 'Kabir AI' on the phone."
else
  echo "Install with:  adb install -r \"$OUT/kabir-ai-release.apk\"   (or copy the file to the phone and tap it)"
fi
