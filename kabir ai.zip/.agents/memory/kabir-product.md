---
name: Kabir product requirements
description: User-stated behavior and scope for the Kabir AI mobile assistant.
---

Kabir is a native mobile voice assistant. Its core experience should include 3–4 user-recorded wake phrases, automatic recognition of the input language, and a persistent response-language choice among Bengali, Hindi, and English. Learning memory should retain only useful, noise-filtered knowledge or actions rather than filler dialogue or original recordings. Keep a dark dashboard with Active, Sleeping, and Learning status states. During testing, keep the app open without sign-in, passwords, or user authentication; login, email/OTP, and security features come later before public release. Add automatic error monitoring with clear logs, precise recovery steps, and troubleshooting links.

**Why:** The user specified these behaviors and the no-auth testing boundary as core product requirements.

**How to apply:** Preserve these requirements when extending Kabir’s voice, settings, dashboard, diagnostics, or learning features. Do not add authentication during the testing phase.
