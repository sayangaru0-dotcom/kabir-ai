# HTML CSS JS Starter

A small starter project using plain HTML, CSS, and JavaScript. Vite is used only
to serve the page and prepare it for a production build.

## The three files to edit

- `index.html` — page content and structure
- `src/style.css` — colors, layout, and other visual styles
- `src/main.js` — browser behavior and interactivity

## Run

The live project preview runs through the web workflow. To start it from the
workspace terminal, run:

```sh
pnpm --filter @workspace/html-css-js-starter run dev
```

Edit the three files above and refresh the preview to see your changes.
