const tryButton = document.querySelector('#try-button');
const demoHeading = document.querySelector('#demo-heading');
const demoMessage = document.querySelector('#demo-message');
const demoCard = document.querySelector('#demo-card');
const tapNote = document.querySelector('#tap-note');
const resetButton = document.querySelector('#reset-button');

const startingCopy = {
  heading: 'You made it here.',
  message: 'That counts as a start.',
  button: 'Give it a nudge',
};

let hasBeenNudged = false;

tryButton.addEventListener('click', () => {
  hasBeenNudged = !hasBeenNudged;

  if (hasBeenNudged) {
    demoHeading.textContent = 'Look what you did.';
    demoMessage.textContent = 'One click, a whole new moment.';
    tryButton.textContent = 'Nice work';
    tapNote.textContent = 'THAT WAS JAVASCRIPT';
    demoCard.classList.add('is-nudged');
  } else {
    resetPreview();
  }
});

function resetPreview() {
  hasBeenNudged = false;
  demoHeading.textContent = startingCopy.heading;
  demoMessage.textContent = startingCopy.message;
  tryButton.textContent = startingCopy.button;
  tapNote.textContent = 'GO ON, TRY IT';
  demoCard.classList.remove('is-nudged');
}

resetButton.addEventListener('click', resetPreview);
