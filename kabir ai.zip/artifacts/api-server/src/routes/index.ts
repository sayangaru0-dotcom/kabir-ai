import { Router, type IRouter } from "express";
import healthRouter from "./health";
import kabirRouter from "./kabir";
import commandRouter from "./command";
import learnWorkflowRouter from "./learn-workflow";

const router: IRouter = Router();

router.use(healthRouter);
router.use(kabirRouter);
router.use(commandRouter);
router.use(learnWorkflowRouter);

export default router;
