/**
 * Single source of truth (server side) for the step whitelist. The app re-validates with its own copy
 * (lib/screen-commands/steps.ts): model output is untrusted on both sides.
 */

type StrRule = { max: number };
type NumRule = { min: number; max: number; optional?: boolean };
type Spec = {
  strings?: Record<string, StrRule & { optional?: boolean }>;
  numbers?: Record<string, NumRule>;
  enums?: Record<string, { values: readonly string[]; optional?: boolean }>;
  bools?: readonly string[];
};

const DIRS = ["up", "down", "left", "right"] as const;
const GLOBALS = ["back", "home", "recents", "notifications", "quickSettings"] as const;
export const WORKFLOW_NAMES = ["youtube.searchPlay"] as const;
const SQUARE = /^[a-h][1-8]$/;
const F = { min: 0, max: 1 };

const SPECS: Record<string, Spec> = {
  openApp: { strings: { name: { max: 80 } } },
  global: { enums: { name: { values: GLOBALS } } },
  tapText: { strings: { text: { max: 80 } }, bools: ["optional"] },
  longPressText: { strings: { text: { max: 80 } } },
  scroll: { enums: { direction: { values: DIRS } } },
  scrollUntilVisible: {
    strings: { text: { max: 80 } },
    enums: { direction: { values: DIRS, optional: true } },
    numbers: { maxScrolls: { min: 1, max: 10, optional: true } },
  },
  typeText: { strings: { text: { max: 300 } }, bools: ["append"] },
  waitForText: { strings: { text: { max: 80 } }, numbers: { timeoutMs: { min: 500, max: 8000, optional: true } } },
  wait: { numbers: { ms: { min: 50, max: 8000 } } },
  tapAt: { numbers: { x: F, y: F } },
  dragAt: { numbers: { x1: F, y1: F, x2: F, y2: F, ms: { min: 100, max: 3000, optional: true } } },
  pinch: {
    numbers: {
      x: F, y: F, from: { min: 0.05, max: 0.9 }, to: { min: 0.05, max: 0.9 },
      ms: { min: 100, max: 3000, optional: true },
    },
  },
  pressEnter: {},
  boardMove: {
    strings: { from: { max: 2 }, to: { max: 2 } },
    enums: { orientation: { values: ["white", "black"], optional: true } },
  },
  workflow: {
    enums: { name: { values: WORKFLOW_NAMES } },
    strings: { query: { max: 200 } },
  },
};

const TEXT_FIELDS = ["name", "text", "query"] as const;
const PLACEHOLDER = /\{\{([a-z][a-z0-9_]{0,23})\}\}/g;

/** Returns a cleaned copy of every step, or null if ANY step is not exactly on the whitelist. */
export function validateSteps(raw: unknown, maxSteps = 25): Record<string, unknown>[] | null {
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > maxSteps) return null;
  const out: Record<string, unknown>[] = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") return null;
    const o = item as Record<string, unknown>;
    const spec = typeof o.type === "string" ? SPECS[o.type] : undefined;
    if (!spec) return null;

    const known = new Set<string>([
      "type",
      ...Object.keys(spec.strings ?? {}), ...Object.keys(spec.numbers ?? {}),
      ...Object.keys(spec.enums ?? {}), ...(spec.bools ?? []),
    ]);
    if (Object.keys(o).some((k) => !known.has(k))) return null;

    for (const [k, r] of Object.entries(spec.strings ?? {})) {
      const v = o[k];
      if (v === undefined) { if (r.optional) continue; return null; }
      if (typeof v !== "string" || v.trim().length === 0 || v.length > r.max) return null;
    }
    for (const [k, r] of Object.entries(spec.numbers ?? {})) {
      const v = o[k];
      if (v === undefined) { if (r.optional) continue; return null; }
      if (typeof v !== "number" || !Number.isFinite(v) || v < r.min || v > r.max) return null;
    }
    for (const [k, r] of Object.entries(spec.enums ?? {})) {
      const v = o[k];
      if (v === undefined) { if (r.optional) continue; return null; }
      if (typeof v !== "string" || !r.values.includes(v)) return null;
    }
    for (const k of spec.bools ?? []) {
      if (o[k] !== undefined && typeof o[k] !== "boolean") return null;
    }
    if (o.type === "boardMove") {
      if (!SQUARE.test(o.from as string) || !SQUARE.test(o.to as string) || o.from === o.to) return null;
    }
    out.push(o);
  }
  return out;
}

export function placeholdersIn(steps: Record<string, unknown>[]): Set<string> {
  const found = new Set<string>();
  for (const s of steps) {
    for (const f of TEXT_FIELDS) {
      const v = s[f];
      if (typeof v === "string") for (const m of v.matchAll(PLACEHOLDER)) found.add(m[1]);
    }
  }
  return found;
}

export const STEP_DOC = `  {"type":"openApp","name":string}                     launch an app by its launcher name (e.g. "Settings", "WhatsApp", "YouTube")
  {"type":"global","name":"back"|"home"|"recents"|"notifications"|"quickSettings"}
  {"type":"tapText","text":string,"optional"?:boolean}   tap the control whose visible label is text
  {"type":"longPressText","text":string}
  {"type":"scroll","direction":"up"|"down"|"left"|"right"}   direction = which way the content moves to reveal more ("down" reveals content below)
  {"type":"scrollUntilVisible","text":string,"direction"?:"up"|"down"|"left"|"right","maxScrolls"?:number}
  {"type":"typeText","text":string,"append"?:boolean}   types into the currently focused field
  {"type":"pressEnter"}                                 presses the keyboard's Search/Go/Enter key
  {"type":"waitForText","text":string,"timeoutMs"?:number}
  {"type":"wait","ms":number}
  {"type":"tapAt","x":0-1,"y":0-1}                      only for controls with NO visible label (fractions of the screen)
  {"type":"dragAt","x1":0-1,"y1":0-1,"x2":0-1,"y2":0-1,"ms"?:number}
  {"type":"pinch","x":0-1,"y":0-1,"from":0.05-0.9,"to":0.05-0.9}   finger distance as a fraction of screen width; from>to = zoom out
  {"type":"boardMove","from":"e2","to":"e4","orientation"?:"white"|"black"}   one move on a chess-style 8x8 board; orientation = colour at the bottom
  {"type":"workflow","name":"youtube.searchPlay","query":string}   built-in adaptive workflow: open YouTube, search, pick and play the best matching video`;
