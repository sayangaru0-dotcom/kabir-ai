/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#0a0a0a',
    tint: '#2f95dc',

    // Core surfaces
    background: '#ffffff',
    foreground: '#0a0a0a',

    // Cards / elevated surfaces
    card: '#f9f9f9',
    cardForeground: '#0a0a0a',

    // Primary action color (buttons, links, active states)
    primary: '#2f95dc',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#f0f0f0',
    secondaryForeground: '#1a1a1a',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#f0f0f0',
    mutedForeground: '#737373',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#f0f0f0',
    accentForeground: '#1a1a1a',

    // Destructive actions (delete, error states)
    destructive: '#ef4444',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#e5e5e5',
    input: '#e5e5e5',
  },

  dark: {
    // Legacy aliases (kept for backward compatibility)
    text: '#eaf3ee',
    tint: '#a3edbc',

    // Core surfaces
    background: '#0b110e',
    foreground: '#edf5f0',

    // Cards / elevated surfaces
    card: '#121a16',
    cardForeground: '#edf5f0',

    // Primary action color (buttons, links, active states)
    primary: '#a3edbc',
    primaryForeground: '#0b110e',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#202b25',
    secondaryForeground: '#dceae1',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#18211c',
    mutedForeground: '#91a199',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#eac581',
    accentForeground: '#271e10',

    // Destructive actions (delete, error states)
    destructive: '#f07779',
    destructiveForeground: '#221011',

    // Borders and input outlines
    border: '#29342d',
    input: '#29342d',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 18,
};

export default colors;
