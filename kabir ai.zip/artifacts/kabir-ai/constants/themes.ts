export const CUSTOMIZATION_COLOR_KEYS = [
  "background",
  "card",
  "foreground",
  "primary",
  "primaryForeground",
  "secondary",
  "accent",
  "mutedForeground",
  "border",
] as const;

export type CustomizationColorKey = (typeof CUSTOMIZATION_COLOR_KEYS)[number];
export type CustomColorOverrides = Partial<Record<CustomizationColorKey, string>>;

export const COLOR_LABELS: Record<CustomizationColorKey, string> = {
  background: "Background",
  card: "Cards",
  foreground: "Main text",
  primary: "Buttons",
  primaryForeground: "Button text",
  secondary: "Secondary surfaces",
  accent: "Accent",
  mutedForeground: "Muted text",
  border: "Borders",
};

export const THEME_PRESETS = [
  {
    id: "forest",
    name: "Forest",
    colors: {
      background: "#0B110E",
      foreground: "#EDF5F0",
      card: "#121A16",
      primary: "#A3EDBC",
      primaryForeground: "#0B110E",
      secondary: "#202B25",
      accent: "#EAC581",
      mutedForeground: "#91A199",
      border: "#29342D",
    },
  },
  {
    id: "midnight",
    name: "Midnight",
    colors: {
      background: "#090D18",
      foreground: "#F0F3FF",
      card: "#12192A",
      primary: "#94B5FF",
      primaryForeground: "#0A1020",
      secondary: "#202B42",
      accent: "#FFD27A",
      mutedForeground: "#A0AEC8",
      border: "#303E5B",
    },
  },
  {
    id: "ocean",
    name: "Ocean",
    colors: {
      background: "#071720",
      foreground: "#E2F3FB",
      card: "#0D2737",
      primary: "#69D0E7",
      primaryForeground: "#08202A",
      secondary: "#15394C",
      accent: "#F2B86B",
      mutedForeground: "#99B6C2",
      border: "#285165",
    },
  },
  {
    id: "plum",
    name: "Plum",
    colors: {
      background: "#160E1A",
      foreground: "#F5EAF9",
      card: "#24152C",
      primary: "#D6A0EF",
      primaryForeground: "#24102E",
      secondary: "#35213F",
      accent: "#F3AA92",
      mutedForeground: "#BEAAC5",
      border: "#4E3659",
    },
  },
  {
    id: "ember",
    name: "Ember",
    colors: {
      background: "#1C100D",
      foreground: "#FFF1E8",
      card: "#2B1A14",
      primary: "#FFB07C",
      primaryForeground: "#2A1408",
      secondary: "#3E261B",
      accent: "#F46F5E",
      mutedForeground: "#C5A89A",
      border: "#5A3A2E",
    },
  },
  {
    id: "graphite",
    name: "Graphite",
    colors: {
      background: "#101114",
      foreground: "#F4F5F7",
      card: "#191B20",
      primary: "#B7C1FF",
      primaryForeground: "#171922",
      secondary: "#272A32",
      accent: "#FFCA7A",
      mutedForeground: "#A3A7B0",
      border: "#383B44",
    },
  },
  {
    id: "rose",
    name: "Rose",
    colors: {
      background: "#1B0E14",
      foreground: "#FFF0F4",
      card: "#2C1620",
      primary: "#FFA9BF",
      primaryForeground: "#2B111C",
      secondary: "#3E202D",
      accent: "#FFCF80",
      mutedForeground: "#C6A3AE",
      border: "#583042",
    },
  },
  {
    id: "cyber",
    name: "Cyber",
    colors: {
      background: "#080E11",
      foreground: "#E9FFF9",
      card: "#101A1E",
      primary: "#5DF2CB",
      primaryForeground: "#06231D",
      secondary: "#18302D",
      accent: "#F1F567",
      mutedForeground: "#A1C2B7",
      border: "#2B4942",
    },
  },
  {
    id: "sapphire",
    name: "Sapphire",
    colors: {
      background: "#0B1020",
      foreground: "#EDF1FF",
      card: "#141C34",
      primary: "#9CBAFF",
      primaryForeground: "#10182C",
      secondary: "#242F4D",
      accent: "#E9B5FF",
      mutedForeground: "#AAB6D2",
      border: "#374363",
    },
  },
  {
    id: "warm-sand",
    name: "Warm sand",
    colors: {
      background: "#1B1811",
      foreground: "#FBF3DF",
      card: "#2A251A",
      primary: "#E9C77A",
      primaryForeground: "#2B2110",
      secondary: "#3A3121",
      accent: "#E9A987",
      mutedForeground: "#C1B494",
      border: "#56492F",
    },
  },
  {
    id: "arctic",
    name: "Arctic",
    colors: {
      background: "#0B1418",
      foreground: "#E9F8FB",
      card: "#132329",
      primary: "#87DCE7",
      primaryForeground: "#082126",
      secondary: "#1D363D",
      accent: "#ADC8FF",
      mutedForeground: "#9BB5B9",
      border: "#365058",
    },
  },
  {
    id: "orchid",
    name: "Orchid",
    colors: {
      background: "#140C1C",
      foreground: "#F8EFFF",
      card: "#23162F",
      primary: "#D0A0FF",
      primaryForeground: "#23102F",
      secondary: "#332246",
      accent: "#91E4D1",
      mutedForeground: "#BAA8CA",
      border: "#4C3663",
    },
  },
  {
    id: "monochrome",
    name: "Monochrome",
    colors: {
      background: "#111111",
      foreground: "#F2F2F2",
      card: "#1C1C1C",
      primary: "#E4E4E4",
      primaryForeground: "#151515",
      secondary: "#2B2B2B",
      accent: "#BDBDBD",
      mutedForeground: "#A1A1A1",
      border: "#3E3E3E",
    },
  },
] as const;

export type ThemeId = (typeof THEME_PRESETS)[number]["id"];

export const LOGO_VARIANTS = [
  { id: "orbit", name: "Orbit" },
  { id: "voice", name: "Voice" },
  { id: "signal", name: "Signal" },
  { id: "pulse", name: "Pulse" },
  { id: "monogram", name: "Monogram" },
] as const;

export type LogoVariant = (typeof LOGO_VARIANTS)[number]["id"];

export type AppearancePreferences = {
  themeId: ThemeId;
  colorOverrides: CustomColorOverrides;
  logoVariant: LogoVariant;
  brandName: string;
};

export const DEFAULT_APPEARANCE: AppearancePreferences = {
  themeId: "forest",
  colorOverrides: {},
  logoVariant: "orbit",
  brandName: "Kabir AI",
};

export function getThemePreset(themeId: string) {
  return THEME_PRESETS.find((theme) => theme.id === themeId) ?? THEME_PRESETS[0];
}

export function isCustomizationColorKey(value: string): value is CustomizationColorKey {
  return (CUSTOMIZATION_COLOR_KEYS as readonly string[]).includes(value);
}

export function isLogoVariant(value: string): value is LogoVariant {
  return (LOGO_VARIANTS as readonly { id: string; name: string }[]).some(
    (variant) => variant.id === value,
  );
}

export function isHexColor(value: string): boolean {
  return /^#[0-9A-Fa-f]{6}$/.test(value);
}
