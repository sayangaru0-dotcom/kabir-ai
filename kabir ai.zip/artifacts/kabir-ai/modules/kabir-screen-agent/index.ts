import { PermissionsAndroid, Platform } from "react-native";
import { requireOptionalNativeModule } from "expo-modules-core";

// ───────────── Types ─────────────
export type Bounds = {
  left: number; top: number; right: number; bottom: number;
  width: number; height: number;
  centerX: number; centerY: number;
};
export type UiNode = {
  text: string; description: string; viewId: string; className: string; package: string;
  clickable: boolean; editable: boolean; scrollable: boolean; enabled: boolean;
  bounds: Bounds; depth: number;
};
export type OcrItem = { text: string; bounds: Bounds; confidence: number; level: "line" | "word" };
export type Target = {
  x: number; y: number; label: string; confidence: number; bounds: Bounds;
  source: "node" | "node-static" | "ocr" | "ocr+node";
};
export type ActionResult = { ok: boolean; reason?: string | null };
export type TapTextResult = ActionResult & Partial<Omit<Target, "bounds">>;

export type AgentStatus = {
  apiLevel: number; ownPackage: string; accessibilityEnabled: boolean;
  demonstrating: boolean; demoEventCount: number; captureRunning: boolean;
  foregroundPackage: string | null;
  screenWidth: number; screenHeight: number; frameWidth: number; frameHeight: number;
  fps: number; lastFrameAgeMs: number | null; lastOcrMs: number; ocrItemCount: number;
};
export type CaptureOptions = {
  /** Longest side of the analysed frame in px. Smaller = faster. Default 720. */
  maxFrameDimension?: number;
  /** Max frames/second pulled from the screen. Default 8. */
  targetFps?: number;
  ocr?: boolean;
  /** Also recognise Hindi/Devanagari (slower). ML Kit has no Bengali model. */
  devanagari?: boolean;
  /** Fraction (0-1) of sampled cells that must change to count as a visual change. Default 0.02. */
  changeThreshold?: number;
  ocrMinIntervalMs?: number;
};
export type DemoEvent = {
  kind: "click" | "longClick" | "scroll" | "text" | "window";
  /** ms since recording started */
  at: number;
  package: string;
  label: string; viewId: string; className: string;
  /** centre of the touched control as a 0-1 fraction of the screen (-1 if unknown) */
  xFrac: number; yFrac: number;
  text: string; secret: boolean;
  dir: "up" | "down" | "left" | "right" | "";
  appLabel: string;
};
export type Snapshot = {
  foregroundPackage: string | null; screenWidth: number; screenHeight: number;
  nodes: UiNode[]; ocr: OcrItem[]; ocrAgeMs: number | null;
};
export type FrameAnalysisEvent = {
  at: number; ocrLatencyMs: number; changeScore: number; fps: number; lineCount: number;
  frameWidth: number; frameHeight: number; screenWidth: number; screenHeight: number;
};
export type ScreenChangedEvent = { kind: "visual" | "window" | "content"; package?: string | null; score?: number; at: number };

type Events = {
  onFrameAnalysis: FrameAnalysisEvent;
  onScreenChanged: ScreenChangedEvent;
  onServiceState: { accessibility?: boolean; capture?: boolean };
  onAgentError: { where: string; message: string };
};

// ───────────── Native binding (null on iOS / web / Expo Go) ─────────────
/** Loading the native module must never be able to crash the app: on any failure the screen agent is simply "unsupported". */
function loadNative(): any | null {
  try {
    return requireOptionalNativeModule<any>("KabirScreenAgent");
  } catch {
    return null;
  }
}
const Native = loadNative();

export const isScreenAgentSupported = Platform.OS === "android" && Native != null;

function native() {
  if (!Native) {
    throw new Error(
      "KabirScreenAgent native module is unavailable. It needs Android and a development build (not Expo Go).",
    );
  }
  return Native;
}

// ───────────── Public API ─────────────
/** What the UI shows when the native side cannot answer: everything off. */
export const OFFLINE_STATUS: AgentStatus = {
  apiLevel: 0, ownPackage: "", accessibilityEnabled: false, demonstrating: false, demoEventCount: 0, captureRunning: false,
  foregroundPackage: null, screenWidth: 0, screenHeight: 0, frameWidth: 0, frameHeight: 0, fps: 0,
  lastFrameAgeMs: null, lastOcrMs: 0, ocrItemCount: 0,
};

/** Status polling runs on timers, where an exception would be uncaught: it never throws and falls back to "off". */
export const getStatus = (): AgentStatus => {
  try {
    return native().getStatus();
  } catch {
    return OFFLINE_STATUS;
  }
};
export const openAccessibilitySettings = (): void => native().openAccessibilitySettings();
export const setBlockedPackages = (packages: string[]): void => native().setBlockedPackages(packages);
export const pressEnter = (): { ok: boolean; reason?: string | null } => native().pressEnter();
export const pinch = (cx: number, cy: number, startSpan: number, endSpan: number, durationMs?: number): Promise<ActionResult> =>
  native().pinch(cx, cy, startSpan, endSpan, durationMs ?? null);

/**
 * Teach mode: records the user's own taps/scrolls/typing in other apps (never passwords) until stopDemonstration().
 * A persistent "Kabir is recording your steps" notification with a Stop button is shown while it runs.
 */
export async function startDemonstration(): Promise<boolean> {
  const n = native();
  if (Platform.OS === "android" && Number(Platform.Version) >= 33) {
    const res = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
    if (res !== "granted") throw new Error("Notification permission is required so the 'recording your steps' indicator is visible.");
  }
  return n.startDemonstration();
}
export const stopDemonstration = (): Promise<DemoEvent[]> => native().stopDemonstration();

export const getChangeSeq = (): number => {
  try {
    return native().getChangeSeq();
  } catch {
    return 0;
  }
};
export const minimizeApp = (): boolean => native().minimizeApp();
export const openApp = (name: string): { ok: boolean; reason?: string; package?: string; label?: string } =>
  native().openApp(name);
export const getActionLog = (): { at: number; kind: string; detail: string; ok: boolean; package: string | null }[] =>
  native().getActionLog();

/**
 * Shows Android's system "start recording/casting?" prompt, then starts the background capture service.
 * The user must approve every time; Android does not allow silent or persistent screen capture.
 */
export async function startScreenCapture(options: CaptureOptions = {}): Promise<boolean> {
  const n = native();
  if (Platform.OS === "android" && Number(Platform.Version) >= 33) {
    const res = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
    if (res !== "granted") {
      // The notification is the user's always-visible "screen is being read" indicator + Stop button.
      throw new Error("Notification permission is required so the 'Kabir is reading your screen' indicator is visible.");
    }
  }
  return n.requestScreenCapture(options);
}
export const stopScreenCapture = (): void => native().stopScreenCapture();

export const getScreenSnapshot = (opts?: { includeNodes?: boolean; includeOcr?: boolean }): Snapshot =>
  native().getScreenSnapshot(opts ?? {});
export const findTargets = (query: string, opts?: { maxOcrAgeMs?: number }): Target[] =>
  native().findTargets(query, opts ?? {});

export const tap = (x: number, y: number): Promise<ActionResult> => native().tap(x, y);
export const longPress = (x: number, y: number, durationMs?: number): Promise<ActionResult> =>
  native().longPress(x, y, durationMs ?? null);
export const swipe = (x1: number, y1: number, x2: number, y2: number, durationMs?: number): Promise<ActionResult> =>
  native().swipe(x1, y1, x2, y2, durationMs ?? null);
export const tapText = (
  query: string,
  opts?: { minConfidence?: number; maxOcrAgeMs?: number; preferNodeAction?: boolean },
): Promise<TapTextResult> => native().tapText(query, opts ?? {});
export const scroll = (direction: "up" | "down" | "left" | "right"): Promise<ActionResult> => native().scroll(direction);
export const typeText = (text: string, append = false): Promise<ActionResult> => native().typeText(text, append);
export const globalAction = (name: "back" | "home" | "recents" | "notifications" | "quickSettings"): Promise<{ ok: boolean }> =>
  native().globalAction(name);

export function addScreenAgentListener<K extends keyof Events>(
  event: K,
  listener: (e: Events[K]) => void,
): { remove: () => void } {
  try {
    return native().addListener(event, listener);
  } catch {
    return { remove: () => undefined };
  }
}
