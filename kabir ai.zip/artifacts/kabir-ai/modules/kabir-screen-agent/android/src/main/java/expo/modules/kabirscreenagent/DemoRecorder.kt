package expo.modules.kabirscreenagent

import android.os.Build
import android.os.SystemClock
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

/**
 * "Learn by demonstration": while teach mode is on, converts the user's own interactions into compact,
 * replayable events (what was tapped, by label + relative position; what was scrolled; what was typed).
 *
 * Privacy rules (enforced here, not in JS):
 *  - password fields: no text, no label, flagged `secret`
 *  - Kabir's own screens, system UI and blocked apps are ignored
 *  - in memory only; capped at 600 events / 10 minutes; collected once by take()
 */
object DemoRecorder {
  private const val MAX_EVENTS = 600
  private const val MAX_DURATION_MS = 10 * 60 * 1000L

  private val events = ArrayList<Map<String, Any?>>()
  private val lastScroll = HashMap<String, Int>()
  private var startedAt = 0L

  @Synchronized fun start() {
    events.clear(); lastScroll.clear()
    startedAt = SystemClock.elapsedRealtime()
    AgentState.demoCount = 0
    AgentState.demonstrating = true
  }

  @Synchronized fun stop() { AgentState.demonstrating = false }

  @Synchronized fun take(): List<Map<String, Any?>> {
    val out = ArrayList(events)
    events.clear(); lastScroll.clear()
    AgentState.demoCount = 0
    return out
  }

  @Synchronized fun onEvent(e: AccessibilityEvent, svc: KabirAccessibilityService) {
    if (!AgentState.demonstrating) return
    val now = SystemClock.elapsedRealtime()
    if (now - startedAt > MAX_DURATION_MS || events.size >= MAX_EVENTS) { svc.stopDemonstration(); return }

    val pkg = e.packageName?.toString() ?: return
    if (pkg == svc.packageName || pkg == "com.android.systemui" || pkg in AgentState.blockedPackages) return

    val (sw, sh) = ScreenMetrics.realSize(svc)
    val src = e.source
    val rect = Rect()
    var xf = -1f
    var yf = -1f
    if (src != null) {
      src.getBoundsInScreen(rect)
      if (rect.width() > 0 && rect.height() > 0 && sw > 0 && sh > 0) {
        xf = (rect.exactCenterX() / sw).coerceIn(0f, 1f)
        yf = (rect.exactCenterY() / sh).coerceIn(0f, 1f)
      }
    }

    fun add(kind: String, label: String = "", text: String = "", secret: Boolean = false, dir: String = "", appLabel: String = "") {
      events += mapOf(
        "kind" to kind, "at" to now - startedAt, "package" to pkg,
        "label" to label, "viewId" to (src?.viewIdResourceName ?: ""),
        "className" to (e.className?.toString() ?: ""),
        "xFrac" to xf, "yFrac" to yf, "text" to text, "secret" to secret, "dir" to dir, "appLabel" to appLabel,
      )
      AgentState.demoCount = events.size
    }

    when (e.eventType) {
      AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> add("window", appLabel = appLabel(svc, pkg))
      AccessibilityEvent.TYPE_VIEW_CLICKED -> add("click", label = labelOf(src))
      AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> add("longClick", label = labelOf(src))
      AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
        val secret = e.isPassword || src?.isPassword == true
        add("text", text = if (secret) "" else (e.text.firstOrNull()?.toString().orEmpty().take(300)), secret = secret)
      }
      AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
        val dx = if (Build.VERSION.SDK_INT >= 28) e.scrollDeltaX else 0
        val dy = if (Build.VERSION.SDK_INT >= 28) e.scrollDeltaY else 0
        // Same meaning as the replay API: "down" = content below was revealed.
        var dir = when {
          abs(dy) >= abs(dx) && dy > 0 -> "down"
          abs(dy) >= abs(dx) && dy < 0 -> "up"
          dx > 0 -> "right"
          dx < 0 -> "left"
          else -> ""
        }
        if (dir.isEmpty()) {
          val key = "$pkg:${e.className}"
          val prev = lastScroll[key]
          val cur = e.scrollY
          if (prev != null && cur != prev) dir = if (cur > prev) "down" else "up"
          lastScroll[key] = cur
        }
        if (dir.isNotEmpty()) add("scroll", dir = dir)
      }
    }
  }

  /** Button/row name: own text, then content description, then the first labelled descendant (depth <= 3). */
  private fun labelOf(n: AccessibilityNodeInfo?, depth: Int = 0): String {
    if (n == null || n.isPassword) return ""
    n.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { return it.take(80) }
    n.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { return it.take(80) }
    if (depth >= 3) return ""
    for (i in 0 until n.childCount) {
      val l = labelOf(n.getChild(i), depth + 1)
      if (l.isNotEmpty()) return l
    }
    return ""
  }

  private fun appLabel(svc: KabirAccessibilityService, pkg: String): String = try {
    val pm = svc.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
  } catch (ignored: Throwable) {
    pkg
  }
}
