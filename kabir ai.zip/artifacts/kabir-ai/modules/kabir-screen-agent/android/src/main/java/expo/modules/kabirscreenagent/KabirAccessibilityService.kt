package expo.modules.kabirscreenagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlin.math.max
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Eyes + hands of Kabir:
 *  - reads the live UI tree (exact bounds, text, clickable flags)
 *  - injects taps / long-presses / swipes at exact pixel coordinates
 *  - performs global actions (back/home/recents) and text entry
 * Password fields are never read or written. Apps on the blocklist are invisible and untouchable.
 *
 * Note: AccessibilityNodeInfo.recycle() is a no-op on API 33+; on older versions skipped recycling only
 * delays reuse of pooled objects (GC reclaims them), so this file keeps the traversal code simple.
 */
class KabirAccessibilityService : AccessibilityService() {

  companion object {
    @Volatile var instance: KabirAccessibilityService? = null
  }

  private val main = Handler(Looper.getMainLooper())
  private var baseEventTypes = 0
  private val emitContentChanged = Runnable {
    AgentState.changeSeq.incrementAndGet()
    AgentEvents.emit(
      "onScreenChanged",
      mapOf("kind" to "content", "package" to AgentState.foregroundPackage, "at" to SystemClock.elapsedRealtime()),
    )
  }

  override fun onServiceConnected() {
    super.onServiceConnected()
    instance = this
    baseEventTypes = serviceInfo?.eventTypes ?: 0
    AgentState.accessibilityConnected = true
    AgentEvents.emit("onServiceState", mapOf("accessibility" to true))
  }

  override fun onUnbind(intent: android.content.Intent?): Boolean {
    instance = null
    AgentState.accessibilityConnected = false
    AgentEvents.emit("onServiceState", mapOf("accessibility" to false))
    return super.onUnbind(intent)
  }

  override fun onInterrupt() {}

  override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    event ?: return
    if (AgentState.demonstrating) DemoRecorder.onEvent(event, this)
    when (event.eventType) {
      AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
        updateForegroundPackage()
        AgentState.changeSeq.incrementAndGet()
        AgentEvents.emit(
          "onScreenChanged",
          mapOf(
            "kind" to "window",
            "package" to AgentState.foregroundPackage,
            "className" to event.className?.toString(),
            "at" to SystemClock.elapsedRealtime(),
          ),
        )
      }
      AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
        main.removeCallbacks(emitContentChanged)
        main.postDelayed(emitContentChanged, 150) // debounce bursts of UI updates
      }
    }
  }

  private fun updateForegroundPackage() {
    val pkg = rootInActiveWindow?.packageName?.toString() ?: return
    if (pkg != "com.android.systemui") AgentState.foregroundPackage = pkg
  }

  // ───────────────────────────── Screen reading ─────────────────────────────

  /** Flat list of visible nodes with exact screen bounds. Empty when the foreground app is blocked. */
  fun snapshot(maxNodes: Int = 1500): List<UiNode> {
    if (AgentState.isForegroundBlocked()) return emptyList()
    val root = rootInActiveWindow ?: return emptyList()
    if (root.packageName?.toString() in AgentState.blockedPackages) return emptyList()
    val out = ArrayList<UiNode>()
    walk(root, 0, out, maxNodes)
    return out
  }

  private fun walk(node: AccessibilityNodeInfo, depth: Int, out: MutableList<UiNode>, max: Int) {
    if (out.size >= max) return
    if (node.isVisibleToUser) {
      val r = Rect()
      node.getBoundsInScreen(r)
      if (r.width() > 0 && r.height() > 0) {
        out += UiNode(
          text = if (node.isPassword) "" else node.text?.toString().orEmpty(),
          description = if (node.isPassword) "" else node.contentDescription?.toString().orEmpty(),
          viewId = node.viewIdResourceName.orEmpty(),
          className = node.className?.toString().orEmpty(),
          packageName = node.packageName?.toString().orEmpty(),
          clickable = node.isClickable,
          editable = node.isEditable,
          scrollable = node.isScrollable,
          enabled = node.isEnabled,
          bounds = Bounds(r.left, r.top, r.right, r.bottom),
          depth = depth,
        )
      }
    }
    for (i in 0 until node.childCount) {
      val child = node.getChild(i) ?: continue
      walk(child, depth + 1, out, max)
    }
  }

  // ───────────────────────────── Virtual touch ─────────────────────────────

  private fun precheck(x: Float, y: Float): String? {
    if (AgentState.isForegroundBlocked()) return "blocked_app"
    val (w, h) = ScreenMetrics.realSize(this)
    if (x < 0f || y < 0f || x > w || y > h) return "out_of_screen"
    return null
  }

  private fun dispatch(strokes: List<GestureDescription.StrokeDescription>, kind: String, detail: String, onDone: (Boolean, String?) -> Unit) {
    val builder = GestureDescription.Builder()
    strokes.forEach { builder.addStroke(it) }
    val accepted = dispatchGesture(
      builder.build(),
      object : AccessibilityService.GestureResultCallback() {
        override fun onCompleted(g: GestureDescription?) {
          AgentState.logAction(kind, detail, true); onDone(true, null)
        }
        override fun onCancelled(g: GestureDescription?) {
          AgentState.logAction(kind, detail, false); onDone(false, "gesture_cancelled")
        }
      },
      null,
    )
    if (!accepted) {
      AgentState.logAction(kind, detail, false)
      onDone(false, "gesture_rejected")
    }
  }

  /** Tap at exact float pixel coordinates. holdMs > ~500 behaves as long-press. */
  fun gestureTap(x: Float, y: Float, holdMs: Long, onDone: (Boolean, String?) -> Unit) {
    precheck(x, y)?.let { AgentState.logAction("tap", "($x,$y) $it", false); onDone(false, it); return }
    val path = Path().apply { moveTo(x, y) }
    val stroke = GestureDescription.StrokeDescription(path, 0, holdMs.coerceAtLeast(1))
    dispatch(listOf(stroke), if (holdMs > 500) "longPress" else "tap", "($x,$y)", onDone)
  }

  fun gestureSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long, onDone: (Boolean, String?) -> Unit) {
    precheck(x1, y1)?.let { onDone(false, it); return }
    precheck(x2, y2)?.let { onDone(false, it); return }
    val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
    val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1))
    dispatch(listOf(stroke), "swipe", "($x1,$y1)->($x2,$y2)", onDone)
  }

  /**
   * Semantic click: performs ACTION_CLICK on the smallest clickable node containing the point.
   * More robust than a raw touch for some controls. Returns false if no node handled it.
   */
  fun clickNodeAt(x: Float, y: Float): Boolean {
    if (AgentState.isForegroundBlocked()) return false
    val root = rootInActiveWindow ?: return false
    var best: AccessibilityNodeInfo? = null
    var bestArea = Long.MAX_VALUE
    val r = Rect()
    fun visit(n: AccessibilityNodeInfo) {
      n.getBoundsInScreen(r)
      if (n.isVisibleToUser && n.isClickable && n.isEnabled && r.contains(x.toInt(), y.toInt())) {
        val area = r.width().toLong() * r.height()
        if (area < bestArea) { best = n; bestArea = area }
      }
      for (i in 0 until n.childCount) n.getChild(i)?.let { visit(it) }
    }
    visit(root)
    val ok = best?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    AgentState.logAction("nodeClick", "($x,$y)", ok)
    return ok
  }

  /** Two-finger pinch around (cx,cy). span = distance between fingers in px. start>end = pinch in (zoom out). */
  fun gesturePinch(cx: Float, cy: Float, startSpan: Float, endSpan: Float, durationMs: Long, onDone: (Boolean, String?) -> Unit) {
    val hs = startSpan / 2f
    val he = endSpan / 2f
    precheck(cx - max(hs, he), cy)?.let { onDone(false, it); return }
    precheck(cx + max(hs, he), cy)?.let { onDone(false, it); return }
    val left = Path().apply { moveTo(cx - hs, cy); lineTo(cx - he, cy) }
    val right = Path().apply { moveTo(cx + hs, cy); lineTo(cx + he, cy) }
    val d = durationMs.coerceAtLeast(1)
    dispatch(
      listOf(GestureDescription.StrokeDescription(left, 0, d), GestureDescription.StrokeDescription(right, 0, d)),
      "pinch", "($cx,$cy) $startSpan->$endSpan", onDone,
    )
  }

  /** Presses the keyboard's action key (Search/Go/Enter) on the focused field. Android 11+. Null = success. */
  fun pressEnter(): String? {
    if (AgentState.isForegroundBlocked()) return "blocked_app"
    val node = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "no_focused_input"
    if (node.isPassword) return "password_field_refused"
    if (Build.VERSION.SDK_INT < 30) return "unsupported_api"
    val ok = node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    AgentState.logAction("pressEnter", "", ok)
    return if (ok) null else "ime_enter_failed"
  }

  // ───────────────────────────── Teach mode (learning by demonstration) ─────────────────────────────

  private val demoChannel = "kabir_demo"
  private val demoNotificationId = 4712

  /**
   * Starts recording the user's own taps / scrolls / typing (labels + positions only, never passwords).
   * Extra event types are enabled ONLY while recording, and a persistent notification with Stop is shown.
   */
  fun startDemonstration() {
    val info = serviceInfo ?: return
    DemoRecorder.start()
    info.eventTypes = baseEventTypes or
      AccessibilityEvent.TYPE_VIEW_CLICKED or AccessibilityEvent.TYPE_VIEW_LONG_CLICKED or
      AccessibilityEvent.TYPE_VIEW_SCROLLED or AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
    serviceInfo = info
    showDemoNotification()
    AgentState.logAction("teach", "start", true)
    AgentEvents.emit("onServiceState", mapOf("demonstrating" to true))
  }

  fun stopDemonstration() {
    DemoRecorder.stop()
    serviceInfo?.let { it.eventTypes = baseEventTypes; serviceInfo = it }
    getSystemService(NotificationManager::class.java).cancel(demoNotificationId)
    AgentState.logAction("teach", "stop", true)
    AgentEvents.emit("onServiceState", mapOf("demonstrating" to false))
  }

  private fun showDemoNotification() {
    val nm = getSystemService(NotificationManager::class.java)
    if (Build.VERSION.SDK_INT >= 26) {
      nm.createNotificationChannel(
        NotificationChannel(demoChannel, getString(R.string.kabir_demo_channel), NotificationManager.IMPORTANCE_HIGH),
      )
    }
    val stop = PendingIntent.getBroadcast(
      this, 3, Intent(this, DemoStopReceiver::class.java),
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )
    val n = NotificationCompat.Builder(this, demoChannel)
      .setSmallIcon(applicationInfo.icon)
      .setContentTitle(getString(R.string.kabir_demo_title))
      .setContentText(getString(R.string.kabir_demo_text))
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setCategory(NotificationCompat.CATEGORY_SERVICE)
      .addAction(0, getString(R.string.kabir_capture_stop), stop)
      .build()
    nm.notify(demoNotificationId, n)
  }

  // ───────────────────────────── Text + global actions ─────────────────────────────

  /** Returns null on success or an error code. Refuses password fields. */
  fun setFocusedText(text: String, append: Boolean): String? {
    if (AgentState.isForegroundBlocked()) return "blocked_app"
    val node = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "no_focused_input"
    if (node.isPassword) { AgentState.logAction("typeText", "password field refused", false); return "password_field_refused" }
    if (!node.isEditable) return "not_editable"
    val base = if (append) node.text?.toString().orEmpty() else ""
    val args = Bundle().apply {
      putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, base + text)
    }
    val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    AgentState.logAction("typeText", "${text.length} chars", ok)
    return if (ok) null else "set_text_failed"
  }

  fun global(name: String): Boolean {
    val action = when (name) {
      "back" -> GLOBAL_ACTION_BACK
      "home" -> GLOBAL_ACTION_HOME
      "recents" -> GLOBAL_ACTION_RECENTS
      "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
      "quickSettings" -> GLOBAL_ACTION_QUICK_SETTINGS
      else -> return false
    }
    val ok = performGlobalAction(action)
    AgentState.logAction("global", name, ok)
    return ok
  }
}
