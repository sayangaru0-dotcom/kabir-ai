package expo.modules.kabirscreenagent

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Handles the "Stop" button of the teach-mode notification. The recorded steps stay buffered for the app to collect. */
class DemoStopReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    KabirAccessibilityService.instance?.stopDemonstration()
  }
}
