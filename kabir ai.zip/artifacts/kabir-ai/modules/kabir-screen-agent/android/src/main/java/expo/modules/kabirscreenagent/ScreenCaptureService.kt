package expo.modules.kabirscreenagent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Continuous screen capture as a fast, downscaled frame stream.
 * MediaProjection -> VirtualDisplay -> ImageReader(RGBA_8888, 2 buffers) -> FrameAnalyzer.
 * Frames are processed in memory only: never written to disk, never sent over the network.
 * Runs as a foreground service with a persistent "Kabir is reading your screen" notification + Stop button.
 */
class ScreenCaptureService : Service() {

  companion object {
    const val ACTION_START = "expo.modules.kabirscreenagent.START"
    const val ACTION_STOP = "expo.modules.kabirscreenagent.STOP"
    const val EXTRA_RESULT_CODE = "resultCode"
    const val EXTRA_DATA = "data"
    const val EXTRA_MAX_DIM = "maxDim"
    const val EXTRA_FPS = "fps"
    const val EXTRA_OCR = "ocr"
    const val EXTRA_DEVA = "devanagari"
    const val EXTRA_CHANGE = "changeThreshold"
    const val EXTRA_OCR_INTERVAL = "ocrIntervalMs"
    private const val CHANNEL_ID = "kabir_screen_agent"
    private const val NOTIFICATION_ID = 4711
  }

  private var thread: HandlerThread? = null
  private var handler: Handler? = null
  private var projection: MediaProjection? = null
  private var projectionCallback: MediaProjection.Callback? = null
  private var virtualDisplay: VirtualDisplay? = null
  private var imageReader: ImageReader? = null
  private var analyzer: FrameAnalyzer? = null
  private var scratch: Bitmap? = null
  private var frameW = 0
  private var frameH = 0
  private var maxDim = 720
  private var minIntervalMs = 125L
  private var lastProcessed = 0L

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    thread = HandlerThread("kabir-capture").also { it.start() }
    handler = Handler(thread!!.looper)
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_STOP -> {
        shutdown()
        return START_NOT_STICKY
      }
      ACTION_START -> {
        if (intent == null) { shutdown(); return START_NOT_STICKY }
        // Must go to the foreground immediately (5 s limit after startForegroundService).
        enterForeground()
        if (AgentState.captureRunning) stopCapture()
        try {
          startCapture(intent)
        } catch (t: Throwable) {
          AgentEvents.emit("onAgentError", mapOf("where" to "capture", "message" to (t.message ?: "capture failed")))
          shutdown()
        }
      }
      else -> shutdown()
    }
    return START_NOT_STICKY // never auto-restart: the one-time projection token cannot be reused
  }

  // ───────────────────────────── Notification ─────────────────────────────

  private fun enterForeground() {
    val nm = getSystemService(NotificationManager::class.java)
    if (Build.VERSION.SDK_INT >= 26) {
      nm.createNotificationChannel(
        NotificationChannel(CHANNEL_ID, getString(R.string.kabir_capture_channel), NotificationManager.IMPORTANCE_LOW),
      )
    }
    val stop = PendingIntent.getService(
      this, 1, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )
    val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
      PendingIntent.getActivity(this, 2, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }
    val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(applicationInfo.icon)
      .setContentTitle(getString(R.string.kabir_capture_title))
      .setContentText(getString(R.string.kabir_capture_text))
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setCategory(NotificationCompat.CATEGORY_SERVICE)
      .setContentIntent(open)
      .addAction(0, getString(R.string.kabir_capture_stop), stop)
      .build()

    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
  }

  // ───────────────────────────── Capture pipeline ─────────────────────────────

  private fun startCapture(intent: Intent) {
    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
    val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
      intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
    } else {
      @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
    }
    requireNotNull(data) { "Missing screen capture permission result." }

    maxDim = intent.getIntExtra(EXTRA_MAX_DIM, 720).coerceIn(240, 1920)
    val fps = intent.getIntExtra(EXTRA_FPS, 8).coerceIn(1, 30)
    minIntervalMs = (1000L / fps)
    val opts = AnalyzerOptions(
      ocrEnabled = intent.getBooleanExtra(EXTRA_OCR, true),
      devanagari = intent.getBooleanExtra(EXTRA_DEVA, false),
      changeThreshold = intent.getFloatExtra(EXTRA_CHANGE, 0.02f),
      ocrMinIntervalMs = intent.getLongExtra(EXTRA_OCR_INTERVAL, 400L),
    )

    val mpm = getSystemService(MediaProjectionManager::class.java)
    // Newer SDKs annotate getMediaProjection() as @Nullable (it returns null if the permission result is no longer valid).
    val proj: MediaProjection = mpm.getMediaProjection(resultCode, data)
      ?: throw IllegalStateException("Android did not return a screen capture session. Start screen reading again and choose 'Start now'.")
    projection = proj

    // Android 14+: callback MUST be registered before creating the VirtualDisplay.
    val cb = object : MediaProjection.Callback() {
      override fun onStop() {
        handler?.post { shutdown() } // user revoked via the system "stop sharing" chip
      }
    }
    projectionCallback = cb
    proj.registerCallback(cb, handler)

    val (sw, sh) = ScreenMetrics.realSize(this)
    val (fw, fh) = frameSizeFor(sw, sh)
    analyzer = FrameAnalyzer(CoordinateMapper(fw, fh, sw, sh), opts)
    buildPipeline()

    AgentState.captureRunning = true
    AgentEvents.emit("onServiceState", mapOf("capture" to true))
  }

  private fun frameSizeFor(sw: Int, sh: Int): Pair<Int, Int> {
    val scale = min(1f, maxDim.toFloat() / max(sw, sh))
    return max(2, (sw * scale).roundToInt()) to max(2, (sh * scale).roundToInt())
  }

  /** (Re)creates the ImageReader at the current rotation. The VirtualDisplay is created ONCE and resized
   *  afterwards, because Android 14 forbids creating a second VirtualDisplay from the same projection. */
  private fun buildPipeline() {
    val proj = projection ?: return
    val (sw, sh) = ScreenMetrics.realSize(this)
    val (fw, fh) = frameSizeFor(sw, sh)
    frameW = fw; frameH = fh

    val reader = ImageReader.newInstance(fw, fh, PixelFormat.RGBA_8888, 2)
    reader.setOnImageAvailableListener({ r -> onImage(r) }, handler)

    val dpi = resources.displayMetrics.densityDpi
    val vd = virtualDisplay
    if (vd == null) {
      virtualDisplay = proj.createVirtualDisplay(
        "KabirCapture", fw, fh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
        reader.surface, null, handler,
      )
    } else {
      vd.resize(fw, fh, dpi)
      vd.surface = reader.surface
    }
    imageReader?.close()
    imageReader = reader

    scratch?.recycle(); scratch = null
    analyzer?.updateMapper(CoordinateMapper(fw, fh, sw, sh))
    AgentState.screenWidth = sw; AgentState.screenHeight = sh
    AgentState.frameWidth = fw; AgentState.frameHeight = fh
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    if (AgentState.captureRunning) handler?.post { runCatching { buildPipeline() } }
  }

  private fun onImage(reader: ImageReader) {
    val image = reader.acquireLatestImage() ?: return
    try {
      val now = SystemClock.elapsedRealtime()
      if (now - lastProcessed < minIntervalMs) return // drop frame: keeps latency low, never queues up
      lastProcessed = now

      val plane = image.planes[0]
      val pixelStride = plane.pixelStride
      val paddedW = plane.rowStride / pixelStride
      var bmp = scratch
      if (bmp == null || bmp.width != paddedW || bmp.height != image.height) {
        bmp?.recycle()
        bmp = Bitmap.createBitmap(paddedW, image.height, Bitmap.Config.ARGB_8888)
        scratch = bmp
      }
      plane.buffer.rewind()
      bmp.copyPixelsFromBuffer(plane.buffer)
      analyzer?.process(bmp, min(image.width, paddedW), image.height, now)
    } catch (t: Throwable) {
      AgentEvents.emit("onAgentError", mapOf("where" to "frame", "message" to (t.message ?: "frame failed")))
    } finally {
      image.close()
    }
  }

  // ───────────────────────────── Teardown ─────────────────────────────

  private fun stopCapture() {
    AgentState.captureRunning = false
    AgentState.ocrItems = emptyList()
    AgentState.measuredFps = 0f
    runCatching { imageReader?.setOnImageAvailableListener(null, null) }
    runCatching { virtualDisplay?.release() }
    runCatching { imageReader?.close() }
    projectionCallback?.let { cb -> runCatching { projection?.unregisterCallback(cb) } }
    runCatching { projection?.stop() }
    analyzer?.release()
    scratch?.recycle()
    virtualDisplay = null; imageReader = null; projection = null
    projectionCallback = null; analyzer = null; scratch = null
    AgentEvents.emit("onServiceState", mapOf("capture" to false))
  }

  private fun shutdown() {
    stopCapture()
    stopForeground(STOP_FOREGROUND_REMOVE)
    stopSelf()
  }

  override fun onTaskRemoved(rootIntent: Intent?) {
    shutdown() // privacy default: swiping the app away ends screen reading
    super.onTaskRemoved(rootIntent)
  }

  override fun onDestroy() {
    stopCapture()
    thread?.quitSafely()
    super.onDestroy()
  }
}
