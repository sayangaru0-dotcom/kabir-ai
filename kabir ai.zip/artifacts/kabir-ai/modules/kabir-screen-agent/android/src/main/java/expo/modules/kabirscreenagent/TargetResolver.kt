package expo.modules.kabirscreenagent

import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Fuses the two sources of "where is X on screen":
 *  1. Accessibility nodes  -> exact OS bounds, knows what is clickable (most precise)
 *  2. OCR boxes            -> works on anything drawn as pixels (games, canvas, WebViews, images)
 * OCR hits that sit inside a clickable node are snapped to that node so the tap lands on the real control.
 */
object TargetResolver {

  fun find(query: String, nodes: List<UiNode>, ocr: List<OcrItem>, limit: Int = 8): List<Target> {
    val q = normalize(query)
    if (q.isEmpty()) return emptyList()
    val found = ArrayList<Target>()

    for (n in nodes) {
      if (!n.enabled) continue
      val s = max(
        if (n.text.isNotBlank()) matchScore(normalize(n.text), q) else 0f,
        if (n.description.isNotBlank()) matchScore(normalize(n.description), q) else 0f,
      )
      if (s <= 0f) continue
      val label = n.text.ifBlank { n.description }
      val conf = min(1f, s + if (n.clickable) 0.05f else 0f)
      found += Target(
        n.bounds.centerX, n.bounds.centerY,
        if (n.clickable) "node" else "node-static", label, n.bounds, conf,
      )
    }

    val clickables = nodes.filter { it.clickable && it.enabled }
    for (o in ocr) {
      val s = matchScore(normalize(o.text), q)
      if (s <= 0f) continue
      val conf = s * (0.6f + 0.4f * o.confidence.coerceIn(0f, 1f))
      val cx = o.bounds.centerX
      val cy = o.bounds.centerY
      val host = clickables.filter { it.bounds.contains(cx, cy) }.minByOrNull { it.bounds.area }
      // Snap to the host control only if it is a "tight" control (button-sized). If the host is a huge
      // container (a whole list row), the text centre is the more precise tap point.
      if (host != null && host.bounds.area <= 6 * max(1L, o.bounds.area)) {
        found += Target(host.bounds.centerX, host.bounds.centerY, "ocr+node", o.text, host.bounds, conf)
      } else {
        found += Target(cx, cy, "ocr", o.text, o.bounds, conf)
      }
    }

    // Best first; drop near-duplicates (same control seen via node and OCR).
    val kept = ArrayList<Target>()
    for (t in found.sortedByDescending { it.confidence }) {
      if (kept.none { hypot((it.x - t.x).toDouble(), (it.y - t.y).toDouble()) < 24.0 }) kept += t
      if (kept.size >= limit) break
    }
    return kept
  }

  private fun normalize(s: String) =
    s.lowercase(Locale.ROOT).trim().replace(Regex("\\s+"), " ")

  private fun matchScore(label: String, q: String): Float {
    if (label.isEmpty()) return 0f
    if (label == q) return 1f
    if (label.contains(q)) {
      val coverage = q.length.toFloat() / label.length
      val wholeWord = Regex("(^|\\s)" + Regex.escape(q) + "(\\s|$)").containsMatchIn(label)
      return min(0.95f, 0.5f + 0.4f * coverage + if (wholeWord) 0.05f else 0f)
    }
    // Typo tolerance for OCR noise ("Sena" vs "Send").
    if (q.length >= 4 && abs(label.length - q.length) <= 3) {
      val ratio = 1f - levenshtein(label, q).toFloat() / max(label.length, q.length)
      if (ratio >= 0.8f) return 0.6f * ratio
    }
    return 0f
  }

  private fun levenshtein(a: String, b: String): Int {
    var prev = IntArray(b.length + 1) { it }
    var cur = IntArray(b.length + 1)
    for (i in 1..a.length) {
      cur[0] = i
      for (j in 1..b.length) {
        val cost = if (a[i - 1] == b[j - 1]) 0 else 1
        cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
      }
      val t = prev; prev = cur; cur = t
    }
    return prev[b.length]
  }
}
