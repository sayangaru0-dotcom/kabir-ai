package expo.modules.kabirscreenagent

import android.graphics.Bitmap
import android.graphics.Color
import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class AnalyzerOptions(
  val ocrEnabled: Boolean = true,
  val devanagari: Boolean = false,
  val changeThreshold: Float = 0.02f,   // fraction of sampled cells that must change
  val ocrMinIntervalMs: Long = 400,
)

/**
 * Per-frame pipeline:
 *  1. Change detection (sub-millisecond): luminance sampled on a grid, compared with previous frame.
 *  2. OCR (tens to a few hundred ms, on-device, async): only when the screen changed, never in parallel.
 *  3. Map OCR boxes from frame pixels to real screen pixels via CoordinateMapper.
 */
class FrameAnalyzer(
  @Volatile private var mapper: CoordinateMapper,
  private val opts: AnalyzerOptions,
) {
  private val gridX = 32
  private val gridY = 56
  private var prev: IntArray? = null
  private var lastOcrAt = 0L
  private var dirty = true // something changed since the last OCR pass
  private var lastFrameAt = 0L
  private val ocrBusy = AtomicBoolean(false)
  private val executor = Executors.newSingleThreadExecutor()

  private val latin: TextRecognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
  private val deva: TextRecognizer by lazy {
    TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
  }

  fun updateMapper(m: CoordinateMapper) {
    mapper = m
    prev = null
    dirty = true
  }

  /** @param frame bitmap that may be wider than frameW (row padding); only [0,frameW)x[0,frameH) is valid. */
  fun process(frame: Bitmap, frameW: Int, frameH: Int, now: Long) {
    if (lastFrameAt != 0L) {
      val inst = 1000f / (now - lastFrameAt).coerceAtLeast(1)
      AgentState.measuredFps = if (AgentState.measuredFps == 0f) inst else AgentState.measuredFps * 0.8f + inst * 0.2f
    }
    lastFrameAt = now
    AgentState.lastFrameAt = now

    if (AgentState.isForegroundBlocked()) {
      AgentState.ocrItems = emptyList() // never keep content of a blocked app
      prev = null
      return
    }

    val score = changeScore(frame, frameW, frameH)
    AgentState.lastChangeScore = score
    val changed = score >= opts.changeThreshold
    if (changed) {
      dirty = true
      AgentState.changeSeq.incrementAndGet()
      AgentEvents.emit("onScreenChanged", mapOf("kind" to "visual", "score" to score, "at" to now))
    }

    val due = now - lastOcrAt >= opts.ocrMinIntervalMs
    if (opts.ocrEnabled && dirty && due && ocrBusy.compareAndSet(false, true)) {
      dirty = false
      lastOcrAt = now
      // Copy: the scratch bitmap is reused for the next frame while OCR is still running.
      val copy = if (frame.width == frameW && frame.height == frameH) {
        frame.copy(Bitmap.Config.ARGB_8888, false)
      } else {
        Bitmap.createBitmap(frame, 0, 0, frameW, frameH)
      }
      runOcr(copy, now, score)
    }
  }

  private fun changeScore(frame: Bitmap, w: Int, h: Int): Float {
    val cur = IntArray(gridX * gridY)
    var i = 0
    for (gy in 0 until gridY) {
      val y = ((gy + 0.5f) * h / gridY).toInt().coerceIn(0, h - 1)
      for (gx in 0 until gridX) {
        val x = ((gx + 0.5f) * w / gridX).toInt().coerceIn(0, w - 1)
        val p = frame.getPixel(x, y)
        cur[i++] = (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000
      }
    }
    val old = prev
    prev = cur
    if (old == null) return 1f
    var diffCells = 0
    for (k in cur.indices) if (kotlin.math.abs(cur[k] - old[k]) > 24) diffCells++
    return diffCells.toFloat() / cur.size
  }

  private fun runOcr(bitmap: Bitmap, frameTime: Long, score: Float) {
    val started = SystemClock.elapsedRealtime()
    val m = mapper
    val input = InputImage.fromBitmap(bitmap, 0)
    val tasks = ArrayList<com.google.android.gms.tasks.Task<Text>>()
    tasks += latin.process(input)
    if (opts.devanagari) tasks += deva.process(input)

    Tasks.whenAllSuccess<Text>(tasks)
      .addOnSuccessListener(executor) { results ->
        val items = dedupe(results.flatMap { toItems(it, m) })
        val ms = SystemClock.elapsedRealtime() - started
        AgentState.ocrItems = items
        AgentState.ocrAt = SystemClock.elapsedRealtime()
        AgentState.lastOcrMs = ms
        AgentEvents.emit(
          "onFrameAnalysis",
          mapOf(
            "at" to frameTime, "ocrLatencyMs" to ms, "changeScore" to score,
            "fps" to AgentState.measuredFps, "lineCount" to items.count { it.level == "line" },
            "frameWidth" to m.frameW, "frameHeight" to m.frameH,
            "screenWidth" to m.screenW, "screenHeight" to m.screenH,
          ),
        )
      }
      .addOnFailureListener(executor) { e ->
        AgentEvents.emit("onAgentError", mapOf("where" to "ocr", "message" to (e.message ?: "OCR failed")))
      }
      .addOnCompleteListener(executor) {
        bitmap.recycle()
        ocrBusy.set(false)
      }
  }

  private fun toItems(text: Text, m: CoordinateMapper): List<OcrItem> {
    val out = ArrayList<OcrItem>()
    for (block in text.textBlocks) for (line in block.lines) {
      line.boundingBox?.let { out += OcrItem(line.text, m.toScreen(it), line.confidence, "line") }
      for (el in line.elements) el.boundingBox?.let { out += OcrItem(el.text, m.toScreen(it), el.confidence, "word") }
    }
    return out
  }

  /** Latin + Devanagari passes can both "see" the same word; keep the higher-confidence box. */
  private fun dedupe(items: List<OcrItem>): List<OcrItem> {
    if (!opts.devanagari) return items
    val kept = ArrayList<OcrItem>()
    for (it in items.sortedByDescending { it.confidence }) {
      if (kept.none { k -> k.level == it.level && k.bounds.iou(it.bounds) > 0.6f }) kept += it
    }
    return kept
  }

  fun release() {
    executor.shutdown()
    runCatching { latin.close() }
    if (opts.devanagari) runCatching { deva.close() }
  }
}
