package expo.modules.kabirscreenagent

import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Rectangle in REAL SCREEN PIXELS (same space that gesture injection uses). */
data class Bounds(val left: Int, val top: Int, val right: Int, val bottom: Int) {
  val width get() = right - left
  val height get() = bottom - top
  val centerX: Float get() = (left + right) / 2f
  val centerY: Float get() = (top + bottom) / 2f
  val area: Long get() = max(0, width).toLong() * max(0, height)

  fun contains(x: Float, y: Float) = x >= left && x < right && y >= top && y < bottom

  fun iou(o: Bounds): Float {
    val iw = min(right, o.right) - max(left, o.left)
    val ih = min(bottom, o.bottom) - max(top, o.top)
    if (iw <= 0 || ih <= 0) return 0f
    val inter = iw.toLong() * ih
    val union = area + o.area - inter
    return if (union <= 0) 0f else inter.toFloat() / union
  }

  fun toMap(): Map<String, Any?> = mapOf(
    "left" to left, "top" to top, "right" to right, "bottom" to bottom,
    "width" to width, "height" to height,
    "centerX" to centerX, "centerY" to centerY,
  )
}

/** Node from the Accessibility tree (exact bounds straight from the OS). */
data class UiNode(
  val text: String,
  val description: String,
  val viewId: String,
  val className: String,
  val packageName: String,
  val clickable: Boolean,
  val editable: Boolean,
  val scrollable: Boolean,
  val enabled: Boolean,
  val bounds: Bounds,
  val depth: Int,
) {
  fun toMap(): Map<String, Any?> = mapOf(
    "text" to text, "description" to description, "viewId" to viewId,
    "className" to className, "package" to packageName,
    "clickable" to clickable, "editable" to editable, "scrollable" to scrollable,
    "enabled" to enabled, "bounds" to bounds.toMap(), "depth" to depth,
  )
}

/** Text found by OCR in a captured frame, already converted to screen pixels. */
data class OcrItem(
  val text: String,
  val bounds: Bounds,
  val confidence: Float,
  val level: String, // "line" | "word"
) {
  fun toMap(): Map<String, Any?> = mapOf(
    "text" to text, "bounds" to bounds.toMap(), "confidence" to confidence, "level" to level,
  )
}

/** A resolved place to tap. x/y are float screen pixels. */
data class Target(
  val x: Float,
  val y: Float,
  val source: String, // "node" | "node-static" | "ocr" | "ocr+node"
  val label: String,
  val bounds: Bounds,
  val confidence: Float,
) {
  fun toMap(): Map<String, Any?> = mapOf(
    "x" to x, "y" to y, "source" to source, "label" to label,
    "bounds" to bounds.toMap(), "confidence" to confidence,
  )
}

/**
 * Frame space -> screen space.
 * Frames are downscaled for speed, so every detected box must be scaled back:
 *   screenX = frameX * (screenW / frameW),  screenY = frameY * (screenH / frameH)
 */
class CoordinateMapper(
  val frameW: Int,
  val frameH: Int,
  val screenW: Int,
  val screenH: Int,
) {
  private val sx = screenW.toFloat() / frameW
  private val sy = screenH.toFloat() / frameH

  fun toScreen(r: android.graphics.Rect) = Bounds(
    (r.left * sx).roundToInt().coerceIn(0, screenW),
    (r.top * sy).roundToInt().coerceIn(0, screenH),
    (r.right * sx).roundToInt().coerceIn(0, screenW),
    (r.bottom * sy).roundToInt().coerceIn(0, screenH),
  )
}

object ScreenMetrics {
  /** Real display size in pixels for the current rotation (includes status/nav bars). */
  fun realSize(ctx: Context): Pair<Int, Int> {
    val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    return if (Build.VERSION.SDK_INT >= 30) {
      val b = wm.maximumWindowMetrics.bounds
      b.width() to b.height()
    } else {
      val dm = DisplayMetrics()
      @Suppress("DEPRECATION")
      wm.defaultDisplay.getRealMetrics(dm)
      dm.widthPixels to dm.heightPixels
    }
  }
}
