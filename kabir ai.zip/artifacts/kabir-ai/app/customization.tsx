import { useEffect, useState } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { BrandMark } from "@/components/BrandMark";
import { useKabir } from "@/context/KabirContext";
import {
  COLOR_LABELS,
  CUSTOMIZATION_COLOR_KEYS,
  LOGO_VARIANTS,
  THEME_PRESETS,
  isHexColor,
  type CustomizationColorKey,
} from "@/constants/themes";
import { useColors } from "@/hooks/useColors";

const QUICK_SWATCHES = [
  "#A3EDBC",
  "#69D0E7",
  "#D6A0EF",
  "#FFB07C",
  "#FFA9BF",
  "#5DF2CB",
  "#9CBAFF",
  "#E9C77A",
  "#87DCE7",
  "#F46F5E",
  "#91E4D1",
  "#F2F2F2",
];

export default function CustomizationScreen() {
  const router = useRouter();
  const colors = useColors();
  const {
    appearance,
    setThemePreset,
    setColorOverride,
    resetCustomColors,
    setLogoVariant,
    setBrandName,
  } = useKabir();
  const [editingColor, setEditingColor] = useState<CustomizationColorKey>("primary");
  const [colorDraft, setColorDraft] = useState<string | null>(null);
  const [hexInvalid, setHexInvalid] = useState(false);
  const brandName = appearance.brandName.trim() || "Kabir AI";
  const selectedColor = colors[editingColor];

  useEffect(() => {
    setColorDraft(null);
    setHexInvalid(false);
  }, [editingColor, appearance.themeId, appearance.colorOverrides]);

  function updateColorDraft(value: string) {
    setColorDraft(value);
    if (isHexColor(value)) {
      setHexInvalid(false);
      setColorOverride(editingColor, value);
      return;
    }
    setHexInvalid(value.length >= 7);
  }

  return (
    <SafeAreaView
      style={[styles.safe, { backgroundColor: colors.background }]}
      edges={["top", "bottom"]}
    >
      <ScrollView
        contentContainerStyle={styles.page}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.content}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Back to Settings"
            onPress={() => router.back()}
            style={({ pressed }) => [
              styles.backButton,
              { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.72 : 1 },
            ]}
          >
            <Feather name="arrow-left" size={17} color={colors.foreground} />
            <Text style={[styles.backText, { color: colors.foreground }]}>Settings</Text>
          </Pressable>

          <View style={styles.heading}>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>OPEN TEST CUSTOMIZATION</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Make Kabir yours</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Choose a dark theme, mix live hex colors, and preview in-app branding. Everything is
              available without a subscription or password.
            </Text>
          </View>

          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.sectionHeading}>
              <View style={styles.sectionCopy}>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Theme library</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                  {THEME_PRESETS.length} ready-made palettes. Selecting one replaces the current custom mix.
                </Text>
              </View>
              {Object.keys(appearance.colorOverrides).length > 0 && (
                <View style={[styles.mixBadge, { backgroundColor: colors.secondary }]}>
                  <Text style={[styles.mixBadgeText, { color: colors.primary }]}>CUSTOM MIX</Text>
                </View>
              )}
            </View>

            <View style={styles.themeGrid}>
              {THEME_PRESETS.map((theme) => {
                const selected = appearance.themeId === theme.id;
                const swatches = [
                  theme.colors.background,
                  theme.colors.card,
                  theme.colors.primary,
                  theme.colors.accent,
                ];
                return (
                  <Pressable
                    key={theme.id}
                    accessibilityRole="radio"
                    accessibilityState={{ selected }}
                    onPress={() => setThemePreset(theme.id)}
                    style={({ pressed }) => [
                      styles.themeCard,
                      {
                        backgroundColor: colors.background,
                        borderColor: selected ? colors.primary : colors.border,
                        opacity: pressed ? 0.76 : 1,
                      },
                    ]}
                  >
                    <View style={styles.swatchRow}>
                      {swatches.map((swatch, index) => (
                        <View
                          key={`${theme.id}-${index}`}
                          style={[
                            styles.themeSwatch,
                            { backgroundColor: swatch, borderColor: colors.border },
                          ]}
                        />
                      ))}
                    </View>
                    <Text
                      numberOfLines={1}
                      style={[
                        styles.themeName,
                        { color: selected ? colors.primary : colors.foreground },
                      ]}
                    >
                      {theme.name}
                    </Text>
                    {selected && (
                      <Feather
                        name="check-circle"
                        size={13}
                        color={colors.primary}
                        style={styles.themeCheck}
                      />
                    )}
                  </Pressable>
                );
              })}
            </View>
          </View>

          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.sectionHeading}>
              <View style={styles.sectionCopy}>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Live color mixer</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                  Pick a UI color, enter a six-digit hex value, and see valid changes across Kabir immediately.
                </Text>
              </View>
              <Feather name="droplet" size={18} color={colors.primary} />
            </View>

            <View style={styles.colorKeyGrid}>
              {CUSTOMIZATION_COLOR_KEYS.map((key) => {
                const selected = editingColor === key;
                return (
                  <Pressable
                    key={key}
                    accessibilityRole="radio"
                    accessibilityState={{ selected }}
                    onPress={() => setEditingColor(key)}
                    style={[
                      styles.colorKey,
                      {
                        backgroundColor: selected ? colors.primary : colors.background,
                        borderColor: selected ? colors.primary : colors.border,
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.colorKeyText,
                        { color: selected ? colors.background : colors.foreground },
                      ]}
                    >
                      {COLOR_LABELS[key]}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            <View style={[styles.colorInputCard, { backgroundColor: colors.background, borderColor: colors.border }]}>
              <View
                accessibilityLabel={`${COLOR_LABELS[editingColor]} preview color`}
                style={[
                  styles.largeSwatch,
                  { backgroundColor: selectedColor, borderColor: colors.border },
                ]}
              />
              <View style={styles.colorInputCopy}>
                <Text style={[styles.fieldLabel, { color: colors.foreground }]}>
                  {COLOR_LABELS[editingColor]}
                </Text>
                <TextInput
                  accessibilityLabel={`Hex value for ${COLOR_LABELS[editingColor]}`}
                  autoCapitalize="characters"
                  autoCorrect={false}
                  maxLength={7}
                  onChangeText={updateColorDraft}
                  placeholder="#A3EDBC"
                  placeholderTextColor={colors.mutedForeground}
                  spellCheck={false}
                  style={[
                    styles.hexInput,
                    {
                      backgroundColor: colors.card,
                      borderColor: hexInvalid ? colors.destructive : colors.border,
                      color: colors.foreground,
                    },
                  ]}
                  value={colorDraft ?? selectedColor}
                />
              </View>
            </View>
            <View style={styles.quickPicker}>
              <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Quick color picker</Text>
              <View style={styles.quickSwatches}>
                {QUICK_SWATCHES.map((swatch) => (
                  <Pressable
                    key={swatch}
                    accessibilityRole="button"
                    accessibilityLabel={`Set ${COLOR_LABELS[editingColor]} to ${swatch}`}
                    onPress={() => setColorOverride(editingColor, swatch)}
                    style={[
                      styles.quickSwatch,
                      {
                        backgroundColor: swatch,
                        borderColor: selectedColor.toUpperCase() === swatch ? colors.foreground : colors.border,
                        borderWidth: selectedColor.toUpperCase() === swatch ? 2 : 1,
                      },
                    ]}
                  />
                ))}
              </View>
            </View>
            <Text style={[styles.helperText, { color: hexInvalid ? colors.destructive : colors.mutedForeground }]}>
              {hexInvalid ? "Use exactly six hex digits, for example #A3EDBC." : "Format: #RRGGBB. Valid colors update the app as you type."}
            </Text>

            <Pressable
              accessibilityRole="button"
              disabled={Object.keys(appearance.colorOverrides).length === 0}
              onPress={resetCustomColors}
              style={({ pressed }) => [
                styles.resetButton,
                {
                  borderColor: colors.border,
                  opacity: Object.keys(appearance.colorOverrides).length === 0 ? 0.45 : pressed ? 0.72 : 1,
                },
              ]}
            >
              <Feather name="rotate-ccw" size={14} color={colors.foreground} />
              <Text style={[styles.resetText, { color: colors.foreground }]}>Reset custom colors</Text>
            </Pressable>
          </View>

          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.sectionHeading}>
              <View style={styles.sectionCopy}>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>In-app branding</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                  Switch the internal logo mark and test a display name.
                </Text>
              </View>
            </View>
            <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Display name</Text>
            <TextInput
              accessibilityLabel="In-app brand name"
              autoCapitalize="words"
              maxLength={28}
              onChangeText={setBrandName}
              placeholder="Kabir AI"
              placeholderTextColor={colors.mutedForeground}
              style={[
                styles.brandInput,
                { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground },
              ]}
              value={appearance.brandName}
            />
            <View style={styles.logoGrid}>
              {LOGO_VARIANTS.map((variant) => {
                const selected = appearance.logoVariant === variant.id;
                return (
                  <Pressable
                    key={variant.id}
                    accessibilityRole="radio"
                    accessibilityState={{ selected }}
                    onPress={() => setLogoVariant(variant.id)}
                    style={[
                      styles.logoOption,
                      {
                        backgroundColor: colors.background,
                        borderColor: selected ? colors.primary : colors.border,
                      },
                    ]}
                  >
                    <BrandMark variant={variant.id} brandName={brandName} size={34} />
                    <Text
                      style={[
                        styles.logoName,
                        { color: selected ? colors.primary : colors.foreground },
                      ]}
                    >
                      {variant.name}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
            <Text style={[styles.helperText, { color: colors.mutedForeground }]}>
              This changes Kabir’s in-app mark only; the installed launcher icon is unchanged.
            </Text>
          </View>

          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Live preview</Text>
            <View style={[styles.previewFrame, { backgroundColor: colors.background, borderColor: colors.border }]}>
              <View style={styles.previewBrand}>
                <BrandMark variant={appearance.logoVariant} brandName={brandName} size={42} />
                <View style={styles.previewBrandCopy}>
                  <Text numberOfLines={1} style={[styles.previewBrandName, { color: colors.foreground }]}>
                    {brandName}
                  </Text>
                  <Text style={[styles.helperText, { color: colors.mutedForeground }]}>Voice assistant</Text>
                </View>
                <View style={[styles.previewAccentDot, { backgroundColor: colors.accent }]} />
              </View>
              <View style={[styles.previewCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Text style={[styles.previewCardTitle, { color: colors.foreground }]}>Your theme is live</Text>
                <Text style={[styles.helperText, { color: colors.mutedForeground }]}>
                  Previewing surfaces, text, and action colors.
                </Text>
                <Pressable
                  accessibilityRole="button"
                  style={[styles.previewButton, { backgroundColor: colors.primary }]}
                >
                  <Text style={[styles.previewButtonText, { color: colors.primaryForeground }]}>
                    Primary action
                  </Text>
                </Pressable>
              </View>
            </View>
          </View>

          <Text style={[styles.deviceNote, { color: colors.mutedForeground }]}>
            Appearance and branding choices are saved on this device. iOS system tab controls may retain their system appearance.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  page: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 52 },
  content: { width: "100%", maxWidth: 640, alignSelf: "center", gap: 16 },
  backButton: {
    alignSelf: "flex-start",
    minHeight: 40,
    borderWidth: 1,
    borderRadius: 13,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  backText: { fontSize: 12, fontWeight: "700" },
  heading: { gap: 7, paddingTop: 3, paddingBottom: 2 },
  eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 1.6 },
  title: { fontSize: 30, lineHeight: 36, fontWeight: "700", letterSpacing: -0.6 },
  subtitle: { fontSize: 13, lineHeight: 20, maxWidth: 520 },
  section: { borderWidth: 1, borderRadius: 22, padding: 16, gap: 14 },
  sectionHeading: { flexDirection: "row", alignItems: "center", gap: 10 },
  sectionCopy: { flex: 1, gap: 3 },
  sectionTitle: { fontSize: 15, fontWeight: "700" },
  sectionSubtitle: { fontSize: 11, lineHeight: 16 },
  mixBadge: { borderRadius: 9, paddingVertical: 7, paddingHorizontal: 9 },
  mixBadgeText: { fontSize: 9, fontWeight: "800", letterSpacing: 0.5 },
  themeGrid: { flexDirection: "row", flexWrap: "wrap", gap: 9, justifyContent: "space-between" },
  themeCard: {
    width: "48%",
    minHeight: 68,
    borderWidth: 1,
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 10,
    justifyContent: "center",
    gap: 8,
  },
  swatchRow: { flexDirection: "row", gap: 5 },
  themeSwatch: { width: 19, height: 19, borderWidth: 1, borderRadius: 7 },
  themeName: { fontSize: 11, fontWeight: "700", paddingRight: 17 },
  themeCheck: { position: "absolute", right: 9, bottom: 10 },
  colorKeyGrid: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  colorKey: { minHeight: 32, paddingHorizontal: 10, borderWidth: 1, borderRadius: 10, justifyContent: "center" },
  colorKeyText: { fontSize: 10, fontWeight: "700" },
  colorInputCard: {
    minHeight: 76,
    borderWidth: 1,
    borderRadius: 14,
    padding: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  largeSwatch: { width: 52, height: 52, borderRadius: 13, borderWidth: 1 },
  colorInputCopy: { flex: 1, gap: 6 },
  fieldLabel: { fontSize: 11, fontWeight: "700" },
  hexInput: { height: 36, borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, fontSize: 12, fontWeight: "700" },
  quickPicker: { gap: 8 },
  quickSwatches: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  quickSwatch: { width: 28, height: 28, borderRadius: 14 },
  helperText: { fontSize: 10, lineHeight: 15 },
  resetButton: {
    alignSelf: "flex-start",
    minHeight: 37,
    paddingHorizontal: 11,
    borderWidth: 1,
    borderRadius: 11,
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
  },
  resetText: { fontSize: 10, fontWeight: "700" },
  brandInput: { minHeight: 44, borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, fontSize: 13 },
  logoGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  logoOption: {
    minWidth: 88,
    minHeight: 71,
    paddingHorizontal: 10,
    paddingVertical: 8,
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
    borderWidth: 1,
    borderRadius: 13,
  },
  logoName: { fontSize: 10, fontWeight: "700" },
  previewFrame: { borderWidth: 1, borderRadius: 17, padding: 12, gap: 11 },
  previewBrand: { flexDirection: "row", alignItems: "center", gap: 10 },
  previewBrandCopy: { flex: 1, gap: 3 },
  previewBrandName: { fontSize: 13, fontWeight: "700" },
  previewAccentDot: { width: 11, height: 11, borderRadius: 6 },
  previewCard: { borderWidth: 1, borderRadius: 13, padding: 12, gap: 8 },
  previewCardTitle: { fontSize: 12, fontWeight: "700" },
  previewButton: { minHeight: 38, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  previewButtonText: { fontSize: 11, fontWeight: "800" },
  deviceNote: { textAlign: "center", fontSize: 10, lineHeight: 15, paddingHorizontal: 8 },
});
