import { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { SafeAreaView } from "react-native-safe-area-context";
import { useExtractKabirLearning, useTranscribeKabirAudio } from "@workspace/api-client-react";
import { useKabir } from "@/context/KabirContext";
import { useAudioCapture } from "@/hooks/useAudioCapture";
import { useColors } from "@/hooks/useColors";
import { recordAppError } from "@/lib/error-monitor";
import { createCollectiveKnowledgeBundle } from "@/lib/knowledge-schema";

function describeError(error: unknown) {
  return error instanceof Error ? error.message : "The learning content could not be processed.";
}

export default function LearningScreen() {
  const colors = useColors();
  const {
    learningEntries,
    addLearningEntry,
    removeLearningEntry,
    setStatus,
    storageError,
  } = useKabir();
  const capture = useAudioCapture();
  const transcribe = useTranscribeKabirAudio();
  const extract = useExtractKabirLearning();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const busy = transcribe.isPending || extract.isPending;

  async function toggleRecording() {
    setError("");
    if (!capture.recording) {
      try {
        const granted = await capture.startRecording();
        if (granted) setStatus("Learning");
      } catch (caught) {
        setError(describeError(caught));
        void recordAppError(caught, "Learning recording");
      }
      return;
    }

    setStatus("Learning");
    try {
      const clip = await capture.stopAndRead();
      if (!clip?.hasSpeech) {
        setMessage("No speech detected. Try recording again or paste a transcript.");
        return;
      }
      const result = await transcribe.mutateAsync({
        data: { audioBase64: clip.audioBase64, fileName: clip.fileName },
      });
      setContent((current) => (current ? `${current}\n${result.text}` : result.text));
      setMessage("Transcript ready. Review it, then save the filtered actions.");
    } catch (caught) {
      setError(describeError(caught));
      void recordAppError(caught, "Learning transcription");
    } finally {
      setStatus("Sleeping");
    }
  }

  async function saveLearning() {
    if (!content.trim()) {
      setError("Add a transcript or learning notes first.");
      return;
    }

    setError("");
    setMessage("");
    setStatus("Learning");
    try {
      const result = await extract.mutateAsync({
        data: {
          title: title.trim() || "Learning note",
          content: content.trim(),
        },
      });
      if (result.actions.length === 0) {
        setMessage("No reusable skill or gameplay actions were found. Nothing was saved.");
        return;
      }

      addLearningEntry({
        title: title.trim() || "Learning note",
        summary: result.summary,
        actions: result.actions,
      });
      setTitle("");
      setContent("");
      setMessage(`Saved ${result.actions.length} filtered action${result.actions.length === 1 ? "" : "s"}.`);
    } catch (caught) {
      setError(describeError(caught));
      void recordAppError(caught, "Learning extraction");
    } finally {
      setStatus("Sleeping");
    }
  }

  function confirmDelete(id: string, entryTitle: string) {
    Alert.alert("Delete this memory?", `“${entryTitle}” will be removed from this device.`, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => removeLearningEntry(id) },
    ]);
  }

  async function exportKnowledge() {
    if (learningEntries.length === 0) return;
    const bundle = createCollectiveKnowledgeBundle(learningEntries);
    const json = JSON.stringify(bundle, null, 2);

    try {
      if (Platform.OS === "web" && typeof document !== "undefined") {
        const file = new Blob([json], { type: "application/json" });
        const url = URL.createObjectURL(file);
        const link = document.createElement("a");
        link.href = url;
        link.download = "kabir-collective-knowledge-v1.json";
        link.click();
        window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
        setMessage("Clean knowledge exported as a versioned JSON file.");
        return;
      }

      await Share.share({
        title: "Kabir clean knowledge JSON",
        message: json,
      });
      setMessage("Clean knowledge bundle is ready in the share sheet.");
    } catch (caught) {
      setError(describeError(caught));
      void recordAppError(caught, "Knowledge JSON export");
    }
  }

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]} edges={["top"]}>
      <KeyboardAwareScrollView
        contentContainerStyle={styles.page}
        bottomOffset={24}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.content}>
          <View style={styles.heading}>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>LONG-TERM MEMORY</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Learning log</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Turn a recording or transcript into concise, reusable actions.
            </Text>
          </View>

          <View style={[styles.formCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Topic or source</Text>
            <TextInput
              accessibilityLabel="Learning topic or source"
              value={title}
              onChangeText={setTitle}
              placeholder="e.g. Boss fight strategy"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.titleInput, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.border }]}
              maxLength={160}
              returnKeyType="next"
            />

            <View style={styles.fieldLabelRow}>
              <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Transcript or notes</Text>
              <Text style={[styles.counter, { color: colors.mutedForeground }]}>{content.length}/40,000</Text>
            </View>
            <TextInput
              accessibilityLabel="Transcript or learning notes"
              value={content}
              onChangeText={setContent}
              placeholder="Paste notes, or record a short audio clip to transcribe..."
              placeholderTextColor={colors.mutedForeground}
              style={[styles.contentInput, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.border }]}
              multiline
              textAlignVertical="top"
              maxLength={40000}
            />

            <Pressable
              accessibilityRole="button"
              onPress={() => void toggleRecording()}
              disabled={busy}
              style={({ pressed }) => [
                styles.secondaryButton,
                { borderColor: colors.border, opacity: pressed || busy ? 0.7 : 1 },
              ]}
            >
              <Feather name={capture.recording ? "square" : "mic"} size={16} color={capture.recording ? colors.destructive : colors.foreground} />
              <Text style={[styles.secondaryButtonText, { color: capture.recording ? colors.destructive : colors.foreground }]}>
                {capture.recording ? `Finish recording · ${Math.floor(capture.durationSeconds)}s` : "Record audio to transcribe"}
              </Text>
            </Pressable>

            <Pressable
              accessibilityRole="button"
              onPress={() => void saveLearning()}
              disabled={busy || !content.trim()}
              style={({ pressed }) => [
                styles.primaryButton,
                { backgroundColor: colors.primary, opacity: pressed || busy || !content.trim() ? 0.5 : 1 },
              ]}
            >
              {busy ? (
                <ActivityIndicator color={colors.background} />
              ) : (
                <Feather name="filter" size={16} color={colors.background} />
              )}
              <Text style={[styles.primaryButtonText, { color: colors.background }]}>
                {extract.isPending ? "Filtering noise..." : transcribe.isPending ? "Transcribing..." : "Extract and save actions"}
              </Text>
            </Pressable>

            <Text style={[styles.privacy, { color: colors.mutedForeground }]}>
              After transcription, the temporary recording is removed from this device. Only the cleaned summary and actions are saved locally; raw transcripts are not kept. OpenAI usage may be billed to your account.
            </Text>
          </View>

          {!!message && (
            <View style={[styles.messageBox, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
              <Text style={[styles.messageText, { color: colors.foreground }]}>{message}</Text>
            </View>
          )}
          {!!error && (
            <View style={[styles.errorBox, { borderColor: colors.destructive, backgroundColor: colors.destructive + "18" }]}>
              <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
            </View>
          )}
          {!!storageError && <Text style={[styles.errorText, { color: colors.destructive }]}>{storageError}</Text>}

          <View style={styles.logHeader}>
            <View>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Stored knowledge</Text>
              <Text style={[styles.logSubtitle, { color: colors.mutedForeground }]}>
                {learningEntries.length} saved item{learningEntries.length === 1 ? "" : "s"} · stays after source deletion
              </Text>
            </View>
            <View style={styles.logActions}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Export clean learning as JSON"
                disabled={learningEntries.length === 0}
                onPress={() => void exportKnowledge()}
                style={({ pressed }) => [
                  styles.exportButton,
                  {
                    borderColor: colors.border,
                    opacity: learningEntries.length === 0 ? 0.45 : pressed ? 0.7 : 1,
                  },
                ]}
              >
                <Feather name="share" size={13} color={colors.primary} />
                <Text style={[styles.exportText, { color: colors.foreground }]}>Export</Text>
              </Pressable>
              <View style={[styles.countBadge, { backgroundColor: colors.secondary }]}>
                <Text style={[styles.countText, { color: colors.primary }]}>{learningEntries.length}</Text>
              </View>
            </View>
          </View>

          {learningEntries.length === 0 ? (
            <View style={[styles.emptyState, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Feather name="bookmark" size={22} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No saved knowledge yet</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                Add a transcript or recording above. Kabir filters out filler and keeps the useful steps.
              </Text>
            </View>
          ) : (
            learningEntries.map((entry) => (
              <View key={entry.id} style={[styles.entryCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={styles.entryHeading}>
                  <View style={styles.entryTitleCopy}>
                    <Text style={[styles.entryTitle, { color: colors.foreground }]}>{entry.title}</Text>
                    <Text style={[styles.entryDate, { color: colors.mutedForeground }]}>
                      {new Date(entry.createdAt).toLocaleDateString()}
                    </Text>
                  </View>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Delete ${entry.title}`}
                    onPress={() => confirmDelete(entry.id, entry.title)}
                    hitSlop={8}
                    style={styles.deleteButton}
                  >
                    <Feather name="trash-2" size={16} color={colors.mutedForeground} />
                  </Pressable>
                </View>
                {!!entry.summary && (
                  <Text style={[styles.summary, { color: colors.mutedForeground }]}>{entry.summary}</Text>
                )}
                <View style={styles.actionList}>
                  {entry.actions.map((action, index) => (
                    <View key={`${entry.id}-${index}`} style={styles.actionRow}>
                      <View style={[styles.actionNumber, { backgroundColor: colors.secondary }]}>
                        <Text style={[styles.actionNumberText, { color: colors.primary }]}>{index + 1}</Text>
                      </View>
                      <Text style={[styles.actionText, { color: colors.foreground }]}>{action}</Text>
                    </View>
                  ))}
                </View>
              </View>
            ))
          )}
        </View>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  page: { flexGrow: 1, alignItems: "center", paddingHorizontal: 20, paddingBottom: 36 },
  content: { width: "100%", maxWidth: 620, gap: 17 },
  heading: { paddingTop: 8, gap: 6, marginBottom: 4 },
  eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 2 },
  title: { fontSize: 30, lineHeight: 36, fontWeight: "700", letterSpacing: -0.6 },
  subtitle: { fontSize: 14, lineHeight: 21, maxWidth: 430 },
  formCard: { borderWidth: 1, borderRadius: 24, padding: 18, gap: 12 },
  fieldLabelRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 3 },
  fieldLabel: { fontSize: 13, fontWeight: "700" },
  counter: { fontSize: 10 },
  titleInput: { height: 46, borderRadius: 13, borderWidth: 1, paddingHorizontal: 13, fontSize: 14 },
  contentInput: { minHeight: 154, borderRadius: 13, borderWidth: 1, padding: 13, fontSize: 14, lineHeight: 21 },
  secondaryButton: { minHeight: 46, borderWidth: 1, borderRadius: 14, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 9 },
  secondaryButtonText: { fontSize: 13, fontWeight: "600" },
  primaryButton: { minHeight: 50, borderRadius: 15, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 9, paddingHorizontal: 14 },
  primaryButtonText: { fontSize: 13, fontWeight: "700" },
  privacy: { fontSize: 11, lineHeight: 17 },
  messageBox: { borderRadius: 13, padding: 13, borderWidth: 1 },
  messageText: { fontSize: 12, lineHeight: 18 },
  errorBox: { borderWidth: 1, borderRadius: 13, padding: 13 },
  errorText: { fontSize: 12, lineHeight: 18 },
  logHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 5 },
  logActions: { flexDirection: "row", alignItems: "center", gap: 7 },
  exportButton: { minHeight: 34, borderWidth: 1, borderRadius: 11, paddingHorizontal: 9, flexDirection: "row", alignItems: "center", gap: 5 },
  exportText: { fontSize: 10, fontWeight: "700" },
  sectionTitle: { fontSize: 19, fontWeight: "700", letterSpacing: -0.2 },
  logSubtitle: { fontSize: 12, lineHeight: 18, marginTop: 4 },
  countBadge: { minWidth: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center", paddingHorizontal: 8 },
  countText: { fontSize: 13, fontWeight: "800" },
  emptyState: { borderWidth: 1, borderRadius: 22, minHeight: 170, padding: 22, alignItems: "center", justifyContent: "center", gap: 9 },
  emptyTitle: { fontSize: 15, fontWeight: "700" },
  emptyText: { fontSize: 12, lineHeight: 18, textAlign: "center", maxWidth: 330 },
  entryCard: { borderWidth: 1, borderRadius: 22, padding: 17, gap: 13 },
  entryHeading: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  entryTitleCopy: { flex: 1, gap: 4 },
  entryTitle: { fontSize: 15, fontWeight: "700" },
  entryDate: { fontSize: 11 },
  deleteButton: { width: 32, height: 32, alignItems: "center", justifyContent: "center" },
  summary: { fontSize: 13, lineHeight: 20 },
  actionList: { gap: 10 },
  actionRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  actionNumber: { width: 23, height: 23, borderRadius: 8, alignItems: "center", justifyContent: "center", marginTop: 1 },
  actionNumberText: { fontSize: 11, fontWeight: "800" },
  actionText: { flex: 1, fontSize: 13, lineHeight: 20 },
});
