import { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { useTranscribeKabirAudio } from "@workspace/api-client-react";
import {
  useKabir,
  type ResponseLanguage,
} from "@/context/KabirContext";
import { useAudioCapture } from "@/hooks/useAudioCapture";
import { useColors } from "@/hooks/useColors";
import {
  clearDiagnosticHistory,
  recordAppError,
  useDiagnosticHistory,
} from "@/lib/error-monitor";

const responseLanguages: { value: ResponseLanguage; note: string }[] = [
  { value: "Bengali", note: "বাংলা" },
  { value: "Hindi", note: "हिन्दी" },
  { value: "English", note: "English" },
];

function describeError(error: unknown) {
  return error instanceof Error ? error.message : "Could not save that phrase.";
}

export default function SettingsScreen() {
  const colors = useColors();
  const router = useRouter();
  const {
    responseLanguage,
    setResponseLanguage,
    wakePhrases,
    addWakePhrase,
    removeWakePhrase,
    setStatus,
    ready,
    storageError,
  } = useKabir();
  const capture = useAudioCapture();
  const { discardRecording } = capture;
  const transcribe = useTranscribeKabirAudio();
  const diagnosticHistory = useDiagnosticHistory();
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [expandedErrorId, setExpandedErrorId] = useState<string | null>(null);
  const finishRecordingRef = useRef<() => void>(() => undefined);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  async function finishRecording() {
    if (saving || !capture.recording) return;
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    setSaving(true);
    setError("");
    setMessage("");
    setStatus("Learning");
    try {
      const clip = await capture.stopAndRead();
      if (!clip?.hasSpeech) {
        setMessage("No speech detected. Try saying one short phrase.");
        return;
      }
      const result = await transcribe.mutateAsync({
        data: { audioBase64: clip.audioBase64, fileName: clip.fileName },
      });
      const phrase = result.text.trim();
      if (!phrase) {
        setMessage("No phrase was recognized. Please try again.");
        return;
      }
      if (wakePhrases.some((item) => item.text.toLocaleLowerCase() === phrase.toLocaleLowerCase())) {
        setMessage("That wake phrase is already saved.");
        return;
      }
      if (wakePhrases.length >= 4) {
        setMessage("You already have four wake phrases. Remove one before adding another.");
        return;
      }
      addWakePhrase(phrase);
      setMessage(`Saved “${phrase}”. The original voice sample was discarded.`);
    } catch (caught) {
      setError(describeError(caught));
      void recordAppError(caught, "Wake phrase transcription");
    } finally {
      setSaving(false);
      setStatus("Sleeping");
    }
  }

  finishRecordingRef.current = () => {
    void finishRecording();
  };

  useEffect(
    () => () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      void discardRecording().catch(() => undefined);
    },
    [discardRecording],
  );

  async function togglePhraseRecording() {
    setError("");
    setMessage("");
    if (capture.recording) {
      await finishRecording();
      return;
    }
    if (wakePhrases.length >= 4) {
      setMessage("You already have four wake phrases. Remove one before adding another.");
      return;
    }
    try {
      const granted = await capture.startRecording();
      if (!granted) return;
      setStatus("Active");
      timerRef.current = setTimeout(() => finishRecordingRef.current(), 6000);
    } catch (caught) {
      setError(describeError(caught));
      void recordAppError(caught, "Microphone recording");
    }
  }

  function confirmRemove(id: string, text: string) {
    Alert.alert("Remove wake phrase?", `“${text}” will stop triggering Kabir.`, [
      { text: "Cancel", style: "cancel" },
      { text: "Remove", style: "destructive", onPress: () => removeWakePhrase(id) },
    ]);
  }

  function confirmClearDiagnostics() {
    Alert.alert("Clear diagnostic history?", "This only removes the error log stored on this device.", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Clear log",
        style: "destructive",
        onPress: () => {
          void clearDiagnosticHistory().then((cleared) => {
            if (!cleared) {
              Alert.alert("Could not clear the log", "Device storage may be unavailable. The existing diagnostic entries were restored.");
            }
          });
        },
      },
    ]);
  }

  async function openTroubleshootingLink(url: string) {
    try {
      await Linking.openURL(url);
    } catch (caught) {
      Alert.alert("Could not open the help link", "Check that your device can open web links, then try again.");
      void recordAppError(caught, "Open troubleshooting link");
    }
  }

  async function openDeviceSettings() {
    if (Platform.OS === "web") {
      Alert.alert(
        "Microphone permission",
        "Open this site's browser settings, allow microphone access, then reload the preview.",
      );
      return;
    }
    try {
      await Linking.openSettings();
    } catch (caught) {
      Alert.alert("Could not open device settings", "Open Kabir's microphone permission from your device settings.");
      void recordAppError(caught, "Open device settings");
    }
  }

  if (!ready) {
    return (
      <SafeAreaView style={[styles.loading, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page} showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          <View style={styles.heading}>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>PREFERENCES</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Settings</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Choose how Kabir responds and record your personal wake phrases.
            </Text>
          </View>

          <Pressable
            accessibilityRole="button"
            onPress={() => router.push("/customization")}
            style={({ pressed }) => [
              styles.section,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                opacity: pressed ? 0.78 : 1,
              },
            ]}
          >
            <View style={styles.sectionHeader}>
              <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
                <Feather name="sliders" size={17} color={colors.primary} />
              </View>
              <View style={styles.sectionCopy}>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Customization</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                  Themes, live colors, and in-app branding. Open for testing.
                </Text>
              </View>
              <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
            </View>
          </Pressable>

          <Pressable
            accessibilityRole="button"
            onPress={() => router.push("/routines")}
            style={({ pressed }) => [
              styles.section,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                opacity: pressed ? 0.78 : 1,
              },
            ]}
          >
            <View style={styles.sectionHeader}>
              <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
                <Feather name="zap" size={17} color={colors.primary} />
              </View>
              <View style={styles.sectionCopy}>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Routines</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                  Teach Kabir multi-step tasks, then ask for them by voice.
                </Text>
              </View>
              <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
            </View>
          </Pressable>

          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.sectionHeader}>
              <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
                <Feather name="volume-2" size={17} color={colors.primary} />
              </View>
              <View style={styles.sectionCopy}>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Response voice language</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                  Speech input is detected automatically. Kabir replies in this language.
                </Text>
              </View>
            </View>
            <View style={styles.languageList}>
              {responseLanguages.map((language) => {
                const selected = responseLanguage === language.value;
                return (
                  <Pressable
                    key={language.value}
                    accessibilityRole="radio"
                    accessibilityState={{ selected }}
                    onPress={() => setResponseLanguage(language.value)}
                    style={[
                      styles.languageOption,
                      {
                        backgroundColor: selected ? colors.primary : colors.background,
                        borderColor: selected ? colors.primary : colors.border,
                      },
                    ]}
                  >
                    <Text style={[styles.languageName, { color: selected ? colors.background : colors.foreground }]}>
                      {language.value}
                    </Text>
                    <Text style={[styles.languageNative, { color: selected ? colors.background : colors.mutedForeground }]}>
                      {language.note}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
            <Text style={[styles.savedNote, { color: colors.mutedForeground }]}>
              Saved on this device and used for every spoken reply.
            </Text>
          </View>

          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.sectionHeader}>
              <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
                <Feather name="radio" size={17} color={colors.primary} />
              </View>
              <View style={styles.sectionCopy}>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Custom wake phrases</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                  Record up to 4 short phrases in any language.
                </Text>
              </View>
              <View style={[styles.countBadge, { backgroundColor: colors.secondary }]}>
                <Text style={[styles.countText, { color: colors.primary }]}>{wakePhrases.length}/4</Text>
              </View>
            </View>

            {wakePhrases.length === 0 ? (
              <View style={[styles.emptyPhrases, { borderColor: colors.border }]}>
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                  No wake phrases recorded yet. Start with 3–4 phrases you naturally use.
                </Text>
              </View>
            ) : (
              <View style={styles.phraseList}>
                {wakePhrases.map((phrase, index) => (
                  <View key={phrase.id} style={[styles.phraseRow, { backgroundColor: colors.background, borderColor: colors.border }]}>
                    <View style={[styles.phraseIndex, { backgroundColor: colors.secondary }]}>
                      <Text style={[styles.phraseIndexText, { color: colors.primary }]}>{index + 1}</Text>
                    </View>
                    <Text style={[styles.phraseText, { color: colors.foreground }]}>{phrase.text}</Text>
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel={`Remove wake phrase ${phrase.text}`}
                      onPress={() => confirmRemove(phrase.id, phrase.text)}
                      hitSlop={8}
                      style={styles.removeButton}
                    >
                      <Feather name="x" size={17} color={colors.mutedForeground} />
                    </Pressable>
                  </View>
                ))}
              </View>
            )}

            <Pressable
              accessibilityRole="button"
              onPress={() => void togglePhraseRecording()}
              disabled={saving || transcribe.isPending || (!capture.recording && wakePhrases.length >= 4)}
              style={({ pressed }) => [
                styles.primaryButton,
                {
                  backgroundColor: capture.recording ? colors.secondary : colors.primary,
                  opacity: pressed || saving || transcribe.isPending || (!capture.recording && wakePhrases.length >= 4) ? 0.55 : 1,
                },
              ]}
            >
              {saving || transcribe.isPending ? (
                <ActivityIndicator color={capture.recording ? colors.foreground : colors.background} />
              ) : (
                <Feather
                  name={capture.recording ? "square" : "mic"}
                  size={16}
                  color={capture.recording ? colors.destructive : colors.background}
                />
              )}
              <Text style={[styles.primaryButtonText, { color: capture.recording ? colors.destructive : colors.background }]}>
                {saving || transcribe.isPending
                  ? "Recognizing phrase..."
                  : capture.recording
                    ? `Stop and save · ${Math.floor(capture.durationSeconds)}s`
                    : "Record a wake phrase"}
              </Text>
            </Pressable>

            <View style={[styles.limitation, { backgroundColor: colors.secondary }]}>
              <Feather name="info" size={15} color={colors.mutedForeground} />
              <Text style={[styles.limitationText, { color: colors.mutedForeground }]}>
                Low-power shell: compact speech capture, adaptive 7–12 second windows, and no uploads for silence. It pauses when Kabir leaves the foreground; closed-app listening still needs a native wake-word engine.
              </Text>
            </View>
          </View>

          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.sectionHeader}>
              <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
                <Feather name="activity" size={17} color={colors.primary} />
              </View>
              <View style={styles.sectionCopy}>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Smart diagnostics</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
                  Kabir logs app crashes and failed actions with suggested fixes.
                </Text>
              </View>
              <View style={[styles.countBadge, { backgroundColor: colors.secondary }]}>
                <Text style={[styles.countText, { color: colors.primary }]}>{diagnosticHistory.length}</Text>
              </View>
            </View>

            {diagnosticHistory.length === 0 ? (
              <View style={[styles.emptyPhrases, { borderColor: colors.border }]}>
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                  No errors recorded. Failed voice, learning, storage, and screen actions are monitored automatically.
                </Text>
              </View>
            ) : (
              <View style={styles.diagnosticList}>
                {diagnosticHistory.slice(0, 8).map((item) => {
                  const expanded = expandedErrorId === item.id;
                  return (
                    <View
                      key={item.id}
                      style={[styles.diagnosticCard, { backgroundColor: colors.background, borderColor: colors.border }]}
                    >
                      <Text style={[styles.diagnosticMeta, { color: colors.mutedForeground }]}>
                        {item.source} · {new Date(item.createdAt).toLocaleString()}
                      </Text>
                      <Text style={[styles.diagnosticTitle, { color: colors.foreground }]}>{item.title}</Text>
                      <Text style={[styles.diagnosticMessage, { color: colors.mutedForeground }]}>{item.message}</Text>

                      <View style={styles.diagnosticSteps}>
                        {item.steps.map((step, index) => (
                          <View key={`${item.id}-step-${index}`} style={styles.diagnosticStep}>
                            <Text style={[styles.stepNumber, { color: colors.primary }]}>{index + 1}</Text>
                            <Text style={[styles.stepText, { color: colors.foreground }]}>{step}</Text>
                          </View>
                        ))}
                      </View>

                      <View style={styles.diagnosticActions}>
                        {item.helpUrl ? (
                          <Pressable
                            accessibilityRole="link"
                            onPress={() => void openTroubleshootingLink(item.helpUrl!)}
                            style={styles.diagnosticAction}
                          >
                            <Feather name="external-link" size={14} color={colors.primary} />
                            <Text style={[styles.diagnosticActionText, { color: colors.primary }]}>
                              Open troubleshooting guide
                            </Text>
                          </Pressable>
                        ) : null}
                        {item.requiresDeviceSettings ? (
                          <Pressable
                            accessibilityRole="button"
                            onPress={() => void openDeviceSettings()}
                            style={styles.diagnosticAction}
                          >
                            <Feather name="settings" size={14} color={colors.primary} />
                            <Text style={[styles.diagnosticActionText, { color: colors.primary }]}>
                              {Platform.OS === "web" ? "Browser microphone settings" : "Open device settings"}
                            </Text>
                          </Pressable>
                        ) : null}
                        <Pressable
                          accessibilityRole="button"
                          accessibilityLabel={expanded ? "Hide technical details" : "Show technical details"}
                          onPress={() => setExpandedErrorId(expanded ? null : item.id)}
                          style={styles.diagnosticAction}
                        >
                          <Feather name={expanded ? "chevron-up" : "code"} size={14} color={colors.mutedForeground} />
                          <Text style={[styles.diagnosticActionText, { color: colors.mutedForeground }]}>
                            {expanded ? "Hide details" : "Technical details"}
                          </Text>
                        </Pressable>
                      </View>

                      {expanded ? (
                        <View style={[styles.detailsBlock, { backgroundColor: colors.card, borderColor: colors.border }]}>
                          <ScrollView
                            style={styles.detailsScroll}
                            nestedScrollEnabled
                            showsVerticalScrollIndicator
                          >
                            <Text selectable style={[styles.detailsText, { color: colors.mutedForeground }]}>
                              {item.details}
                            </Text>
                          </ScrollView>
                        </View>
                      ) : null}
                    </View>
                  );
                })}
              </View>
            )}

            <Text style={[styles.savedNote, { color: colors.mutedForeground }]}>
              Logs stay on this device and can be cleared at any time. Common API-key patterns are redacted.
            </Text>
            {diagnosticHistory.length > 0 ? (
              <Pressable
                accessibilityRole="button"
                onPress={confirmClearDiagnostics}
                style={[styles.clearLogsButton, { borderColor: colors.border }]}
              >
                <Feather name="trash-2" size={14} color={colors.destructive} />
                <Text style={[styles.diagnosticActionText, { color: colors.destructive }]}>Clear diagnostic history</Text>
              </Pressable>
            ) : null}
          </View>

          {!!message && (
            <View style={[styles.messageBox, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
              <Text style={[styles.messageText, { color: colors.foreground }]}>{message}</Text>
            </View>
          )}
          {!!error && <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>}
          {!!storageError && <Text style={[styles.errorText, { color: colors.destructive }]}>{storageError}</Text>}

          <Text style={[styles.deviceNote, { color: colors.mutedForeground }]}>
            Settings and trigger text are stored locally. OpenAI receives audio only when you choose to transcribe or save it; the temporary recording is removed from this device afterward. Usage may be billed to your OpenAI account.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  page: { flexGrow: 1, alignItems: "center", paddingHorizontal: 20, paddingBottom: 24 },
  content: { width: "100%", maxWidth: 620, gap: 17 },
  heading: { paddingTop: 8, gap: 6, marginBottom: 4 },
  eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 2 },
  title: { fontSize: 30, lineHeight: 36, fontWeight: "700", letterSpacing: -0.6 },
  subtitle: { fontSize: 14, lineHeight: 21, maxWidth: 440 },
  section: { borderWidth: 1, borderRadius: 24, padding: 18, gap: 15 },
  sectionHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  iconBox: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  sectionCopy: { flex: 1, gap: 3 },
  sectionTitle: { fontSize: 15, fontWeight: "700" },
  sectionSubtitle: { fontSize: 12, lineHeight: 17 },
  languageList: { flexDirection: "row", gap: 8 },
  languageOption: { flex: 1, minHeight: 56, borderRadius: 14, borderWidth: 1, paddingHorizontal: 10, alignItems: "center", justifyContent: "center", gap: 2 },
  languageName: { fontSize: 12, fontWeight: "700" },
  languageNative: { fontSize: 11 },
  savedNote: { fontSize: 11, lineHeight: 16 },
  countBadge: { height: 31, minWidth: 44, borderRadius: 11, alignItems: "center", justifyContent: "center", paddingHorizontal: 8 },
  countText: { fontSize: 11, fontWeight: "800" },
  emptyPhrases: { borderWidth: 1, borderStyle: "dashed", borderRadius: 15, padding: 14 },
  emptyText: { fontSize: 12, lineHeight: 18 },
  phraseList: { gap: 8 },
  phraseRow: { minHeight: 50, borderWidth: 1, borderRadius: 14, paddingLeft: 10, paddingRight: 7, alignItems: "center", flexDirection: "row", gap: 10 },
  phraseIndex: { width: 27, height: 27, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  phraseIndexText: { fontSize: 11, fontWeight: "800" },
  phraseText: { flex: 1, fontSize: 13, fontWeight: "600" },
  removeButton: { width: 34, height: 34, alignItems: "center", justifyContent: "center" },
  primaryButton: { minHeight: 49, borderRadius: 15, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 9, paddingHorizontal: 14 },
  primaryButtonText: { fontSize: 13, fontWeight: "700" },
  limitation: { flexDirection: "row", alignItems: "flex-start", gap: 9, padding: 12, borderRadius: 14 },
  limitationText: { flex: 1, fontSize: 11, lineHeight: 17 },
  messageBox: { borderRadius: 13, padding: 13, borderWidth: 1 },
  messageText: { fontSize: 12, lineHeight: 18 },
  errorText: { fontSize: 12, lineHeight: 18 },
  deviceNote: { textAlign: "center", fontSize: 11, lineHeight: 17, paddingHorizontal: 8 },
  diagnosticList: { gap: 9 },
  diagnosticCard: { borderWidth: 1, borderRadius: 16, padding: 13, gap: 8 },
  diagnosticMeta: { fontSize: 10, lineHeight: 14 },
  diagnosticTitle: { fontSize: 13, fontWeight: "700" },
  diagnosticMessage: { fontSize: 12, lineHeight: 17 },
  diagnosticSteps: { gap: 7, paddingTop: 2 },
  diagnosticStep: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  stepNumber: { fontSize: 11, lineHeight: 17, fontWeight: "800", width: 14 },
  stepText: { flex: 1, fontSize: 11, lineHeight: 17 },
  diagnosticActions: { flexDirection: "row", flexWrap: "wrap", gap: 12, paddingTop: 3 },
  diagnosticAction: { minHeight: 28, flexDirection: "row", alignItems: "center", gap: 6 },
  diagnosticActionText: { fontSize: 11, fontWeight: "700" },
  detailsBlock: { borderWidth: 1, borderRadius: 11, padding: 10, height: 170 },
  detailsScroll: { flex: 1 },
  detailsText: { fontSize: 10, lineHeight: 15, fontFamily: "monospace" },
  clearLogsButton: { minHeight: 40, borderWidth: 1, borderRadius: 12, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
});
