import { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  AppState,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { AudioModule, useAudioPlayer, useAudioPlayerStatus } from "expo-audio";
import * as FileSystem from "expo-file-system/legacy";
import { Feather } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  useAskKabirByVoice,
  useRespondToKabirTranscript,
  useTranscribeKabirAudio,
} from "@workspace/api-client-react";
import { StatusBadge } from "@/components/StatusBadge";
import { BrandMark } from "@/components/BrandMark";
import { useAudioCapture } from "@/hooks/useAudioCapture";
import { useVoiceCommands } from "@/hooks/useVoiceCommands";
import { useColors } from "@/hooks/useColors";
import { useKabir } from "@/context/KabirContext";
import { recordAppError } from "@/lib/error-monitor";
import {
  getWakeListeningWindow,
  nextQuietWindowCount,
} from "@/lib/low-power-listener";
import { matchWakePhrase } from "@/lib/wake-phrases";

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function errorMessage(error: unknown) {
  return error instanceof Error
    ? error.message
    : "Kabir could not finish that request. Please try again.";
}

export default function DashboardScreen() {
  const colors = useColors();
  const {
    responseLanguage,
    wakePhrases,
    appearance,
    status,
    setStatus,
    ready,
    storageError,
  } = useKabir();
  const {
    recording,
    durationSeconds,
    startRecording,
    stopAndRead,
    discardRecording,
  } = useAudioCapture();
  const transcribe = useTranscribeKabirAudio();
  const askByVoice = useAskKabirByVoice();
  const respondToTranscript = useRespondToKabirTranscript();
  const voiceCommands = useVoiceCommands();
  const player = useAudioPlayer(null);
  const playerStatus = useAudioPlayerStatus(player);
  const [listening, setListening] = useState(false);
  const [busy, setBusy] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [reply, setReply] = useState("");
  const [wakeMatch, setWakeMatch] = useState("");
  const [error, setError] = useState("");
  const listenerRef = useRef(false);
  const runIdRef = useRef(0);
  const manualStopRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const speechUriRef = useRef<string | null>(null);

  const playReplyAudio = useCallback(
    async (audioBase64: string) => {
      if (Platform.OS === "web") {
        player.replace({ uri: `data:audio/mpeg;base64,${audioBase64}` });
      } else {
        const cacheDirectory = FileSystem.cacheDirectory;
        if (!cacheDirectory) return;

        if (speechUriRef.current) {
          await FileSystem.deleteAsync(speechUriRef.current, { idempotent: true }).catch(
            () => undefined,
          );
        }
        const uri = `${cacheDirectory}kabir-reply-${Date.now()}.mp3`;
        await FileSystem.writeAsStringAsync(uri, audioBase64, {
          encoding: FileSystem.EncodingType.Base64,
        });
        speechUriRef.current = uri;
        player.replace({ uri });
      }
      player.play();
    },
    [player],
  );

  useEffect(() => {
    if (!playerStatus.didJustFinish || !speechUriRef.current) return;
    const uri = speechUriRef.current;
    speechUriRef.current = null;
    void FileSystem.deleteAsync(uri, { idempotent: true }).catch(() => undefined);
  }, [playerStatus.didJustFinish]);

  const stopWakeListening = useCallback(() => {
    listenerRef.current = false;
    runIdRef.current += 1;
    setListening(false);
    void discardRecording();
  }, [discardRecording]);

  useEffect(() => {
    const subscription = AppState.addEventListener("change", (nextState) => {
      if (nextState !== "active" && listenerRef.current) {
        stopWakeListening();
        setStatus("Sleeping");
      }
    });
    return () => subscription.remove();
  }, [setStatus, stopWakeListening]);

  useEffect(
    () => () => {
      listenerRef.current = false;
      runIdRef.current += 1;
      if (manualStopRef.current) clearTimeout(manualStopRef.current);
      void discardRecording();
      if (speechUriRef.current) {
        void FileSystem.deleteAsync(speechUriRef.current, { idempotent: true }).catch(
          () => undefined,
        );
      }
    },
    [discardRecording],
  );

  const runWakeListener = useCallback(async () => {
    if (wakePhrases.length === 0) {
      Alert.alert(
        "Add a wake phrase first",
        "Record a custom phrase in Settings to use wake listening.",
      );
      return;
    }

    const runId = runIdRef.current + 1;
    runIdRef.current = runId;
    listenerRef.current = true;
    setListening(true);
    setError("");
    setWakeMatch("");
    setStatus("Active");
    let activated = false;
    let previousTail = "";
    let quietWindows = 0;

    try {
      while (listenerRef.current && runIdRef.current === runId) {
        const listeningWindow = getWakeListeningWindow(AppState.currentState, quietWindows);
        if (!listeningWindow.shouldCapture) break;
        const granted = await startRecording();
        if (!granted) break;
        await delay(listeningWindow.durationMs);

        if (!listenerRef.current || runIdRef.current !== runId) {
          await discardRecording();
          break;
        }

        const clip = await stopAndRead();
        if (!clip?.hasSpeech) {
          quietWindows = nextQuietWindowCount(false, quietWindows);
          continue;
        }
        quietWindows = nextQuietWindowCount(true, quietWindows);

        const recognized = await transcribe.mutateAsync({
          data: { audioBase64: clip.audioBase64, fileName: clip.fileName },
        });
        const combinedTranscript = `${previousTail} ${recognized.text}`.trim();
        const match = matchWakePhrase(combinedTranscript, wakePhrases);
        previousTail = recognized.text.split(/\s+/).slice(-8).join(" ");
        if (!match) continue;

        activated = true;
        listenerRef.current = false;
        setListening(false);
        setWakeMatch(match.text);
        setTranscript(combinedTranscript);
        if (voiceCommands.available) {
          // Screen-control path: Kabir either answers (chat) or operates the screen, in one planner call.
          const outcome = await voiceCommands.handle(combinedTranscript, {
            onSpeak: async (speak, audio) => {
              setReply(speak);
              if (audio) await playReplyAudio(audio);
            },
          });
          if (outcome.problem) setError(outcome.problem);
          setStatus("Active");
          return;
        }
        const response = await respondToTranscript.mutateAsync({
          data: {
            transcript: combinedTranscript,
            responseLanguage,
          },
        });
        setReply(response.reply);
        await playReplyAudio(response.audioBase64);
        setStatus("Active");
        return;
      }
    } catch (caught) {
      setError(errorMessage(caught));
      void recordAppError(caught, "Wake phrase listening");
    } finally {
      if (runIdRef.current === runId) {
        listenerRef.current = false;
        setListening(false);
        if (!activated) setStatus("Sleeping");
      }
    }
  }, [
    discardRecording,
    playReplyAudio,
    respondToTranscript,
    responseLanguage,
    setStatus,
    startRecording,
    stopAndRead,
    transcribe,
    voiceCommands,
    wakePhrases,
  ]);

  const finishManualRecording = useCallback(async () => {
    if (manualStopRef.current) {
      clearTimeout(manualStopRef.current);
      manualStopRef.current = null;
    }
    setBusy(true);
    setError("");
    try {
      const clip = await stopAndRead();
      if (!clip?.hasSpeech) {
        setError("I didn't hear speech. Try again in a quieter spot.");
        return;
      }
      if (voiceCommands.available) {
        const recognized = await transcribe.mutateAsync({
          data: { audioBase64: clip.audioBase64, fileName: clip.fileName },
        });
        setTranscript(recognized.text);
        const outcome = await voiceCommands.handle(recognized.text, {
          onSpeak: async (speak, audio) => {
            setReply(speak);
            if (audio) await playReplyAudio(audio);
          },
        });
        if (outcome.problem) setError(outcome.problem);
        setStatus("Active");
        return;
      }
      const result = await askByVoice.mutateAsync({
        data: {
          audioBase64: clip.audioBase64,
          fileName: clip.fileName,
          responseLanguage,
        },
      });
      setTranscript(result.transcript);
      setReply(result.reply);
      await playReplyAudio(result.audioBase64);
      setStatus("Active");
    } catch (caught) {
      setError(errorMessage(caught));
      void recordAppError(caught, "Voice request");
    } finally {
      setBusy(false);
    }
  }, [askByVoice, playReplyAudio, responseLanguage, setStatus, stopAndRead, transcribe, voiceCommands]);

  const toggleManualRecording = useCallback(async () => {
    if (recording) {
      await finishManualRecording();
      return;
    }
    if (listening || busy) return;

    try {
      const granted = await startRecording();
      if (!granted) return;
      setStatus("Active");
      manualStopRef.current = setTimeout(() => {
        void finishManualRecording();
      }, 12000);
    } catch (caught) {
      setError(errorMessage(caught));
      void recordAppError(caught, "Microphone recording");
    }
  }, [busy, finishManualRecording, listening, recording, setStatus, startRecording]);

  const sleep = useCallback(() => {
    stopWakeListening();
    setStatus("Sleeping");
    setWakeMatch("");
  }, [setStatus, stopWakeListening]);

  if (!ready) {
    return (
      <SafeAreaView style={[styles.loading, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </SafeAreaView>
    );
  }

  const brandName = appearance.brandName.trim() || "Kabir AI";

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page} showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          <View style={styles.topLine}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 11 }}>
              <BrandMark
                variant={appearance.logoVariant}
                brandName={brandName}
                size={40}
              />
              <View>
                <Text style={[styles.eyebrow, { color: colors.primary }]}>{brandName.toLocaleUpperCase()}</Text>
                <Text style={[styles.brand, { color: colors.foreground }]}>Voice assistant</Text>
              </View>
            </View>
            <StatusBadge status={listening ? "Active" : busy ? "Active" : status} />
          </View>

          <View style={[styles.hero, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.orbOuter, { borderColor: colors.border }]}>
              <View style={[styles.orbInner, { backgroundColor: colors.secondary }]}>
                {busy ? (
                  <ActivityIndicator size="large" color={colors.primary} />
                ) : (
                  <Feather name={listening ? "radio" : "mic"} size={34} color={colors.primary} />
                )}
              </View>
            </View>
            <Text style={[styles.heroTitle, { color: colors.foreground }]}>
              {listening
                ? "Listening for your phrase"
                : recording
                  ? "I'm listening"
                  : status === "Active"
                    ? "Kabir is awake"
                    : "Ready when you are"}
            </Text>
            <Text style={[styles.heroBody, { color: colors.mutedForeground }]}>
              {listening
                ? `Checking for ${wakePhrases.length} saved trigger${wakePhrases.length === 1 ? "" : "s"}`
                : "Speak naturally in Bengali, Hindi, English, or another language."}
            </Text>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel={recording ? "Finish voice request" : "Record a voice request"}
              onPress={() => void toggleManualRecording()}
              disabled={busy || listening}
              style={({ pressed }) => [
                styles.primaryButton,
                {
                  backgroundColor: colors.primary,
                  opacity: pressed || busy || listening ? 0.76 : 1,
                },
              ]}
            >
              {busy ? (
                <ActivityIndicator color={colors.background} />
              ) : (
                <Feather
                  name={recording ? "square" : "mic"}
                  size={18}
                  color={colors.background}
                />
              )}
              <Text style={[styles.primaryButtonText, { color: colors.background }]}>
                {busy
                  ? "Kabir is replying..."
                  : recording
                    ? "Finish recording"
                    : "Record a voice request"}
              </Text>
            </Pressable>
            <Text style={[styles.durationNote, { color: colors.mutedForeground }]}>
              {recording
                ? `Recording · ${Math.floor(durationSeconds)} seconds`
                : "Up to 12 seconds · speech language is detected automatically"}
            </Text>
          </View>

          <View style={[styles.wakeCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.cardTitleRow}>
              <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
                <Feather name="radio" size={17} color={colors.primary} />
              </View>
              <View style={styles.cardTitleCopy}>
                <Text style={[styles.cardTitle, { color: colors.foreground }]}>Wake listening</Text>
                <Text style={[styles.cardSubtitle, { color: colors.mutedForeground }]}>
                  {wakePhrases.length
                    ? `${wakePhrases.length} saved phrase${wakePhrases.length === 1 ? "" : "s"}`
                    : "Add custom phrases in Settings"}
                </Text>
              </View>
            </View>
            <Pressable
              accessibilityRole="button"
              onPress={() => {
                if (listening) {
                  stopWakeListening();
                  setStatus("Sleeping");
                } else {
                  void runWakeListener();
                }
              }}
              disabled={busy}
              style={({ pressed }) => [
                styles.secondaryButton,
                { borderColor: colors.border, opacity: pressed || busy ? 0.7 : 1 },
              ]}
            >
              <Feather
                name={listening ? "square" : "radio"}
                size={16}
                color={listening ? colors.destructive : colors.foreground}
              />
              <Text
                style={[
                  styles.secondaryButtonText,
                  { color: listening ? colors.destructive : colors.foreground },
                ]}
              >
                {listening ? "Stop listening" : "Start wake listening"}
              </Text>
            </Pressable>
            <Text style={[styles.disclosure, { color: colors.mutedForeground }]}>
              Wake listening runs only while Kabir is open. Speech clips are sent to OpenAI to check for a match; usage may be billed to your OpenAI account.
            </Text>
          </View>

          {status === "Active" && !listening && (
            <Pressable
              accessibilityRole="button"
              onPress={sleep}
              style={[styles.sleepButton, { borderColor: colors.border }]}
            >
              <Feather name="moon" size={15} color={colors.mutedForeground} />
              <Text style={[styles.sleepText, { color: colors.mutedForeground }]}>
                Put Kabir to sleep
              </Text>
            </Pressable>
          )}

          {(reply || transcript) && (
            <View style={[styles.replyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.cardTitleRow}>
                <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
                  <Feather name="message-circle" size={17} color={colors.primary} />
                </View>
                <View style={styles.cardTitleCopy}>
                  <Text style={[styles.cardTitle, { color: colors.foreground }]}>
                    {wakeMatch ? `Triggered by “${wakeMatch}”` : "Latest conversation"}
                  </Text>
                  <Text style={[styles.cardSubtitle, { color: colors.mutedForeground }]}>
                    Response voice · {responseLanguage}
                  </Text>
                </View>
                {!!reply && (
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel="Replay Kabir's response"
                    onPress={() => player.play()}
                    style={[styles.replayButton, { backgroundColor: colors.secondary }]}
                  >
                    <Feather name="volume-2" size={17} color={colors.primary} />
                  </Pressable>
                )}
              </View>
              {!!transcript && (
                <Text
                  style={[
                    styles.transcript,
                    { color: colors.mutedForeground, borderLeftColor: colors.border },
                  ]}
                >
                  {transcript}
                </Text>
              )}
              {!!reply && <Text style={[styles.replyText, { color: colors.foreground }]}>{reply}</Text>}
            </View>
          )}

          {!!error && (
            <View
              style={[
                styles.errorBox,
                { backgroundColor: colors.destructive + "18", borderColor: colors.destructive },
              ]}
            >
              <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
            </View>
          )}
          {!!storageError && (
            <Text style={[styles.storageError, { color: colors.destructive }]}>{storageError}</Text>
          )}
          <Text style={[styles.localNote, { color: colors.mutedForeground }]}>
            Wake phrases and learning notes are saved on this device.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  page: { flexGrow: 1, alignItems: "center", paddingHorizontal: 20, paddingBottom: 28 },
  content: { width: "100%", maxWidth: 620, gap: 18 },
  topLine: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: 8,
  },
  eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 2.2, marginBottom: 5 },
  brand: { fontSize: 22, fontWeight: "700", letterSpacing: -0.4 },
  hero: {
    alignItems: "center",
    paddingHorizontal: 22,
    paddingTop: 28,
    paddingBottom: 22,
    borderWidth: 1,
    borderRadius: 28,
  },
  orbOuter: {
    width: 138,
    height: 138,
    borderRadius: 70,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
  },
  orbInner: {
    width: 106,
    height: 106,
    borderRadius: 54,
    alignItems: "center",
    justifyContent: "center",
  },
  heroTitle: { fontSize: 22, fontWeight: "700", textAlign: "center", letterSpacing: -0.3 },
  heroBody: { fontSize: 14, lineHeight: 21, textAlign: "center", marginTop: 8, marginBottom: 20 },
  primaryButton: {
    minHeight: 52,
    paddingHorizontal: 20,
    borderRadius: 16,
    alignSelf: "stretch",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
  },
  primaryButtonText: { fontSize: 15, fontWeight: "700" },
  durationNote: { fontSize: 11, textAlign: "center", marginTop: 12 },
  wakeCard: { borderWidth: 1, borderRadius: 24, padding: 18, gap: 15 },
  cardTitleRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  iconBox: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  cardTitleCopy: { flex: 1, gap: 3 },
  cardTitle: { fontSize: 15, fontWeight: "700" },
  cardSubtitle: { fontSize: 12, lineHeight: 17 },
  secondaryButton: {
    minHeight: 46,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 9,
  },
  secondaryButtonText: { fontSize: 13, fontWeight: "600" },
  disclosure: { fontSize: 11, lineHeight: 17 },
  sleepButton: {
    minHeight: 40,
    borderRadius: 13,
    borderWidth: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  sleepText: { fontSize: 12, fontWeight: "600" },
  replyCard: { borderWidth: 1, borderRadius: 24, padding: 18, gap: 14 },
  replayButton: { width: 36, height: 36, alignItems: "center", justifyContent: "center", borderRadius: 13 },
  transcript: { fontSize: 13, lineHeight: 19, borderLeftWidth: 2, paddingLeft: 10 },
  replyText: { fontSize: 16, lineHeight: 24, fontWeight: "500" },
  errorBox: { borderWidth: 1, borderRadius: 14, padding: 13 },
  errorText: { fontSize: 12, lineHeight: 18 },
  storageError: { fontSize: 12, lineHeight: 18 },
  localNote: { textAlign: "center", fontSize: 11, lineHeight: 16, paddingHorizontal: 14 },
});
