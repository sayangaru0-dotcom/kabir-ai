import React, { useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ErrorBoundary as AppErrorBoundary } from '@/components/ErrorBoundary';
import { StartupErrorView, StartupFaultGate } from '@/components/StartupErrorScreen';
import { makeStartupFault } from '@/lib/startup-guard';
import { KabirProvider } from '@/context/KabirContext';
import { setBaseUrl } from '@workspace/api-client-react';
import { installGlobalErrorMonitoring, recordAppError } from '@/lib/error-monitor';
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from '@expo-google-fonts/inter';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';

// Keep the native splash screen up until the app is ready. These calls return promises that can reject (for example when there is
// no activity yet); an unhandled rejection must never be able to take the app down.
try {
  SplashScreen.preventAutoHideAsync().catch(() => undefined);
} catch {
  /* the splash screen is cosmetic */
}

const queryClient = new QueryClient();

try {
  if (process.env.EXPO_PUBLIC_DOMAIN) {
    setBaseUrl(`https://${process.env.EXPO_PUBLIC_DOMAIN}`);
  }
} catch {
  /* a bad API host must not stop the app from starting; requests will report their own errors */
}

// If the custom fonts have not loaded after this long, start anyway with the system font instead of showing nothing forever.
const FONT_WAIT_MS = 4000;

/**
 * expo-router wraps this layout (and every screen under it) with this component, so it also covers an error thrown by RootLayout
 * itself. It uses only plain React Native (no theme, providers or navigation), so it can render when everything else is broken.
 */
export function ErrorBoundary({ error, retry }: { error: Error; retry: () => Promise<void> }) {
  const fault = useMemo(() => makeStartupFault(error, 'The app crashed while it was starting', true), [error]);
  return (
    <StartupErrorView
      fault={fault}
      onRetry={() => {
        void retry();
      }}
    />
  );
}

function RootLayoutNav() {
  return (
    <Stack screenOptions={{ headerBackTitle: 'Back' }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="customization" options={{ headerShown: false }} />
      <Stack.Screen name="routines" options={{ headerShown: false }} />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  const [fontsGaveUp, setFontsGaveUp] = useState(false);
  useEffect(() => {
    if (fontsLoaded || fontError) return undefined;
    const timer = setTimeout(() => setFontsGaveUp(true), FONT_WAIT_MS);
    return () => clearTimeout(timer);
  }, [fontsLoaded, fontError]);
  const fontsReady = fontsLoaded || Boolean(fontError) || fontsGaveUp;

  useEffect(() => {
    if (!fontsReady) return;
    try {
      SplashScreen.hideAsync().catch(() => undefined);
    } catch {
      /* the splash screen is cosmetic */
    }
  }, [fontsReady]);

  useEffect(() => {
    try {
      return installGlobalErrorMonitoring();
    } catch {
      // Diagnostics are a convenience: if they cannot start, the app must still start.
      return undefined;
    }
  }, []);

  if (!fontsReady) return null;

  return (
    <StartupFaultGate>
      <SafeAreaProvider>
        <AppErrorBoundary
          onError={(error, stackTrace) => {
            void recordAppError(error, 'Screen rendering', stackTrace);
          }}
        >
          <QueryClientProvider client={queryClient}>
            <KabirProvider>
              <GestureHandlerRootView style={{ flex: 1 }}>
                <KeyboardProvider>
                  <StatusBar style="light" />
                  <RootLayoutNav />
                </KeyboardProvider>
              </GestureHandlerRootView>
            </KabirProvider>
          </QueryClientProvider>
        </AppErrorBoundary>
      </SafeAreaProvider>
    </StartupFaultGate>
  );
}
