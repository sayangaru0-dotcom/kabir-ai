import { useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useScreenAgent } from "@/hooks/useScreenAgent";
import { useWorkflows } from "@/hooks/useWorkflows";
import { describeStepPlain, type Recipe } from "@/lib/learning/recipe";

const STATUS_LABEL: Record<Recipe["status"], string> = {
  draft: "Not tried yet",
  verified: "Works",
  needs_repair: "Needs repair",
};

type ButtonProps = {
  label: string;
  onPress: () => void;
  icon: React.ComponentProps<typeof Feather>["name"];
  tone?: "primary" | "plain";
  disabled?: boolean;
};

function ActionButton({ label, onPress, icon, tone = "primary", disabled }: ButtonProps) {
  const colors = useColors();
  const primary = tone === "primary";
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: primary ? colors.primary : colors.secondary, opacity: disabled ? 0.45 : pressed ? 0.8 : 1 },
      ]}
    >
      <Feather name={icon} size={15} color={primary ? colors.primaryForeground : colors.foreground} />
      <Text style={[styles.buttonText, { color: primary ? colors.primaryForeground : colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

export default function RoutinesScreen() {
  const router = useRouter();
  const colors = useColors();
  const agent = useScreenAgent();
  const wf = useWorkflows({ shareScreenLabels: false });
  const [name, setName] = useState("");
  const [tutorial, setTutorial] = useState("");
  const [appName, setAppName] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);

  const teaching = agent.status?.demonstrating === true;
  const ready = agent.status?.accessibilityEnabled === true;
  const card = { backgroundColor: colors.card, borderColor: colors.border };
  const inputStyle = [styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }];
  const warn = "#F46F5E";

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled">
        <View style={styles.content}>
          <Pressable onPress={() => router.back()} style={[styles.back, { borderColor: colors.border }]}>
            <Feather name="arrow-left" size={15} color={colors.foreground} />
            <Text style={[styles.backText, { color: colors.foreground }]}>Back</Text>
          </Pressable>

          <View style={{ gap: 6 }}>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>AUTOMATION</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Routines</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Teach Kabir a routine once, then ask for it by voice. Everything is saved on this phone.
            </Text>
          </View>

          {!agent.supported || !ready ? (
            <View style={[styles.section, card]}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Screen access is off</Text>
              <Text style={[styles.hint, { color: colors.mutedForeground }]}>
                Routines need Kabir's accessibility service. Turn it on, then come back.
              </Text>
              {agent.supported && <ActionButton icon="settings" label="Open accessibility settings" onPress={agent.enableAccessibility} />}
            </View>
          ) : null}

          <View style={[styles.section, card]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Screen reading</Text>
            <Text style={[styles.hint, { color: colors.mutedForeground }]}>
              Lets Kabir read text that is drawn as pictures (games, canvases) and keeps it running while it works in other apps.
              Android shows a notification while it is on and asks your permission every time.
            </Text>
            {agent.status?.captureRunning ? (
              <ActionButton icon="eye-off" tone="plain" label="Stop screen reading" onPress={agent.stopCapture} />
            ) : (
              <ActionButton
                icon="eye"
                label="Start screen reading"
                disabled={!agent.supported}
                onPress={() => void agent.startCapture({ targetFps: 6, maxFrameDimension: 720 })}
              />
            )}
            {agent.error ? <Text style={{ color: warn, fontSize: 12, lineHeight: 18 }}>{agent.error}</Text> : null}
          </View>

          <View style={[styles.section, card]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Teach by showing</Text>
            <Text style={[styles.hint, { color: colors.mutedForeground }]}>
              Kabir records which buttons you tap, what you scroll and what you type (never passwords) while you do the routine in
              your apps. A notification shows while it records.
            </Text>
            {teaching ? (
              <>
                <Text style={[styles.hint, { color: colors.primary }]}>
                  Recording… {agent.status?.demoEventCount ?? 0} actions. Finish the routine, come back here and tap Finish.
                </Text>
                <TextInput value={name} onChangeText={setName} placeholder="Name this routine" placeholderTextColor={colors.mutedForeground} style={inputStyle} />
                <View style={styles.row}>
                  <ActionButton icon="check" label="Finish" disabled={!name.trim() || !!wf.busy} onPress={() => void wf.finishTeaching(name)} />
                  <ActionButton icon="x" tone="plain" label="Cancel" onPress={() => void wf.cancelTeaching()} />
                </View>
              </>
            ) : (
              <ActionButton icon="video" label="Start teaching" disabled={!ready || !!wf.busy} onPress={() => void wf.startTeaching()} />
            )}
          </View>

          <View style={[styles.section, card]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Learn from a tutorial</Text>
            <Text style={[styles.hint, { color: colors.mutedForeground }]}>
              Paste a transcript, notes or an article. Kabir drafts a routine from the text; you approve it and watch a first run.
              It can only guess button names, so teaching by showing is more reliable.
            </Text>
            <TextInput value={appName} onChangeText={setAppName} placeholder="App (optional), e.g. CapCut" placeholderTextColor={colors.mutedForeground} style={inputStyle} />
            <TextInput
              value={tutorial}
              onChangeText={setTutorial}
              multiline
              placeholder="Paste the tutorial text here"
              placeholderTextColor={colors.mutedForeground}
              style={[...inputStyle, { minHeight: 110, textAlignVertical: "top" }]}
            />
            <ActionButton
              icon="book-open"
              label="Learn it"
              disabled={tutorial.trim().length < 20 || !!wf.busy}
              onPress={() =>
                void wf
                  .learnFromTutorial({ text: tutorial, appName: appName.trim() || undefined, name: name.trim() || undefined })
                  .then((r) => { if (r) setTutorial(""); })
              }
            />
          </View>

          {wf.busy ? (
            <View style={[styles.row, { gap: 10 }]}>
              <ActivityIndicator color={colors.primary} />
              <Text style={{ color: colors.mutedForeground, fontSize: 12, flex: 1 }}>{wf.progress || "Working…"}</Text>
              {wf.busy === "run" && <ActionButton icon="square" tone="plain" label="Stop" onPress={wf.cancel} />}
            </View>
          ) : null}
          {wf.error ? <Text style={{ color: warn, fontSize: 12, lineHeight: 18 }}>{wf.error}</Text> : null}

          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>My routines</Text>
          {wf.recipes.length === 0 ? (
            <Text style={[styles.hint, { color: colors.mutedForeground }]}>Nothing saved yet.</Text>
          ) : (
            wf.recipes.map((r) => (
              <View key={r.id} style={[styles.section, card]}>
                <Pressable onPress={() => setOpenId(openId === r.id ? null : r.id)} style={styles.row}>
                  <View style={{ flex: 1, gap: 3 }}>
                    <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{r.name}</Text>
                    <Text style={[styles.hint, { color: r.status === "needs_repair" ? warn : colors.mutedForeground }]}>
                      {STATUS_LABEL[r.status]} · {r.steps.length} steps{r.app ? ` · ${r.app}` : ""}
                    </Text>
                  </View>
                  <Feather name={openId === r.id ? "chevron-up" : "chevron-down"} size={18} color={colors.mutedForeground} />
                </Pressable>
                {openId === r.id && (
                  <View style={{ gap: 4 }}>
                    {r.steps.map((s, i) => (
                      <Text key={i} style={[styles.hint, { color: colors.foreground }]}>{i + 1}. {describeStepPlain(s)}</Text>
                    ))}
                    {r.warnings.map((w, i) => (
                      <Text key={`w${i}`} style={[styles.hint, { color: colors.mutedForeground }]}>• {w}</Text>
                    ))}
                    {r.stats.lastError ? <Text style={[styles.hint, { color: warn }]}>Last problem: {r.stats.lastError}</Text> : null}
                  </View>
                )}
                <View style={styles.row}>
                  <ActionButton icon="play" label="Run" disabled={!ready || !!wf.busy} onPress={() => void wf.run(r)} />
                  <ActionButton icon="trash-2" tone="plain" label="Delete" onPress={() => wf.remove(r)} />
                </View>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  page: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 52 },
  content: { width: "100%", maxWidth: 640, alignSelf: "center", gap: 16 },
  back: { alignSelf: "flex-start", minHeight: 40, borderWidth: 1, borderRadius: 13, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", gap: 8 },
  backText: { fontSize: 12, fontWeight: "700" },
  eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 1.6 },
  title: { fontSize: 30, lineHeight: 36, fontWeight: "700", letterSpacing: -0.6 },
  subtitle: { fontSize: 13, lineHeight: 20, maxWidth: 520 },
  section: { borderWidth: 1, borderRadius: 22, padding: 16, gap: 12 },
  sectionTitle: { fontSize: 15, fontWeight: "700" },
  hint: { fontSize: 12, lineHeight: 18 },
  row: { flexDirection: "row", gap: 10, alignItems: "center", flexWrap: "wrap" },
  input: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14 },
  button: { minHeight: 42, borderRadius: 14, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", gap: 8 },
  buttonText: { fontSize: 13, fontWeight: "700" },
});
