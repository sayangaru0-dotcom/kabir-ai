import React, { useSyncExternalStore } from "react";
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import {
  clearStartupFault,
  getStartupFault,
  subscribeStartupFault,
  type StartupFault,
} from "../lib/startup-guard";

/**
 * Shown when Kabir cannot start or hits a fatal error. It deliberately depends on NOTHING from the app (no theme, no providers,
 * no navigation, no safe-area context, no custom fonts): it must be able to render when everything else is broken.
 */

const WAITING: StartupFault = {
  source: "Startup",
  message: "The app did not finish starting, and no error was reported.",
  details: "",
  at: "",
  fatal: false,
  more: 0,
};

function restart() {
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const expo = require("expo") as { reloadAppAsync?: (reason?: string) => Promise<void> };
    void expo.reloadAppAsync?.("Restart after a startup problem");
  } catch {
    /* if even this is unavailable, the user can close and reopen the app */
  }
}

export function StartupErrorView({ fault, onRetry }: { fault: StartupFault; onRetry?: () => void }) {
  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Text style={styles.eyebrow}>KABIR AI</Text>
        <Text style={styles.title}>Kabir hit a problem while starting</Text>
        <Text style={styles.body}>
          Nothing was lost. Take a screenshot of this screen, or touch and hold the box below to copy the text, and send it to
          whoever maintains the app. That is exactly what is needed to fix it.
        </Text>

        <View style={styles.box}>
          <Text style={styles.label}>{fault.source}</Text>
          <Text selectable style={styles.message}>
            {fault.message}
          </Text>
          {fault.details ? (
            <Text selectable style={styles.details}>
              {fault.details}
            </Text>
          ) : null}
          <Text style={styles.meta}>
            {fault.at ? `${fault.at}  ` : ""}
            {fault.more > 0 ? `(+${fault.more} more error${fault.more > 1 ? "s" : ""} after this one)` : ""}
          </Text>
        </View>

        <View style={styles.row}>
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              clearStartupFault();
              onRetry?.();
            }}
            style={({ pressed }) => [styles.button, styles.primary, pressed && styles.pressed]}
          >
            <Text style={styles.primaryText}>Try again</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            onPress={restart}
            style={({ pressed }) => [styles.button, styles.secondary, pressed && styles.pressed]}
          >
            <Text style={styles.secondaryText}>Restart app</Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

/** Root registered by index.js before the real app; it stays only if the real app never registers. */
export function StartupErrorRoot() {
  const fault = useSyncExternalStore(subscribeStartupFault, getStartupFault, getStartupFault);
  return <StartupErrorView fault={fault ?? WAITING} />;
}

/** Wraps the real app: shows the error screen whenever a fatal error was reported, otherwise renders the app. */
export function StartupFaultGate({ children }: { children: React.ReactNode }) {
  const fault = useSyncExternalStore(subscribeStartupFault, getStartupFault, getStartupFault);
  if (fault) return <StartupErrorView fault={fault} />;
  return <>{children}</>;
}

const mono = Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" });

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#0B110E" },
  content: { padding: 24, paddingTop: 64, paddingBottom: 48 },
  eyebrow: { color: "#7CC49A", fontSize: 11, fontWeight: "800", letterSpacing: 1.6, marginBottom: 8 },
  title: { color: "#F2F7F3", fontSize: 24, fontWeight: "700", marginBottom: 12 },
  body: { color: "#B9C7BD", fontSize: 14, lineHeight: 21, marginBottom: 18 },
  box: { backgroundColor: "#141D18", borderColor: "#27352C", borderWidth: 1, borderRadius: 16, padding: 14, marginBottom: 20 },
  label: { color: "#F4A3A3", fontSize: 11, fontWeight: "800", letterSpacing: 1, marginBottom: 6 },
  message: { color: "#F2F7F3", fontSize: 14, lineHeight: 20, marginBottom: 8 },
  details: { color: "#9FB0A5", fontSize: 11, lineHeight: 16, fontFamily: mono },
  meta: { color: "#6F8176", fontSize: 11, marginTop: 8 },
  row: { flexDirection: "row", gap: 12 },
  button: { flex: 1, minHeight: 48, borderRadius: 14, alignItems: "center", justifyContent: "center", paddingHorizontal: 12 },
  primary: { backgroundColor: "#7CC49A" },
  secondary: { backgroundColor: "#1B2720", borderWidth: 1, borderColor: "#27352C" },
  primaryText: { color: "#0B110E", fontSize: 14, fontWeight: "700" },
  secondaryText: { color: "#F2F7F3", fontSize: 14, fontWeight: "700" },
  pressed: { opacity: 0.8 },
});
