import { Feather } from "@expo/vector-icons";
import { StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";
import type { LogoVariant } from "@/constants/themes";

const logoIcons: Record<Exclude<LogoVariant, "monogram">, keyof typeof Feather.glyphMap> = {
  orbit: "aperture",
  voice: "mic",
  signal: "radio",
  pulse: "activity",
};

type BrandMarkProps = {
  variant: LogoVariant;
  brandName: string;
  size?: number;
};

export function BrandMark({ variant, brandName, size = 40 }: BrandMarkProps) {
  const colors = useColors();
  const monogram = brandName.trim().charAt(0).toLocaleUpperCase() || "K";

  return (
    <View
      accessibilityRole="image"
      accessibilityLabel={`${brandName || "Kabir AI"} ${variant} logo`}
      style={[
        styles.mark,
        {
          width: size,
          height: size,
          borderRadius: size * 0.34,
          backgroundColor: colors.secondary,
          borderColor: colors.border,
        },
      ]}
    >
      {variant === "monogram" ? (
        <Text style={{ color: colors.primary, fontSize: size * 0.46, fontWeight: "800" }}>
          {monogram}
        </Text>
      ) : (
        <Feather name={logoIcons[variant]} size={size * 0.5} color={colors.primary} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  mark: {
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
  },
});
