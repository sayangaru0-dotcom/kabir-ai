import { StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";
import type { KabirStatus } from "@/context/KabirContext";

type Props = {
  status: KabirStatus;
};

export function StatusBadge({ status }: Props) {
  const colors = useColors();
  const isActive = status === "Active";
  const isLearning = status === "Learning";
  const foreground = isActive
    ? colors.background
    : isLearning
      ? colors.accentForeground
      : colors.mutedForeground;
  const background = isActive
    ? colors.primary
    : isLearning
      ? colors.accent
      : colors.secondary;

  return (
    <View style={[styles.badge, { backgroundColor: background }]}>
      <View style={[styles.dot, { backgroundColor: foreground }]} />
      <Text style={[styles.label, { color: foreground }]}>{status}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    minHeight: 32,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 12,
    borderRadius: 999,
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  label: {
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 0.2,
  },
});
