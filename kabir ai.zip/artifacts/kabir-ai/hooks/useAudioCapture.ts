import {
  AudioModule,
  RecordingPresets,
  useAudioRecorder,
  useAudioRecorderState,
} from "expo-audio";
import * as FileSystem from "expo-file-system/legacy";
import { useCallback, useEffect, useRef } from "react";
import { Alert, Linking, Platform } from "react-native";
import { recordAppError } from "@/lib/error-monitor";

export type RecordedClip = {
  audioBase64: string;
  fileName: string;
  hasSpeech: boolean;
};

async function readClipAsBase64(uri: string) {
  if (Platform.OS !== "web") {
    return FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });
  }

  const response = await fetch(uri);
  const bytes = new Uint8Array(await response.arrayBuffer());
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
  }
  return btoa(binary);
}

async function removeClip(uri: string) {
  if (Platform.OS === "web") {
    if (uri.startsWith("blob:")) URL.revokeObjectURL(uri);
    return;
  }
  await FileSystem.deleteAsync(uri, { idempotent: true });
}

export function useAudioCapture() {
  const peakMetering = useRef(-160);
  const recorder = useAudioRecorder({
    // Voice recognition does not need music-grade capture; smaller clips reduce
    // encoding work and storage use during repeated wake listening.
    ...RecordingPresets.LOW_QUALITY,
    isMeteringEnabled: true,
  });
  const recorderState = useAudioRecorderState(recorder, 500);

  useEffect(() => {
    if (typeof recorderState.metering === "number") {
      peakMetering.current = Math.max(peakMetering.current, recorderState.metering);
    }
  }, [recorderState.metering]);

  const startRecording = useCallback(async () => {
    const permission = await AudioModule.requestRecordingPermissionsAsync();
    if (!permission.granted) {
      void recordAppError(new Error("Microphone permission was denied."), "Microphone recording");
      Alert.alert(
        "Microphone access needed",
        Platform.OS === "web"
          ? "Allow microphone access in your browser, then try again."
          : "Allow microphone access in device settings to record a phrase or voice request.",
        Platform.OS === "web"
          ? [{ text: "OK" }]
          : [
              { text: "Not now", style: "cancel" },
              { text: "Open settings", onPress: () => void Linking.openSettings() },
            ],
      );
      return false;
    }

    peakMetering.current = -160;
    await AudioModule.setAudioModeAsync({
      allowsRecording: true,
      playsInSilentMode: true,
    });
    await recorder.prepareToRecordAsync();
    recorder.record();
    return true;
  }, [recorder]);

  const stopAndRead = useCallback(async (): Promise<RecordedClip | null> => {
    const latestMetering = recorder.getStatus().metering;
    if (typeof latestMetering === "number") {
      peakMetering.current = Math.max(peakMetering.current, latestMetering);
    }
    const uriBeforeStop = recorder.getStatus().url;
    await recorder.stop();
    const uri = recorder.getStatus().url ?? uriBeforeStop;
    await AudioModule.setAudioModeAsync({
      allowsRecording: false,
      playsInSilentMode: true,
    });
    if (!uri) {
      throw new Error("The recording file was not created. Please try again.");
    }

    try {
      const audioBase64 = await readClipAsBase64(uri);
      await removeClip(uri);
      return {
        audioBase64,
        fileName: Platform.OS === "web" ? "kabir-recording.webm" : "kabir-recording.m4a",
        hasSpeech: peakMetering.current > -52,
      };
    } catch (error) {
      await removeClip(uri).catch(() => undefined);
      throw error;
    }
  }, [recorder]);

  const discardRecording = useCallback(async () => {
    const uriBeforeStop = recorder.getStatus().url;
    if (recorder.getStatus().isRecording) {
      await recorder.stop();
    }
    const uri = recorder.getStatus().url ?? uriBeforeStop;
    await AudioModule.setAudioModeAsync({
      allowsRecording: false,
      playsInSilentMode: true,
    });
    if (uri) await removeClip(uri);
  }, [recorder]);

  return {
    recording: recorderState.isRecording,
    durationSeconds: recorderState.durationMillis / 1000,
    startRecording,
    stopAndRead,
    discardRecording,
  };
}
