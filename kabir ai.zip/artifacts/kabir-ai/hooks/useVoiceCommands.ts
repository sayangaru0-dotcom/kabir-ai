import { useCallback, useEffect, useRef, useState } from "react";
import * as Agent from "@/modules/kabir-screen-agent";
import { useKabir } from "@/context/KabirContext";
import { describeStep, runSteps, type RunReport } from "@/lib/screen-commands/executor";
import { approvePlan, confirmDialog } from "@/lib/screen-commands/approval";
import { listRecipes } from "@/lib/learning/recipe-store";
import { runRecipe } from "@/lib/learning/run-recipe";
import { reportAutomationIssue } from "@/lib/screen-commands/diagnostics";
import { deviceLocale, pickRelevantLearning, requestCommand } from "@/lib/screen-commands/planner";
import { sleep } from "@/lib/screen-commands/precise-touch";
import type { Step } from "@/lib/screen-commands/steps";

export type CommandOutcome = {
  kind: "chat" | "screen" | "recipe";
  speak: string;
  audioBase64: string;
  report?: RunReport;
  /** Human-readable problem for the UI, if the screen action did not complete. */
  problem?: string;
};

type HandleHooks = {
  /** Called as soon as Kabir has something to say (answer, or "Opening Settings"). Playback may overlap execution. */
  onSpeak?: (speak: string, audioBase64: string) => Promise<void> | void;
};

/** True while the Accessibility Service is connected. Re-renders only when that flips. */
function useAgentReady() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if (!Agent.isScreenAgentSupported) return;
    const check = () => setReady(Agent.getStatus().accessibilityEnabled);
    check();
    const timer = setInterval(check, 2000);
    const sub = Agent.addScreenAgentListener("onServiceState", check);
    return () => {
      clearInterval(timer);
      sub.remove();
    };
  }, []);
  return ready;
}

function problemText(report: RunReport): string {
  const step = report.failedStep;
  const what = step ? describeStep(step) : "that step";
  switch (report.reason) {
    case "cancelled": return "Stopped.";
    case "declined": return "Okay, I didn't do it.";
    case "accessibility_off": return "Turn on Kabir's accessibility service so I can use the screen.";
    case "not_found": return `I couldn't find it on the screen (${what}).`;
    case "end_of_content": return `I reached the end and didn't find it (${what}).`;
    case "blocked_app": return "That app is on your blocked list, so I left it alone.";
    case "app_not_found": return `I couldn't find that app (${what}).`;
    case "timeout": return "That took too long, so I stopped.";
    default: return `I couldn't finish (${what}).`;
  }
}

/** Up to 60 distinct visible labels. Used only for the opt-in "re-plan after failure" request. */
function collectScreenLabels(): string[] {
  const snap = Agent.getScreenSnapshot({ includeNodes: true, includeOcr: false });
  const seen = new Set<string>();
  for (const n of snap.nodes) {
    const t = (n.text || n.description).trim();
    if (t && t.length <= 60) seen.add(t);
    if (seen.size >= 60) break;
  }
  return [...seen];
}

export function useVoiceCommands(options: { shareScreenLabels?: boolean } = {}) {
  const { responseLanguage, learningEntries } = useKabir();
  const available = useAgentReady();
  const abortRef = useRef<AbortController | null>(null);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState("");

  const cancel = useCallback(() => abortRef.current?.abort(), []);

  const execute = useCallback(
    async (steps: Step[], approved: Set<string>, signal: AbortSignal): Promise<RunReport> =>
      runSteps(steps, {
        signal,
        approved,
        confirm: confirmDialog,
        onProgress: (p) => setProgress(`${p.index + 1}/${p.total}: ${describeStep(p.step)}`),
      }),
    [],
  );

  const handle = useCallback(
    async (transcript: string, hooks: HandleHooks = {}): Promise<CommandOutcome> => {
      const base = { transcript, responseLanguage, uiLanguage: deviceLocale() };
      const recipes = (await listRecipes()).filter((r) => r.status !== "needs_repair");
      const plan = await requestCommand({
        ...base,
        learned: pickRelevantLearning(transcript, learningEntries),
        recipes: recipes.map((r) => ({ name: r.name, description: r.description, params: r.params.map((p) => p.name) })),
      });
      await hooks.onSpeak?.(plan.speak, plan.audioBase64);
      if (plan.kind === "chat") return { kind: "chat", speak: plan.speak, audioBase64: plan.audioBase64 };

      if (plan.kind === "recipe" && plan.recipe) {
        // The planner may only call a routine the user actually saved; it can't invent one.
        const wanted = plan.recipe.name.toLowerCase();
        const recipe = recipes.find((r) => r.name.toLowerCase() === wanted);
        if (!recipe) {
          return { kind: "recipe", speak: plan.speak, audioBase64: plan.audioBase64, problem: "I couldn't find that routine." };
        }
        const controller = new AbortController();
        abortRef.current = controller;
        setRunning(true);
        try {
          await sleep(Math.min(3000, 400 + plan.speak.length * 55), controller.signal).catch(() => undefined);
          const result = await runRecipe(recipe, plan.recipe.params, {
            signal: controller.signal,
            onProgress: (p) => setProgress(`${p.index + 1}/${p.total}: ${describeStep(p.step)}`),
          });
          if (result.problem) reportAutomationIssue("Routine", result.problem, result.report.reason);
          return { kind: "recipe", speak: plan.speak, audioBase64: plan.audioBase64, report: result.report, problem: result.problem };
        } finally {
          abortRef.current = null;
          setRunning(false);
          setProgress("");
        }
      }

      const controller = new AbortController();
      abortRef.current = controller;
      setRunning(true);
      try {
        let approved = await approvePlan(plan.steps);
        if (!approved) {
          return { kind: "screen", speak: plan.speak, audioBase64: plan.audioBase64, problem: "Okay, I didn't do it." };
        }
        // Let the confirmation sentence be heard before Kabir steps aside (its audio stops when the app is backgrounded).
        await sleep(Math.min(3000, 400 + plan.speak.length * 55), controller.signal).catch(() => undefined);

        let report = await execute(plan.steps, approved, controller.signal);

        // One recovery attempt, only if the user opted in to sending visible labels to the planner.
        const canReplan =
          !report.ok && options.shareScreenLabels && report.failedStep &&
          report.reason !== "cancelled" && report.reason !== "declined" && report.reason !== "blocked_app" &&
          report.reason !== "accessibility_off";
        if (canReplan && report.failedStep) {
          const retry = await requestCommand({
            ...base,
            screenLabels: collectScreenLabels(),
            failed: { step: report.failedStep, reason: report.reason ?? "unknown" },
          });
          if (retry.kind === "screen") {
            approved = await approvePlan(retry.steps);
            if (approved) report = await execute(retry.steps, approved, controller.signal);
          }
        }
        const problem = report.ok ? undefined : problemText(report);
        if (problem) reportAutomationIssue("Screen command", problem, report.reason);
        return {
          kind: "screen",
          speak: plan.speak,
          audioBase64: plan.audioBase64,
          report,
          problem,
        };
      } finally {
        abortRef.current = null;
        setRunning(false);
        setProgress("");
      }
    },
    [execute, learningEntries, options.shareScreenLabels, responseLanguage],
  );

  return { available, running, progress, handle, cancel };
}
