import { useCallback, useEffect, useState } from "react";
import {
  addScreenAgentListener,
  getStatus,
  isScreenAgentSupported,
  openAccessibilitySettings,
  startScreenCapture,
  stopScreenCapture,
  type AgentStatus,
  type CaptureOptions,
  type FrameAnalysisEvent,
} from "@/modules/kabir-screen-agent";
import { reportAutomationIssue } from "@/lib/screen-commands/diagnostics";

/** Live status of the screen agent for dashboard UI. Polls cheaply and listens to service events. */
export function useScreenAgent() {
  const [status, setStatus] = useState<AgentStatus | null>(null);
  const [lastFrame, setLastFrame] = useState<FrameAnalysisEvent | null>(null);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(() => {
    if (!isScreenAgentSupported) return;
    try {
      setStatus(getStatus());
    } catch {
      /* status polling must never throw from a timer */
    }
  }, []);

  useEffect(() => {
    if (!isScreenAgentSupported) return;
    refresh();
    const timer = setInterval(refresh, 1000);
    const subs = [
      addScreenAgentListener("onServiceState", refresh),
      addScreenAgentListener("onFrameAnalysis", setLastFrame),
      addScreenAgentListener("onAgentError", (e) => {
        setError(`${e.where}: ${e.message}`);
        reportAutomationIssue("Screen agent", `${e.where}: ${e.message}`);
      }),
    ];
    return () => {
      clearInterval(timer);
      subs.forEach((s) => s.remove());
    };
  }, [refresh]);

  const start = useCallback(async (options?: CaptureOptions) => {
    setError(null);
    try {
      const ok = await startScreenCapture(options);
      refresh();
      return ok;
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      return false;
    }
  }, [refresh]);

  const stop = useCallback(() => {
    stopScreenCapture();
    refresh();
  }, [refresh]);

  return {
    supported: isScreenAgentSupported,
    status,
    lastFrame,
    error,
    enableAccessibility: openAccessibilitySettings,
    startCapture: start,
    stopCapture: stop,
  };
}
