import { useCallback, useEffect, useRef, useState } from "react";
import { Alert } from "react-native";
import * as Agent from "@/modules/kabir-screen-agent";
import { useKabir } from "@/context/KabirContext";
import { describeStep } from "@/lib/screen-commands/executor";
import { confirmDialog } from "@/lib/screen-commands/approval";
import { demoToRecipe } from "@/lib/learning/demo-to-steps";
import { describeRecipe, type Recipe } from "@/lib/learning/recipe";
import { deleteRecipe, listRecipes, saveRecipe } from "@/lib/learning/recipe-store";
import { runRecipe } from "@/lib/learning/run-recipe";
import { recordAppError } from "@/lib/error-monitor";
import { reportAutomationIssue } from "@/lib/screen-commands/diagnostics";
import { learnFromText, proposeRepair } from "@/lib/learning/tutorial-learner";

/**
 * Everything the Routines screen needs: list / teach by demonstration / learn from tutorial text / run / repair.
 * `shareScreenLabels` is the opt-in that lets a broken routine send the visible labels to the planner for repair.
 */
export function useWorkflows(options: { shareScreenLabels?: boolean } = {}) {
  const { responseLanguage } = useKabir();
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [progress, setProgress] = useState("");
  const [error, setError] = useState("");
  const abortRef = useRef<AbortController | null>(null);

  const refresh = useCallback(async () => setRecipes(await listRecipes()), []);
  useEffect(() => { void refresh(); }, [refresh]);

  const guard = useCallback(async <T,>(label: string, fn: () => Promise<T>): Promise<T | undefined> => {
    setError("");
    setBusy(label);
    try {
      return await fn();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      void recordAppError(e, "Routines");
      return undefined;
    } finally {
      setBusy(null);
      void refresh();
    }
  }, [refresh]);

  // ── Teach by demonstration ──────────────────────────────────────
  /** Starts recording and sends Kabir to the background so the user can perform the routine in their apps. */
  const startTeaching = useCallback(() => guard("teach", async () => {
    await Agent.startDemonstration();
    Agent.minimizeApp();
  }), [guard]);

  const finishTeaching = useCallback((name: string) => guard("teach", async () => {
    const events = await Agent.stopDemonstration();
    const { recipe } = demoToRecipe(events, { name, ownPackage: Agent.getStatus().ownPackage });
    if (recipe.steps.length === 0) throw new Error("I didn't record any steps. Try again and perform the routine in another app.");
    await saveRecipe(recipe);
    return recipe;
  }), [guard]);

  const cancelTeaching = useCallback(async () => {
    await Agent.stopDemonstration().catch(() => undefined); // discards the buffer
  }, []);

  // ── Learn from tutorial text ────────────────────────────────────
  const learnFromTutorial = useCallback(
    (input: { text: string; appName?: string; goal?: string; name?: string }) =>
      guard("learn", async () => {
        const recipe = await learnFromText({ ...input, responseLanguage });
        await saveRecipe(recipe);
        return recipe;
      }),
    [guard, responseLanguage],
  );

  // ── Run / repair / delete ───────────────────────────────────────
  const cancel = useCallback(() => abortRef.current?.abort(), []);

  const run = useCallback((recipe: Recipe, params: Record<string, string> = {}) =>
    guard("run", async () => {
      const controller = new AbortController();
      abortRef.current = controller;
      try {
        Agent.minimizeApp();
        const result = await runRecipe(recipe, params, {
          signal: controller.signal,
          onProgress: (p) => setProgress(`${p.index + 1}/${p.total}: ${describeStep(p.step)}`),
        });
        if (result.problem) {
          setError(result.problem);
          reportAutomationIssue("Routine", result.problem, result.report.reason);
        }

        // Self-repair: only after a real failure, only if the user opted in to sharing visible labels.
        if (
          options.shareScreenLabels && !result.report.ok && result.report.failedStep &&
          result.recipe.status === "needs_repair"
        ) {
          const labels = Agent.getScreenSnapshot({ includeNodes: true, includeOcr: false }).nodes
            .map((n) => (n.text || n.description).trim())
            .filter((t) => t && t.length <= 60)
            .slice(0, 60);
          const proposal = await proposeRepair(
            result.recipe, result.report.completed, result.report.reason ?? "unknown", [...new Set(labels)], responseLanguage,
          );
          if (proposal) {
            const ok = await confirmDialog({
              title: `Update "${recipe.name}"?`,
              message: `${proposal.note ? proposal.note + "\n\n" : ""}New version:\n\n${describeRecipe(proposal.recipe)}`,
            });
            if (ok) await saveRecipe(proposal.recipe);
          }
        }
        return result;
      } finally {
        abortRef.current = null;
        setProgress("");
      }
    }),
    [guard, options.shareScreenLabels, responseLanguage],
  );

  const remove = useCallback((recipe: Recipe) => {
    Alert.alert("Delete routine?", `"${recipe.name}" will be removed from this phone.`, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => { void deleteRecipe(recipe.id).then(refresh); } },
    ]);
  }, [refresh]);

  return {
    recipes, busy, progress, error,
    startTeaching, finishTeaching, cancelTeaching,
    learnFromTutorial, run, cancel, remove, refresh,
  };
}
