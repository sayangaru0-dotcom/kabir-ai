import colors from '@/constants/colors';
import { useKabirOptional } from '@/context/KabirContext';
import { getThemePreset } from '@/constants/themes';

/**
 * Returns Kabir's dark design tokens consistently on native and web.
 *
 * The returned object contains all color tokens for the active palette
 * plus scheme-independent values like `radius`.
 *
 * The dashboard is intentionally dark regardless of device appearance.
 */
export function useColors() {
  const appearance = useKabirOptional()?.appearance;
  const theme = getThemePreset(appearance?.themeId ?? 'forest');

  return {
    ...colors.dark,
    ...theme.colors,
    ...(appearance?.colorOverrides ?? {}),
    radius: colors.radius,
  };
}
