"use strict";
/**
 * Custom entry point (package.json "main"). Order matters:
 *   1. install the early error guard and register a minimal fallback root, BEFORE anything else can fail;
 *   2. then load the real app (expo-router). If loading throws, the error is shown on screen instead of killing the process.
 * Written with require() on purpose: static imports are hoisted and would run before step 1.
 */
const guard = require("./lib/startup-guard");
const screen = require("./components/StartupErrorScreen");

guard.installEarlyErrorGuard();
guard.registerFallbackRoot(screen.StartupErrorRoot);

try {
  require("expo-router/entry");
} catch (error) {
  guard.reportStartupFault(error, "The app failed to load", true);
}
