import { Alert } from "react-native";
import type { ConfirmRequest } from "./executor";
import { normLabel, sensitiveLabelsIn, type Step } from "./steps";

export function confirmDialog({ title, message }: ConfirmRequest): Promise<boolean> {
  return new Promise((resolve) => {
    Alert.alert(
      title,
      message,
      [
        { text: "Cancel", style: "cancel", onPress: () => resolve(false) },
        { text: "Continue", onPress: () => resolve(true) },
      ],
      { cancelable: true, onDismiss: () => resolve(false) },
    );
  });
}

/** Confirm once, up front, for any sensitive step. Returns the approved set, or null if the user declined. */
export async function approvePlan(
  steps: Step[],
  confirm: (r: ConfirmRequest) => Promise<boolean> = confirmDialog,
): Promise<Set<string> | null> {
  const sensitive = sensitiveLabelsIn(steps);
  const approved = new Set<string>();
  if (sensitive.length === 0) return approved;
  const ok = await confirm({
    title: "Confirm action",
    message: `Kabir is about to tap: ${sensitive.map((s) => `"${s}"`).join(", ")}. Continue?`,
  });
  if (!ok) return null;
  sensitive.forEach((s) => approved.add(normLabel(s)));
  return approved;
}
