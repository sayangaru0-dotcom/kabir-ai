import * as Agent from "@/modules/kabir-screen-agent";
import type { Direction } from "./steps";

export class AbortError extends Error {
  constructor() {
    super("Cancelled");
    this.name = "AbortError";
  }
}

export function throwIfAborted(signal?: AbortSignal) {
  if (signal?.aborted) throw new AbortError();
}

export function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new AbortError());
    const t = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(t);
      reject(new AbortError());
    };
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

const dist = (a: { x: number; y: number }, b: { x: number; y: number }) => Math.hypot(a.x - b.x, a.y - b.y);

/** Polls `fn` until it returns a value (not null/undefined) or the timeout passes. */
export async function waitFor<T>(
  fn: () => T | null | undefined,
  timeoutMs: number,
  signal?: AbortSignal,
  intervalMs = 150,
): Promise<T | null> {
  const start = Date.now();
  for (;;) {
    throwIfAborted(signal);
    const v = fn();
    if (v !== null && v !== undefined) return v;
    if (Date.now() - start >= timeoutMs) return null;
    await sleep(intervalMs, signal);
  }
}

// ───────────── Waiting on the screen, not on the clock ─────────────

/** Resolves true when the screen stops changing for `quietMs` (animations/loading finished). */
export async function waitForSettle(o: { quietMs?: number; timeoutMs?: number; signal?: AbortSignal } = {}): Promise<boolean> {
  const quietMs = o.quietMs ?? 250;
  const timeoutMs = o.timeoutMs ?? 2500;
  const start = Date.now();
  let last = Agent.getChangeSeq();
  let lastChangeAt = start;
  while (Date.now() - start < timeoutMs) {
    await sleep(50, o.signal);
    const seq = Agent.getChangeSeq();
    if (seq !== last) {
      last = seq;
      lastChangeAt = Date.now();
    } else if (Date.now() - lastChangeAt >= quietMs) {
      return true;
    }
  }
  return false;
}

/** Resolves true as soon as the screen changes after `sinceSeq`. */
export async function waitForChange(sinceSeq: number, timeoutMs: number, signal?: AbortSignal): Promise<boolean> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (Agent.getChangeSeq() !== sinceSeq) return true;
    await sleep(30, signal);
  }
  return Agent.getChangeSeq() !== sinceSeq;
}

// ───────────── Target finding ─────────────

export function findBest(text: string, minConfidence = 0.6): Agent.Target | null {
  const [best] = Agent.findTargets(text);
  return best && best.confidence >= minConfidence ? best : null;
}

/**
 * Precision step 1: don't tap something that is still moving.
 * Resolve twice ~60 ms apart; only accept when both positions agree within `tolerancePx`.
 * (Sliding sheets, list animations and loading shifts otherwise cause taps that land on the wrong item.)
 */
export async function findStable(
  text: string,
  o: { minConfidence?: number; tolerancePx?: number; attempts?: number; signal?: AbortSignal } = {},
): Promise<{ target: Agent.Target; stable: boolean } | null> {
  const tol = o.tolerancePx ?? 6;
  const attempts = o.attempts ?? 6;
  let prev = findBest(text, o.minConfidence);
  for (let i = 0; i < attempts; i++) {
    if (!prev) {
      await sleep(120, o.signal);
      prev = findBest(text, o.minConfidence);
      continue;
    }
    await sleep(60, o.signal);
    const cur = findBest(text, o.minConfidence);
    if (cur && dist(prev, cur) <= tol) return { target: cur, stable: true };
    prev = cur;
  }
  return prev ? { target: prev, stable: false } : null; // never settled (marquee etc.): best effort
}

// ───────────── Tap with verification ─────────────

export type TapOutcome = {
  ok: boolean;
  /** true when the screen reacted to the tap */
  verified: boolean;
  target?: Agent.Target;
  reason?: string;
};

export type TapOptions = {
  minConfidence?: number;
  longPress?: boolean;
  signal?: AbortSignal;
  /** Called with the label that is about to be tapped. Return false to abort (user declined). */
  guard?: (resolvedLabel: string, requestedText: string) => Promise<boolean>;
};

/**
 * Find -> stabilise -> guard -> tap at exact float pixels -> verify the screen reacted.
 * If a tap on a real clickable control produced no visible reaction, retry ONCE with a semantic
 * ACTION_CLICK on that control (some views ignore synthetic touches but honour accessibility clicks).
 */
export async function preciseTap(text: string, o: TapOptions = {}): Promise<TapOutcome> {
  const min = o.minConfidence ?? 0.6;
  let found = await findStable(text, { minConfidence: min, signal: o.signal });
  if (!found) return { ok: false, verified: false, reason: "not_found" };

  if (o.guard) {
    const allowed = await o.guard(found.target.label, text);
    if (!allowed) return { ok: false, verified: false, target: found.target, reason: "declined" };
    // The user took time to read a dialog; the screen may have moved. Re-resolve.
    found = (await findStable(text, { minConfidence: min, signal: o.signal })) ?? found;
  }

  const t = found.target;
  throwIfAborted(o.signal);
  const seq = Agent.getChangeSeq();
  const res = o.longPress ? await Agent.longPress(t.x, t.y) : await Agent.tap(t.x, t.y);
  if (!res.ok) return { ok: false, verified: false, target: t, reason: res.reason ?? "tap_failed" };

  if (await waitForChange(seq, 700, o.signal)) return { ok: true, verified: true, target: t };

  if (!o.longPress && (t.source === "node" || t.source === "ocr+node")) {
    const seq2 = Agent.getChangeSeq();
    const retry = await Agent.tapText(t.label, { minConfidence: min, preferNodeAction: true });
    if (retry.ok && (await waitForChange(seq2, 700, o.signal))) return { ok: true, verified: true, target: t };
  }
  return { ok: true, verified: false, target: t };
}

// ───────────── Scrolling to find ─────────────

export async function scrollUntilVisible(
  text: string,
  o: { direction?: Direction; maxScrolls?: number; minConfidence?: number; signal?: AbortSignal } = {},
): Promise<{ found: boolean; scrolls: number; reason?: string }> {
  const direction = o.direction ?? "down";
  const max = o.maxScrolls ?? 6;
  let stagnant = 0;
  for (let i = 0; i <= max; i++) {
    throwIfAborted(o.signal);
    if (findBest(text, o.minConfidence)) return { found: true, scrolls: i };
    if (i === max) break;
    const seq = Agent.getChangeSeq();
    const r = await Agent.scroll(direction);
    if (!r.ok) return { found: false, scrolls: i, reason: r.reason ?? "scroll_failed" };
    await waitForSettle({ quietMs: 200, timeoutMs: 1500, signal: o.signal });
    // Two scrolls in a row that change nothing = we hit the end of the list.
    if (Agent.getChangeSeq() === seq) {
      if (++stagnant >= 2) return { found: false, scrolls: i + 1, reason: "end_of_content" };
    } else {
      stagnant = 0;
    }
  }
  return { found: false, scrolls: max, reason: "not_found" };
}
