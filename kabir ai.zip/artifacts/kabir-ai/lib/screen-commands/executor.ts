import * as Agent from "@/modules/kabir-screen-agent";
import {
  AbortError,
  findBest,
  preciseTap,
  scrollUntilVisible,
  sleep,
  throwIfAborted,
  waitForChange,
  waitForSettle,
} from "./precise-touch";
import { detectSquareBoard, squareCenter } from "./grid";
import { isSensitiveLabel, normLabel, type Step } from "./steps";
import { WORKFLOWS } from "@/lib/workflows";

export type StepResult = { step: Step; ok: boolean; detail?: string; verified?: boolean };

export type RunReport = {
  ok: boolean;
  completed: number;
  total: number;
  failedStep?: Step;
  /** machine-readable: cancelled | timeout | accessibility_off | declined | not_found | blocked_app | end_of_content | ... */
  reason?: string;
  log: StepResult[];
};

export type ConfirmRequest = { title: string; message: string };

export type RunOptions = {
  signal?: AbortSignal;
  /** Asks the user. REQUIRED for sensitive labels; without it sensitive taps are refused. */
  confirm?: (req: ConfirmRequest) => Promise<boolean>;
  /** Normalised labels the user already approved for this plan. */
  approved?: Set<string>;
  onProgress?: (p: { index: number; total: number; step: Step }) => void;
  maxDurationMs?: number;
};

function describe(step: Step): string {
  switch (step.type) {
    case "openApp": return `open ${step.name}`;
    case "global": return step.name;
    case "tapText": return `tap "${step.text}"`;
    case "longPressText": return `long-press "${step.text}"`;
    case "scroll": return `scroll ${step.direction}`;
    case "scrollUntilVisible": return `find "${step.text}"`;
    case "typeText": return "type text";
    case "waitForText": return `wait for "${step.text}"`;
    case "wait": return "wait";
    case "tapAt": return "tap a position";
    case "dragAt": return "drag";
    case "pinch": return step.to < step.from ? "pinch in" : "pinch out";
    case "pressEnter": return "press enter";
    case "boardMove": return `move ${step.from}→${step.to}`;
    case "workflow": return `${step.name} "${step.query}"`;
  }
}
export { describe as describeStep };

export async function runSteps(steps: Step[], opts: RunOptions = {}): Promise<RunReport> {
  const started = Date.now();
  const maxMs = opts.maxDurationMs ?? 90_000;
  const log: StepResult[] = [];
  const total = steps.length;
  const fail = (i: number, reason: string): RunReport => ({
    ok: false, completed: i, total, failedStep: steps[i], reason, log,
  });

  const status = Agent.getStatus();
  if (!status.accessibilityEnabled) return fail(0, "accessibility_off");

  // Voice requests start inside Kabir, so Kabir is the foreground app. Step aside first, otherwise
  // "scroll down" or "tap Send" would act on Kabir's own screen.
  const first = steps[0];
  const leavesByItself =
    first.type === "openApp" || first.type === "workflow" || (first.type === "global" && first.name === "home");
  if (status.foregroundPackage === status.ownPackage && !leavesByItself) {
    Agent.minimizeApp();
    await sleep(500, opts.signal).catch(() => undefined);
    await waitForSettle({ quietMs: 300, timeoutMs: 2000, signal: opts.signal }).catch(() => undefined);
  }

  // Guard for sensitive labels. The check is on what is ACTUALLY about to be tapped (the resolved label),
  // so a harmless-looking planned text that resolves to "Delete all" still asks the user.
  const approved = opts.approved ?? new Set<string>();
  const guard = async (resolvedLabel: string, requestedText: string): Promise<boolean> => {
    if (!isSensitiveLabel(resolvedLabel) && !isSensitiveLabel(requestedText)) return true;
    if (approved.has(normLabel(resolvedLabel)) && approved.has(normLabel(requestedText))) return true;
    if (!opts.confirm) return false;
    const ok = await opts.confirm({
      title: "Confirm action",
      message: `Kabir is about to tap "${resolvedLabel}". Continue?`,
    });
    if (ok) {
      approved.add(normLabel(resolvedLabel));
      approved.add(normLabel(requestedText));
    }
    return ok;
  };

  try {
    for (let i = 0; i < total; i++) {
      throwIfAborted(opts.signal);
      if (Date.now() - started > maxMs) return fail(i, "timeout");
      const step = steps[i];
      opts.onProgress?.({ index: i, total, step });

      const r = await runStep(step, guard, opts.signal);
      log.push({ step, ok: r.ok, detail: r.detail, verified: r.verified });

      if (!r.ok) {
        const skippable = step.type === "tapText" && step.optional && r.detail === "not_found";
        if (!skippable) return fail(i, r.detail ?? "step_failed");
        continue;
      }
      // Let the UI finish reacting before the next step (adaptive, not a fixed sleep).
      if (step.type !== "wait" && step.type !== "waitForText") {
        await waitForSettle({ quietMs: 250, timeoutMs: step.type === "openApp" ? 4500 : 2500, signal: opts.signal });
      }
    }
    return { ok: true, completed: total, total, log };
  } catch (e) {
    if (e instanceof AbortError) return { ok: false, completed: log.length, total, failedStep: steps[log.length], reason: "cancelled", log };
    throw e;
  }
}

type Guard = (resolvedLabel: string, requestedText: string) => Promise<boolean>;

async function runStep(step: Step, guard: Guard, signal?: AbortSignal): Promise<{ ok: boolean; detail?: string; verified?: boolean }> {
  switch (step.type) {
    case "openApp": {
      const r = Agent.openApp(step.name);
      return { ok: r.ok, detail: r.reason };
    }
    case "global": {
      const r = await Agent.globalAction(step.name);
      return { ok: r.ok, detail: r.ok ? undefined : "global_failed" };
    }
    case "tapText":
    case "longPressText": {
      const r = await preciseTap(step.text, { guard, signal, longPress: step.type === "longPressText" });
      return { ok: r.ok, detail: r.reason, verified: r.verified };
    }
    case "scroll": {
      const r = await Agent.scroll(step.direction);
      return { ok: r.ok, detail: r.reason ?? undefined };
    }
    case "scrollUntilVisible": {
      const r = await scrollUntilVisible(step.text, { direction: step.direction, maxScrolls: step.maxScrolls, signal });
      return { ok: r.found, detail: r.reason };
    }
    case "typeText": {
      const r = await Agent.typeText(step.text, step.append === true);
      return { ok: r.ok, detail: r.reason ?? undefined };
    }
    case "waitForText": {
      const deadline = Date.now() + (step.timeoutMs ?? 4000);
      while (Date.now() < deadline) {
        if (findBest(step.text)) return { ok: true };
        await sleep(200, signal);
      }
      return { ok: false, detail: "timeout" };
    }
    case "wait": {
      await sleep(step.ms, signal);
      return { ok: true };
    }
    case "tapAt": {
      const { screenWidth: w, screenHeight: h } = Agent.getStatus();
      const r = await Agent.tap(step.x * w, step.y * h);
      return { ok: r.ok, detail: r.reason ?? undefined };
    }
    case "dragAt": {
      const { screenWidth: w, screenHeight: h } = Agent.getStatus();
      const r = await Agent.swipe(step.x1 * w, step.y1 * h, step.x2 * w, step.y2 * h, step.ms);
      return { ok: r.ok, detail: r.reason ?? undefined };
    }
    case "pinch": {
      const { screenWidth: w, screenHeight: h } = Agent.getStatus();
      const r = await Agent.pinch(step.x * w, step.y * h, step.from * w, step.to * w, step.ms);
      return { ok: r.ok, detail: r.reason ?? undefined };
    }
    case "pressEnter": {
      const r = Agent.pressEnter();
      return { ok: r.ok, detail: r.reason ?? undefined };
    }
    case "boardMove":
      return runBoardMove(step.from, step.to, step.orientation ?? "white", signal);
    case "workflow": {
      const r = await WORKFLOWS[step.name](step.query, { signal });
      return { ok: r.ok, detail: r.detail, verified: r.verified };
    }
  }
}

/** Tap-tap move on a detected square board; if the screen did not react, retry once as a drag. */
async function runBoardMove(
  from: string,
  to: string,
  orientation: "white" | "black",
  signal?: AbortSignal,
): Promise<{ ok: boolean; detail?: string; verified?: boolean }> {
  const { screenWidth } = Agent.getStatus();
  const board = detectSquareBoard(Agent.getScreenSnapshot({ includeNodes: true, includeOcr: false }).nodes, screenWidth);
  if (!board) return { ok: false, detail: "board_not_found" };
  const a = squareCenter(board, from, orientation);
  const b = squareCenter(board, to, orientation);

  const seq = Agent.getChangeSeq();
  const t1 = await Agent.tap(a.x, a.y);
  if (!t1.ok) return { ok: false, detail: t1.reason ?? "tap_failed" };
  await sleep(150, signal);
  const t2 = await Agent.tap(b.x, b.y);
  if (!t2.ok) return { ok: false, detail: t2.reason ?? "tap_failed" };
  if (await waitForChange(seq, 900, signal)) return { ok: true, verified: true };

  const seq2 = Agent.getChangeSeq();
  const d = await Agent.swipe(a.x, a.y, b.x, b.y, 350);
  if (!d.ok) return { ok: false, detail: d.reason ?? "drag_failed" };
  const moved = await waitForChange(seq2, 900, signal);
  return { ok: true, verified: moved };
}
