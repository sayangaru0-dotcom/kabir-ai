import { customFetch } from "@workspace/api-client-react";
import type { LearningEntry, ResponseLanguage } from "@/context/KabirContext";
import { parseSteps, PlanValidationError, type Step } from "./steps";

export type RecipeCall = { name: string; params: Record<string, string> };

export type CommandResponse = {
  kind: "chat" | "screen" | "recipe";
  /** What Kabir says: the answer for "chat", a short confirmation of what it will do for "screen". */
  speak: string;
  audioBase64: string;
  steps: Step[];
  /** Present when kind === "recipe": run one of the user's saved routines. */
  recipe?: RecipeCall;
};

export type CommandRequest = {
  transcript: string;
  responseLanguage: ResponseLanguage;
  uiLanguage: string;
  learned?: { title: string; summary: string; actions: string[] }[];
  /** The user's saved routines the planner may call by name. */
  recipes?: { name: string; description: string; params: string[] }[];
  /** OPT-IN only: visible labels from the current screen, used to re-plan after a failure. */
  screenLabels?: string[];
  failed?: { step: Step; reason: string };
};

export function deviceLocale(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().locale || "en";
  } catch {
    return "en";
  }
}

/** Sends only the few learned notes that overlap with what the user said (already noise-filtered, no recordings). */
export function pickRelevantLearning(transcript: string, entries: LearningEntry[], max = 3) {
  const tokens = new Set(
    transcript.toLowerCase().split(/[\s,.;:!?()"'।]+/).filter((t) => t.length >= 3),
  );
  if (tokens.size === 0) return [];
  return entries
    .map((e) => {
      const hay = `${e.title} ${e.summary}`.toLowerCase();
      let score = 0;
      tokens.forEach((t) => { if (hay.includes(t)) score += 1; });
      return { e, score };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, max)
    .map(({ e }) => ({ title: e.title, summary: e.summary, actions: e.actions.slice(0, 12) }));
}

const UNSAFE_PLAN: Record<ResponseLanguage, string> = {
  English: "Sorry, I couldn't plan that safely. Please try saying it differently.",
  Hindi: "माफ़ कीजिए, मैं इसे सुरक्षित रूप से नहीं कर पाया। कृपया दूसरे तरीके से कहिए।",
  Bengali: "দুঃখিত, আমি এটা নিরাপদে করতে পারিনি। অনুগ্রহ করে অন্যভাবে বলুন।",
};

type Raw = { kind?: unknown; speak?: unknown; audioBase64?: unknown; steps?: unknown; recipe?: unknown };

function parseRecipeCall(raw: unknown): RecipeCall | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  if (typeof r.name !== "string" || !r.name.trim() || r.name.length > 60) return null;
  const params: Record<string, string> = {};
  if (r.params && typeof r.params === "object") {
    for (const [k, v] of Object.entries(r.params as Record<string, unknown>).slice(0, 8)) {
      if (/^[a-z][a-z0-9_]{0,23}$/.test(k) && typeof v === "string") params[k] = v.slice(0, 200);
    }
  }
  return { name: r.name.trim(), params };
}

/** Client-side validation is the real trust boundary: the server's output is checked again here. */
export async function requestCommand(input: CommandRequest): Promise<CommandResponse> {
  const raw = await customFetch<Raw>("/api/kabir/command", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(input),
    responseType: "json",
  });
  const speak = typeof raw.speak === "string" ? raw.speak : "";
  const audioBase64 = typeof raw.audioBase64 === "string" ? raw.audioBase64 : "";
  if (raw.kind === "recipe") {
    const recipe = parseRecipeCall(raw.recipe);
    if (recipe) return { kind: "recipe", speak, audioBase64, steps: [], recipe };
    return { kind: "chat", speak: UNSAFE_PLAN[input.responseLanguage], audioBase64: "", steps: [] };
  }
  if (raw.kind !== "screen") return { kind: "chat", speak, audioBase64, steps: [] };
  try {
    return { kind: "screen", speak, audioBase64, steps: parseSteps(raw.steps) };
  } catch (e) {
    if (e instanceof PlanValidationError) {
      // Do not speak the model's "I'll do X" line for a plan we rejected; the audio would not match either.
      return { kind: "chat", speak: UNSAFE_PLAN[input.responseLanguage], audioBase64: "", steps: [] };
    }
    throw e;
  }
}
