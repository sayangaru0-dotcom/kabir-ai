/**
 * The ONLY actions a voice command may trigger. Anything the planner (an LLM) returns is untrusted input:
 * it is validated against this whitelist, and any invalid step rejects the WHOLE plan (never partially run).
 */

export type Direction = "up" | "down" | "left" | "right";
export type GlobalName = "back" | "home" | "recents" | "notifications" | "quickSettings";

export type Step =
  | { type: "openApp"; name: string }
  | { type: "global"; name: GlobalName }
  | { type: "tapText"; text: string; optional?: boolean }
  | { type: "longPressText"; text: string }
  | { type: "scroll"; direction: Direction }
  | { type: "scrollUntilVisible"; text: string; direction?: Direction; maxScrolls?: number }
  | { type: "typeText"; text: string; append?: boolean }
  | { type: "waitForText"; text: string; timeoutMs?: number }
  | { type: "wait"; ms: number }
  // — added for workflows / learned routines —
  /** Tap at a screen position given as 0-1 fractions (for unlabeled controls, canvases, games). */
  | { type: "tapAt"; x: number; y: number }
  | { type: "dragAt"; x1: number; y1: number; x2: number; y2: number; ms?: number }
  /** Two-finger pinch around (x,y). from/to = finger distance as a fraction of screen width (from > to = zoom out). */
  | { type: "pinch"; x: number; y: number; from: number; to: number; ms?: number }
  | { type: "pressEnter" }
  /** Move on a detected square 8x8 board (chess-style). Squares like "e2". */
  | { type: "boardMove"; from: string; to: string; orientation?: "white" | "black" }
  /** A built-in, hand-written adaptive workflow. */
  | { type: "workflow"; name: WorkflowName; query: string };

export const WORKFLOW_NAMES = ["youtube.searchPlay"] as const;
export type WorkflowName = (typeof WORKFLOW_NAMES)[number];

export const LIMITS = {
  maxSteps: 25,
  /** Saved routines (learned or demonstrated) may be longer than a one-off voice plan. */
  maxRecipeSteps: 40,
  maxQuery: 200,
  maxLabel: 80,
  maxTyped: 300,
  maxWaitMs: 8000,
  maxScrolls: 10,
} as const;

const DIRECTIONS: readonly string[] = ["up", "down", "left", "right"];
const GLOBALS: readonly string[] = ["back", "home", "recents", "notifications", "quickSettings"];

export class PlanValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PlanValidationError";
  }
}

function label(v: unknown, where: string): string {
  if (typeof v !== "string" || !v.trim() || v.trim().length > LIMITS.maxLabel) {
    throw new PlanValidationError(`${where}: expected a non-empty string up to ${LIMITS.maxLabel} chars`);
  }
  return v.trim();
}

function num(v: unknown, min: number, max: number, fallback: number): number {
  if (v === undefined || v === null) return fallback;
  if (typeof v !== "number" || !Number.isFinite(v)) throw new PlanValidationError("expected a number");
  return Math.min(max, Math.max(min, Math.round(v)));
}

function frac(v: unknown, where: string, min = 0, max = 1): number {
  if (typeof v !== "number" || !Number.isFinite(v) || v < min || v > max) {
    throw new PlanValidationError(`${where}: expected a number between ${min} and ${max}`);
  }
  return v;
}

const SQUARE = /^[a-h][1-8]$/;

function dir(v: unknown, where: string): Direction {
  if (typeof v !== "string" || !DIRECTIONS.includes(v)) throw new PlanValidationError(`${where}: bad direction`);
  return v as Direction;
}

function parseStep(item: unknown, i: number): Step {
  if (!item || typeof item !== "object") throw new PlanValidationError(`step ${i}: not an object`);
  const o = item as Record<string, unknown>;
  const w = `step ${i} (${String(o.type)})`;
  switch (o.type) {
    case "openApp":
      return { type: "openApp", name: label(o.name, w) };
    case "global":
      if (typeof o.name !== "string" || !GLOBALS.includes(o.name)) throw new PlanValidationError(`${w}: bad name`);
      return { type: "global", name: o.name as GlobalName };
    case "tapText":
      return { type: "tapText", text: label(o.text, w), optional: o.optional === true };
    case "longPressText":
      return { type: "longPressText", text: label(o.text, w) };
    case "scroll":
      return { type: "scroll", direction: dir(o.direction, w) };
    case "scrollUntilVisible":
      return {
        type: "scrollUntilVisible",
        text: label(o.text, w),
        direction: o.direction === undefined ? "down" : dir(o.direction, w),
        maxScrolls: num(o.maxScrolls, 1, LIMITS.maxScrolls, 6),
      };
    case "typeText": {
      if (typeof o.text !== "string" || !o.text.length || o.text.length > LIMITS.maxTyped) {
        throw new PlanValidationError(`${w}: text must be 1-${LIMITS.maxTyped} chars`);
      }
      return { type: "typeText", text: o.text, append: o.append === true };
    }
    case "waitForText":
      return { type: "waitForText", text: label(o.text, w), timeoutMs: num(o.timeoutMs, 500, LIMITS.maxWaitMs, 4000) };
    case "wait":
      return { type: "wait", ms: num(o.ms, 50, LIMITS.maxWaitMs, 500) };
    case "tapAt":
      return { type: "tapAt", x: frac(o.x, w), y: frac(o.y, w) };
    case "dragAt":
      return {
        type: "dragAt",
        x1: frac(o.x1, w), y1: frac(o.y1, w), x2: frac(o.x2, w), y2: frac(o.y2, w),
        ms: num(o.ms, 100, 3000, 400),
      };
    case "pinch":
      return {
        type: "pinch",
        x: frac(o.x, w), y: frac(o.y, w),
        from: frac(o.from, w, 0.05, 0.9), to: frac(o.to, w, 0.05, 0.9),
        ms: num(o.ms, 100, 3000, 400),
      };
    case "pressEnter":
      return { type: "pressEnter" };
    case "boardMove": {
      if (typeof o.from !== "string" || typeof o.to !== "string" || !SQUARE.test(o.from) || !SQUARE.test(o.to) || o.from === o.to) {
        throw new PlanValidationError(`${w}: from/to must be different squares like "e2"`);
      }
      if (o.orientation !== undefined && o.orientation !== "white" && o.orientation !== "black") {
        throw new PlanValidationError(`${w}: bad orientation`);
      }
      return { type: "boardMove", from: o.from, to: o.to, orientation: (o.orientation as "white" | "black" | undefined) ?? "white" };
    }
    case "workflow": {
      if (typeof o.name !== "string" || !(WORKFLOW_NAMES as readonly string[]).includes(o.name)) {
        throw new PlanValidationError(`${w}: unknown workflow`);
      }
      if (typeof o.query !== "string" || !o.query.trim() || o.query.length > LIMITS.maxQuery) {
        throw new PlanValidationError(`${w}: query must be 1-${LIMITS.maxQuery} chars`);
      }
      return { type: "workflow", name: o.name as WorkflowName, query: o.query.trim() };
    }
    default:
      throw new PlanValidationError(`${w}: unknown step type`);
  }
}

export function parseSteps(raw: unknown, maxSteps: number = LIMITS.maxSteps): Step[] {
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > maxSteps) {
    throw new PlanValidationError(`plan must contain 1-${maxSteps} steps`);
  }
  return raw.map(parseStep);
}

// ───────────── Sensitive actions: always need the user's explicit OK ─────────────
// Money, destructive, permission and account actions. Latin words use word boundaries; Hindi/Bengali
// have no \b support so they are matched as substrings.
const SENSITIVE_LATIN =
  /\b(pay(ment)?|purchase|buy( now)?|check ?out|place order|order now|subscribe|transfer|send money|donate|delete|erase|remove|uninstall|wipe|format|factory reset|reset|clear (all|data|storage)|deactivate|close account|sign ?out|log ?out|allow|grant|install|accept all)\b/i;
const SENSITIVE_OTHER =
  /(भुगतान|खरीद|हटा|डिलीट|मिटा|रीसेट|अनुमति|अनइंस्टॉल|পেমেন্ট|কিনুন|ক্রয়|মুছ|ডিলিট|রিসেট|অনুমতি|আনইনস্টল)/;

export function isSensitiveLabel(text: string): boolean {
  return SENSITIVE_LATIN.test(text) || SENSITIVE_OTHER.test(text);
}

export const normLabel = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");

/** Labels in a plan that need confirmation (tapped/long-pressed/scrolled-to texts). */
export function sensitiveLabelsIn(steps: Step[]): string[] {
  const out = new Set<string>();
  for (const s of steps) {
    if ((s.type === "tapText" || s.type === "longPressText") && isSensitiveLabel(s.text)) out.add(s.text);
  }
  return [...out];
}
