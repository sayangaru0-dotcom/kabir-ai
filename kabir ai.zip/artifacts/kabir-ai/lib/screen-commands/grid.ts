import type { UiNode } from "@/modules/kabir-screen-agent";

/**
 * Geometry for grid-like surfaces (chess boards, keypads, calendars).
 * Pure functions: no native calls, easy to test.
 */

export type Board = { left: number; top: number; size: number };

/**
 * Finds the 8x8 board as the biggest near-square visible node that spans most of the screen width.
 * Works for apps whose board is a native view with accessibility bounds. Returns null for pure canvas/WebView boards.
 */
export function detectSquareBoard(nodes: UiNode[], screenW: number): Board | null {
  let best: Board | null = null;
  for (const n of nodes) {
    const w = n.bounds.width;
    const h = n.bounds.height;
    if (w <= 0 || h <= 0) continue;
    const squareish = Math.abs(w - h) / Math.max(w, h) <= 0.03;
    if (!squareish || w < screenW * 0.8 || w > screenW + 2) continue;
    if (!best || w > best.size) best = { left: n.bounds.left, top: n.bounds.top, size: w };
  }
  return best;
}

/** Pixel centre of a square such as "e2". orientation = which colour is at the bottom of the screen. */
export function squareCenter(board: Board, square: string, orientation: "white" | "black" = "white") {
  const file = square.charCodeAt(0) - 97; // a..h -> 0..7
  const rank = parseInt(square[1], 10) - 1; // 1..8 -> 0..7
  const cell = board.size / 8;
  const col = orientation === "white" ? file : 7 - file;
  const row = orientation === "white" ? 7 - rank : rank;
  return { x: board.left + (col + 0.5) * cell, y: board.top + (row + 0.5) * cell };
}
