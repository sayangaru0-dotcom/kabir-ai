import { recordAppError } from "@/lib/error-monitor";

/** Reasons that are the user's choice, not a fault: never logged as diagnostics. */
const NOT_A_FAULT = new Set(["cancelled", "declined"]);

/**
 * Sends a screen-automation problem to Kabir's diagnostic history (Settings > diagnostics), where the rules in
 * error-monitor.ts turn it into plain-language fix steps. The 10 s duplicate window there prevents spam.
 */
export function reportAutomationIssue(source: string, message: string, reason?: string | null) {
  if (reason && NOT_A_FAULT.has(reason)) return;
  void recordAppError(new Error(reason ? `${message} [${reason}]` : message), source);
}
