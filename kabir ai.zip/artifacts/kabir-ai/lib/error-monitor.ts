import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";

const STORAGE_KEY = "@kabir/diagnostics/v1";
const MAX_DIAGNOSTICS = 40;
const DUPLICATE_WINDOW_MS = 10_000;

export type DiagnosticRecord = {
  id: string;
  source: string;
  title: string;
  message: string;
  details: string;
  createdAt: string;
  steps: string[];
  helpUrl: string | null;
  requiresDeviceSettings: boolean;
};

type ErrorUtilsLike = {
  getGlobalHandler?: () => ((error: Error, isFatal?: boolean) => void) | undefined;
  setGlobalHandler?: (handler: (error: Error, isFatal?: boolean) => void) => void;
};

let records: DiagnosticRecord[] | null = null;
let loading: Promise<DiagnosticRecord[]> | null = null;
let monitoringInstalled = false;
const listeners = new Set<(items: DiagnosticRecord[]) => void>();

export function sanitizeDiagnosticText(value: string) {
  return value
    .replace(/sk-[A-Za-z0-9_-]{12,}/g, "[redacted key]")
    .replace(/Bearer\s+\S+/gi, "Bearer [redacted]")
    .replace(/(OPENAI_API_KEY\s*[:=]\s*)\S+/gi, "$1[redacted]");
}

function getErrorMessage(error: unknown) {
  if (error instanceof Error) return sanitizeDiagnosticText(error.message || error.name);
  if (typeof error === "string") return sanitizeDiagnosticText(error);
  try {
    return sanitizeDiagnosticText(JSON.stringify(error) || "Unknown error");
  } catch {
    return "Unknown error";
  }
}

function getErrorDetails(error: unknown, componentStack?: string) {
  const stack = error instanceof Error ? error.stack : "";
  const details = [getErrorMessage(error), stack, componentStack]
    .filter((value): value is string => Boolean(value))
    .join("\n\n");
  return sanitizeDiagnosticText(details).slice(0, 6_000);
}

function getStatusCode(error: unknown) {
  if (!error || typeof error !== "object") return null;
  const candidate = error as {
    status?: unknown;
    statusCode?: unknown;
    response?: { status?: unknown };
  };
  const raw = candidate.status ?? candidate.statusCode ?? candidate.response?.status;
  const status = typeof raw === "number" ? raw : Number(raw);
  return Number.isInteger(status) && status >= 100 && status <= 599 ? status : null;
}

function diagnose(error: unknown, source: string) {
  const message = getErrorMessage(error);
  const lower = `${source} ${message}`.toLowerCase();
  const status = getStatusCode(error);

  // ── Screen control / automation (added with the screen agent) ──
  if (/native module is unavailable|kabirscreenagent/.test(lower)) {
    return {
      title: "Screen control isn't in this build",
      steps: [
        "Screen control needs the installed APK / development build of Kabir; it can't run in Expo Go or the web preview.",
        "Rebuild and reinstall the Android app, then open Kabir again.",
      ],
      helpUrl: null,
      requiresDeviceSettings: false,
    };
  }

  if (/accessibility|a11y/.test(lower)) {
    return {
      title: "Screen access is off",
      steps: [
        "Open Android Settings > Accessibility > Installed apps (or Downloaded apps) > Kabir screen assistant and turn it on.",
        "If the switch is greyed out (apps installed from an APK file): Settings > Apps > Kabir AI > three-dot menu > Allow restricted settings, then try again.",
        "Some phones switch accessibility services off to save battery. Exempt Kabir from battery optimization if it keeps turning off.",
      ],
      helpUrl: null,
      requiresDeviceSettings: true,
    };
  }

  if (/notification permission|screen capture|mediaprojection|capture failed|recording your steps|reading your screen/.test(lower)) {
    return {
      title: "Screen reading needs permission",
      steps: [
        "Allow notifications for Kabir. The on-screen indicator that shows when Kabir is reading or recording is required.",
        "When Android asks to start capturing the screen, choose Start now. Android asks every time, by design.",
        "Return to Kabir and try again.",
      ],
      helpUrl: null,
      requiresDeviceSettings: true,
    };
  }

  if (/blocked_app|blocked list/.test(lower)) {
    return {
      title: "That app is on your blocked list",
      steps: [
        "Kabir will not read or touch apps on the blocked list (for example banking apps).",
        "Remove the app from the blocked list if you want Kabir to use it.",
      ],
      helpUrl: null,
      requiresDeviceSettings: false,
    };
  }

  if (/needs to be repaired|stopped working twice/.test(lower)) {
    return {
      title: "A routine needs repair",
      steps: [
        "The app's screens probably changed since you taught this routine.",
        "Open Settings > Routines and teach it again by showing it, or delete it and learn it again.",
      ],
      helpUrl: null,
      requiresDeviceSettings: false,
    };
  }

  if (/not_found|search_not_found|no_results|no_input_field|board_not_found|end_of_content|app_not_found|couldn't find|could not find/.test(lower)) {
    return {
      title: "Kabir couldn't find that on the screen",
      steps: [
        "Make sure the app is installed, logged in and showing its normal main screen, then try again.",
        "Kabir matches the names it sees on screen. If your phone language changed, or the app updated, re-teach the routine.",
        "Open Settings > Routines to see the steps and the last problem for each routine.",
      ],
      helpUrl: null,
      requiresDeviceSettings: false,
    };
  }

  if (/microphone|recording permission|permission denied/.test(lower)) {
    return {
      title: "Microphone permission",
      steps: [
        "Allow microphone access for Kabir in your device or browser settings.",
        "Return to Kabir and try recording again.",
      ],
      helpUrl: null,
      requiresDeviceSettings: true,
    };
  }

  if (status === 401 || status === 403 || /invalid api key|unauthorized|authentication/.test(lower)) {
    return {
      title: "AI service credentials",
      steps: [
        "Check that OPENAI_API_KEY is configured in Replit Secrets on the server.",
        "Restart the API Server after changing a secret, then retry.",
        "Never paste the key into the app or an error report.",
      ],
      helpUrl: "https://platform.openai.com/docs/guides/error-codes",
      requiresDeviceSettings: false,
    };
  }

  if (status === 429 || /\b429\b|rate limit|quota|billing limit/.test(lower)) {
    return {
      title: "AI usage limit",
      steps: [
        "Check the API account's usage limits and billing status.",
        "Wait for a rate limit to reset, then retry once.",
      ],
      helpUrl: "https://platform.openai.com/settings/organization/limits",
      requiresDeviceSettings: false,
    };
  }

  if (/network|fetch|connection|timed? out|offline|econn/.test(lower)) {
    return {
      title: "Connection issue",
      steps: [
        "Check that this device has a working internet connection.",
        "If you are testing locally, confirm the API Server workflow is running.",
        "Retry after the connection is restored.",
      ],
      helpUrl: "https://status.openai.com/",
      requiresDeviceSettings: false,
    };
  }

  if (
    (status !== null && status >= 500) ||
    /\b5\d\d\b|service unavailable|internal server/.test(lower)
  ) {
    return {
      title: "Service temporarily unavailable",
      steps: [
        "Wait briefly and retry; the request may have reached the service already.",
        "If the issue continues, check the service status and the API Server logs.",
      ],
      helpUrl: "https://status.openai.com/",
      requiresDeviceSettings: false,
    };
  }

  return {
    title: "Kabir encountered an error",
    steps: [
      "Review the technical details below and try the action again once.",
      "If it repeats, restart Kabir and share this diagnostic entry with the developer.",
    ],
    helpUrl: "https://platform.openai.com/docs/guides/error-codes",
    requiresDeviceSettings: false,
  };
}

function isDiagnosticRecord(value: unknown): value is DiagnosticRecord {
  if (!value || typeof value !== "object") return false;
  const record = value as Partial<DiagnosticRecord>;
  const safeHelpUrl =
    record.helpUrl === null ||
    (typeof record.helpUrl === "string" &&
      /^https:\/\/(platform\.openai\.com|status\.openai\.com)\//.test(record.helpUrl));
  return (
    typeof record.id === "string" &&
    typeof record.source === "string" &&
    typeof record.title === "string" &&
    typeof record.message === "string" &&
    typeof record.details === "string" &&
    typeof record.createdAt === "string" &&
    Array.isArray(record.steps) &&
    record.steps.every((step) => typeof step === "string") &&
    safeHelpUrl &&
    typeof record.requiresDeviceSettings === "boolean"
  );
}

function notifyListeners() {
  if (!records) return;
  for (const listener of listeners) listener(records);
}

async function loadRecords() {
  if (records) return records;
  if (!loading) {
    loading = AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (!stored) return [];
        try {
          const parsed: unknown = JSON.parse(stored);
          return Array.isArray(parsed)
            ? parsed.filter(isDiagnosticRecord).slice(0, MAX_DIAGNOSTICS)
            : [];
        } catch {
          void AsyncStorage.removeItem(STORAGE_KEY).catch(() => undefined);
          return [];
        }
      })
      .catch(() => [])
      .then((loadedRecords) => {
        records = loadedRecords;
        return loadedRecords;
      });
  }
  return loading;
}

async function persistRecords() {
  if (!records) return;
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(records)).catch(() => undefined);
}

export async function recordAppError(
  error: unknown,
  source: string,
  componentStack?: string,
) {
  const existing = await loadRecords();
  const message = getErrorMessage(error);
  const now = Date.now();
  const duplicate = existing.find(
    (item) =>
      item.source === source &&
      item.message === message &&
      now - Date.parse(item.createdAt) < DUPLICATE_WINDOW_MS,
  );
  if (duplicate) return duplicate;

  const diagnosis = diagnose(error, source);
  const record: DiagnosticRecord = {
    id: `${now}-${Math.random().toString(36).slice(2, 8)}`,
    source: sanitizeDiagnosticText(source).slice(0, 100),
    title: diagnosis.title,
    message: message.slice(0, 600),
    details: getErrorDetails(error, componentStack),
    createdAt: new Date(now).toISOString(),
    steps: diagnosis.steps,
    helpUrl: diagnosis.helpUrl,
    requiresDeviceSettings: diagnosis.requiresDeviceSettings,
  };

  records = [record, ...existing].slice(0, MAX_DIAGNOSTICS);
  notifyListeners();
  await persistRecords();
  return record;
}

export async function clearDiagnosticHistory() {
  const previous = await loadRecords();
  records = [];
  notifyListeners();
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
    return true;
  } catch {
    records = previous;
    notifyListeners();
    return false;
  }
}

export function subscribeToDiagnostics(listener: (items: DiagnosticRecord[]) => void) {
  let active = true;
  listeners.add(listener);
  void loadRecords().then((items) => {
    if (active) listener(items);
  });
  return () => {
    active = false;
    listeners.delete(listener);
  };
}

export function useDiagnosticHistory() {
  const [history, setHistory] = useState<DiagnosticRecord[]>(records ?? []);
  useEffect(() => subscribeToDiagnostics(setHistory), []);
  return history;
}

export function installGlobalErrorMonitoring() {
  if (monitoringInstalled) return () => undefined;
  monitoringInstalled = true;

  const globalWithErrorUtils = globalThis as typeof globalThis & {
    ErrorUtils?: ErrorUtilsLike;
  };
  const errorUtils = globalWithErrorUtils.ErrorUtils;
  const canWrapGlobalHandler = Boolean(
    errorUtils?.getGlobalHandler && errorUtils.setGlobalHandler,
  );
  const previousHandler = canWrapGlobalHandler ? errorUtils?.getGlobalHandler?.() : undefined;
  const handler = (error: Error, isFatal?: boolean) => {
    void recordAppError(error, isFatal ? "Fatal JavaScript exception" : "JavaScript exception");
    previousHandler?.(error, isFatal);
  };

  if (previousHandler && errorUtils?.setGlobalHandler) {
    errorUtils.setGlobalHandler(handler);
  }

  const handleUnhandledRejection = (event: Event) => {
    const rejection = event as Event & { reason?: unknown };
    void recordAppError(rejection.reason, "Unhandled promise rejection");
  };
  const handleWindowError = (event: Event) => {
    const browserError = event as ErrorEvent;
    void recordAppError(
      browserError.error ?? new Error(browserError.message || "Uncaught browser error."),
      "Uncaught browser exception",
    );
  };
  if (typeof window !== "undefined") {
    window.addEventListener("unhandledrejection", handleUnhandledRejection);
    window.addEventListener("error", handleWindowError);
  }

  return () => {
    if (previousHandler && errorUtils?.setGlobalHandler) errorUtils.setGlobalHandler(previousHandler);
    if (typeof window !== "undefined") {
      window.removeEventListener("unhandledrejection", handleUnhandledRejection);
      window.removeEventListener("error", handleWindowError);
    }
    monitoringInstalled = false;
  };
}
