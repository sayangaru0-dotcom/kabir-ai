import AsyncStorage from "@react-native-async-storage/async-storage";
import { LIMITS, parseSteps } from "@/lib/screen-commands/steps";
import { assertRecipeSound, type Recipe } from "./recipe";

const KEY = "@kabir/recipes/v1";
const MAX_RECIPES = 50;

/** Reads recipes, dropping anything malformed (storage is also treated as untrusted input). */
export async function listRecipes(): Promise<Recipe[]> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const out: Recipe[] = [];
    for (const r of parsed as Recipe[]) {
      try {
        const steps = parseSteps(r.steps, LIMITS.maxRecipeSteps);
        assertRecipeSound(steps, r.params ?? []);
        out.push({ ...r, steps, params: r.params ?? [], warnings: r.warnings ?? [] });
      } catch {
        /* skip invalid recipe */
      }
    }
    return out;
  } catch {
    return [];
  }
}

async function write(all: Recipe[]) {
  await AsyncStorage.setItem(KEY, JSON.stringify(all.slice(0, MAX_RECIPES)));
}

export async function saveRecipe(recipe: Recipe): Promise<void> {
  const all = await listRecipes();
  const i = all.findIndex((r) => r.id === recipe.id);
  const next = { ...recipe, updatedAt: new Date().toISOString() };
  if (i >= 0) all[i] = next;
  else all.unshift(next);
  await write(all);
}

export async function deleteRecipe(id: string): Promise<void> {
  await write((await listRecipes()).filter((r) => r.id !== id));
}

export async function findRecipeByName(name: string): Promise<Recipe | undefined> {
  const n = name.trim().toLowerCase();
  return (await listRecipes()).find((r) => r.name.trim().toLowerCase() === n);
}
