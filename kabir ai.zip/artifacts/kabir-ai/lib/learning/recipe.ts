import { LIMITS, parseSteps, PlanValidationError, type Step, type WorkflowName } from "@/lib/screen-commands/steps";

const WORKFLOW_LABEL: Record<WorkflowName, string> = {
  "youtube.searchPlay": "Search YouTube and play",
};

/**
 * A "recipe" is a learned routine: a validated list of whitelisted steps plus named parameters.
 * Steps may contain {{param}} placeholders inside their text fields (text / name / query).
 */
export type RecipeParam = { name: string; example: string };

export type RecipeStatus =
  | "draft"         // never run successfully: needs the user's approval + a supervised first run
  | "verified"      // completed end to end at least once
  | "needs_repair"; // failed twice in a row: UI probably changed

export type Recipe = {
  id: string;
  name: string;
  description: string;
  /** App the routine is for (display only). */
  app: string;
  source: "demonstration" | "tutorial";
  params: RecipeParam[];
  steps: Step[];
  status: RecipeStatus;
  revision: number;
  createdAt: string;
  updatedAt: string;
  /** Learner's own caveats, e.g. "labels guessed from a transcript". Shown before the first run. */
  warnings: string[];
  stats: { runs: number; successes: number; consecutiveFailures: number; lastError?: string };
};

const PLACEHOLDER = /\{\{([a-z][a-z0-9_]{0,23})\}\}/g;
const TEXT_FIELDS = ["text", "name", "query"] as const;

export function newRecipeId() {
  return `r_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

/** Every {{placeholder}} used by the steps. */
export function placeholdersIn(steps: Step[]): string[] {
  const out = new Set<string>();
  for (const s of steps) {
    for (const f of TEXT_FIELDS) {
      const v = (s as Record<string, unknown>)[f];
      if (typeof v === "string") for (const m of v.matchAll(PLACEHOLDER)) out.add(m[1]);
    }
  }
  return [...out];
}

/**
 * Fills placeholders (missing values fall back to the parameter's example) and re-validates the result,
 * because parameter values come from the user's speech and are untrusted.
 */
export function applyParams(recipe: Pick<Recipe, "steps" | "params">, values: Record<string, string> = {}): Step[] {
  const resolved: Record<string, string> = {};
  for (const p of recipe.params) {
    const v = values[p.name];
    resolved[p.name] = typeof v === "string" && v.trim() ? v.trim().replace(/\{\{|\}\}/g, "") : p.example;
  }
  const filled = recipe.steps.map((s) => {
    const copy: Record<string, unknown> = { ...s };
    for (const f of TEXT_FIELDS) {
      const v = copy[f];
      if (typeof v === "string") copy[f] = v.replace(PLACEHOLDER, (_, name: string) => resolved[name] ?? "");
    }
    return copy;
  });
  return parseSteps(filled, LIMITS.maxRecipeSteps);
}

/** Throws PlanValidationError if a recipe coming from storage/server is malformed or uses undeclared placeholders. */
export function assertRecipeSound(steps: Step[], params: RecipeParam[]) {
  const declared = new Set(params.map((p) => p.name));
  for (const used of placeholdersIn(steps)) {
    if (!declared.has(used)) throw new PlanValidationError(`placeholder {{${used}}} is not declared in params`);
  }
}

/** Plain-language list of what a routine will do, for the approval dialog / details view. */
export function describeStepPlain(s: Step): string {
  switch (s.type) {
    case "openApp": return `Open ${s.name}`;
    case "global": return `Press ${s.name}`;
    case "tapText": return `Tap "${s.text}"${s.optional ? " (if present)" : ""}`;
    case "longPressText": return `Long-press "${s.text}"`;
    case "scroll": return `Scroll ${s.direction}`;
    case "scrollUntilVisible": return `Scroll ${s.direction ?? "down"} until "${s.text}" appears`;
    case "typeText": return `Type "${s.text}"`;
    case "waitForText": return `Wait for "${s.text}"`;
    case "wait": return `Wait ${s.ms} ms`;
    case "tapAt": return `Tap the screen at ${Math.round(s.x * 100)}% / ${Math.round(s.y * 100)}%`;
    case "dragAt": return "Drag across the screen";
    case "pinch": return s.to < s.from ? "Pinch in" : "Pinch out";
    case "pressEnter": return "Press the keyboard's Enter/Search key";
    case "boardMove": return `Move a piece ${s.from} → ${s.to}`;
    case "workflow": return `${WORKFLOW_LABEL[s.name]}: "${s.query}"`;
  }
}

export function describeRecipe(r: Recipe): string {
  const lines = r.steps.slice(0, 14).map((s, i) => `${i + 1}. ${describeStepPlain(s)}`);
  if (r.steps.length > 14) lines.push(`…and ${r.steps.length - 14} more steps`);
  const warn = r.warnings.length ? `\n\nHeads-up:\n- ${r.warnings.slice(0, 3).join("\n- ")}` : "";
  return `${lines.join("\n")}${warn}`;
}
