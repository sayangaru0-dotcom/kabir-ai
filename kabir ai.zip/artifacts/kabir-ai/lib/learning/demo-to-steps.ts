import type { DemoEvent } from "@/modules/kabir-screen-agent";
import { LIMITS, type Step } from "@/lib/screen-commands/steps";
import { newRecipeId, type Recipe, type RecipeParam } from "./recipe";

const round3 = (n: number) => Math.round(n * 1000) / 1000;
const SCROLL_BURST_MS = 700;

/**
 * Turns what the user did (recorded natively in teach mode) into a replayable routine.
 *  - first event in another app            -> openApp
 *  - click on a labelled control           -> tapText(label)     (labelled taps survive layout changes)
 *  - click without a label                 -> tapAt(x%, y%)      (position fallback, flagged in warnings)
 *  - run of typing in one field            -> typeText("{{textN}}") with the typed text as the parameter's default
 *  - burst of same-direction scroll events -> one scroll
 *  - password typing                       -> skipped, with a warning (Kabir never replays passwords)
 */
export function demoToRecipe(
  events: DemoEvent[],
  o: { name: string; description?: string; ownPackage?: string },
): { recipe: Recipe; warnings: string[] } {
  const steps: Step[] = [];
  const params: RecipeParam[] = [];
  const warnings: string[] = [];
  let lastPackage = "";
  let lastScroll: { dir: string; at: number } | null = null;
  let pendingText: { viewKey: string; text: string; pkg: string } | null = null;
  let positionTaps = 0;

  const flushText = () => {
    if (!pendingText) return;
    const name = `text${params.length + 1}`;
    params.push({ name, example: pendingText.text });
    steps.push({ type: "typeText", text: `{{${name}}}` });
    pendingText = null;
  };

  for (const e of events) {
    if (o.ownPackage && e.package === o.ownPackage) continue;

    if (e.kind === "text") {
      if (e.secret) {
        flushText();
        warnings.push("A password field was skipped. Kabir never replays passwords; you'll need to enter it yourself.");
        continue;
      }
      const key = `${e.package}:${e.viewId}:${e.className}`;
      if (pendingText && pendingText.viewKey === key) pendingText.text = e.text; // keystrokes of one field: keep the latest
      else { flushText(); pendingText = { viewKey: key, text: e.text, pkg: e.package }; }
      if (!e.text) pendingText = null;
      continue;
    }

    flushText();

    if (e.kind === "window") {
      if (e.package !== lastPackage) {
        steps.push({ type: "openApp", name: e.appLabel || e.package });
        lastPackage = e.package;
      }
      lastScroll = null;
      continue;
    }

    if (e.kind === "click") {
      lastScroll = null;
      if (e.label) steps.push({ type: "tapText", text: e.label });
      else if (e.xFrac >= 0 && e.yFrac >= 0) {
        steps.push({ type: "tapAt", x: round3(e.xFrac), y: round3(e.yFrac) });
        positionTaps++;
      }
      continue;
    }

    if (e.kind === "longClick") {
      lastScroll = null;
      if (e.label) steps.push({ type: "longPressText", text: e.label });
      else warnings.push("A long-press on an unlabeled control was skipped (it can't be replayed reliably).");
      continue;
    }

    if (e.kind === "scroll" && e.dir) {
      // Many scroll events fire during one swipe/fling: merge bursts in the same direction.
      if (lastScroll && lastScroll.dir === e.dir && e.at - lastScroll.at <= SCROLL_BURST_MS) {
        lastScroll.at = e.at;
      } else {
        steps.push({ type: "scroll", direction: e.dir });
        lastScroll = { dir: e.dir, at: e.at };
      }
    }
  }
  flushText();

  if (positionTaps > 0) {
    warnings.push(`${positionTaps} tap(s) were recorded by screen position because the control had no name; they break if the layout changes.`);
  }
  if (steps.length > LIMITS.maxRecipeSteps) {
    warnings.push(`The routine was longer than ${LIMITS.maxRecipeSteps} steps and was cut off.`);
    steps.length = LIMITS.maxRecipeSteps;
  }

  const now = new Date().toISOString();
  const recipe: Recipe = {
    id: newRecipeId(),
    name: o.name.trim().slice(0, 60) || "My routine",
    description: (o.description ?? "").trim().slice(0, 300) || "Learned from your demonstration.",
    app: steps.find((s): s is Extract<Step, { type: "openApp" }> => s.type === "openApp")?.name ?? "",
    source: "demonstration",
    params,
    steps,
    status: "draft",
    revision: 1,
    createdAt: now,
    updatedAt: now,
    warnings: [...new Set(warnings)],
    stats: { runs: 0, successes: 0, consecutiveFailures: 0 },
  };
  return { recipe, warnings: recipe.warnings };
}
