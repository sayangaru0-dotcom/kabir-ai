import { customFetch } from "@workspace/api-client-react";
import type { ResponseLanguage } from "@/context/KabirContext";
import { LIMITS, parseSteps, type Step } from "@/lib/screen-commands/steps";
import { deviceLocale } from "@/lib/screen-commands/planner";
import { assertRecipeSound, newRecipeId, type Recipe, type RecipeParam } from "./recipe";

type LearnRaw = {
  name?: unknown; description?: unknown; app?: unknown; params?: unknown;
  steps?: unknown; assumptions?: unknown; warnings?: unknown; confidence?: unknown;
};

const strs = (v: unknown, max: number, n: number): string[] =>
  Array.isArray(v) ? v.filter((x): x is string => typeof x === "string").slice(0, n).map((x) => x.slice(0, max)) : [];

/**
 * Turns tutorial text (a transcript, pasted notes, a how-to article) into a DRAFT routine.
 * The result is never trusted: steps are re-validated against the whitelist, placeholders must be declared,
 * and the recipe is stored as "draft" so the user must approve it and watch a first run.
 *
 * Source material is text. Kabir does not download or watch videos; paste the transcript/notes, or teach by demonstration.
 */
export async function learnFromText(input: {
  text: string;
  appName?: string;
  goal?: string;
  name?: string;
  responseLanguage: ResponseLanguage;
}): Promise<Recipe> {
  const raw = await customFetch<LearnRaw>("/api/kabir/learn-workflow", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ mode: "learn", ...input, uiLanguage: deviceLocale() }),
    responseType: "json",
  });

  const steps = parseSteps(raw.steps, LIMITS.maxRecipeSteps);
  const params: RecipeParam[] = Array.isArray(raw.params)
    ? (raw.params as Record<string, unknown>[])
        .filter((p) => p && typeof p.name === "string" && /^[a-z][a-z0-9_]{0,23}$/.test(p.name) && typeof p.example === "string")
        .slice(0, 8)
        .map((p) => ({ name: p.name as string, example: (p.example as string).slice(0, 200) }))
    : [];
  assertRecipeSound(steps, params);

  const confidence = typeof raw.confidence === "number" ? Math.min(1, Math.max(0, raw.confidence)) : 0.5;
  const warnings = [
    ...strs(raw.warnings, 200, 6),
    ...strs(raw.assumptions, 200, 4).map((a) => `Assumed: ${a}`),
    ...(confidence < 0.7 ? ["Kabir had to guess some button names from the text, so the first run may need fixing."] : []),
  ];

  const now = new Date().toISOString();
  return {
    id: newRecipeId(),
    name: (input.name?.trim() || (typeof raw.name === "string" ? raw.name : "") || "Learned routine").slice(0, 60),
    description: (typeof raw.description === "string" ? raw.description : "").slice(0, 300),
    app: (typeof raw.app === "string" ? raw.app : input.appName ?? "").slice(0, 60),
    source: "tutorial",
    params,
    steps,
    status: "draft",
    revision: 1,
    createdAt: now,
    updatedAt: now,
    warnings,
    stats: { runs: 0, successes: 0, consecutiveFailures: 0 },
  };
}

/**
 * Self-repair: when a verified routine breaks (the app's UI changed), ask for replacement steps from the failing
 * step onward, given the labels currently visible. Returns a new DRAFT revision; the caller shows it to the user.
 * Only call this when the user has opted in to sending visible labels.
 */
export async function proposeRepair(
  recipe: Recipe,
  failedIndex: number,
  reason: string,
  screenLabels: string[],
  responseLanguage: ResponseLanguage,
): Promise<{ recipe: Recipe; note: string } | null> {
  const raw = await customFetch<{ steps?: unknown; note?: unknown }>("/api/kabir/learn-workflow", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      mode: "repair",
      responseLanguage,
      uiLanguage: deviceLocale(),
      repair: { steps: recipe.steps, params: recipe.params, failedIndex, reason, screenLabels },
    }),
    responseType: "json",
  });
  let replacement: Step[];
  try {
    replacement = parseSteps(raw.steps, LIMITS.maxRecipeSteps);
  } catch {
    return null;
  }
  const steps = [...recipe.steps.slice(0, Math.max(0, failedIndex)), ...replacement].slice(0, LIMITS.maxRecipeSteps);
  try {
    assertRecipeSound(steps, recipe.params);
  } catch {
    return null;
  }
  return {
    recipe: {
      ...recipe,
      steps,
      status: "draft", // changed steps must be approved and re-verified
      revision: recipe.revision + 1,
      stats: { ...recipe.stats, consecutiveFailures: 0 },
      updatedAt: new Date().toISOString(),
    },
    note: typeof raw.note === "string" ? raw.note.slice(0, 200) : "",
  };
}
