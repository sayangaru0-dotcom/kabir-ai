import { runSteps, type ConfirmRequest, type RunOptions, type RunReport } from "@/lib/screen-commands/executor";
import { approvePlan, confirmDialog } from "@/lib/screen-commands/approval";
import { applyParams, describeRecipe, type Recipe } from "./recipe";
import { saveRecipe } from "./recipe-store";

export type RecipeRunDeps = {
  signal?: AbortSignal;
  confirm?: (r: ConfirmRequest) => Promise<boolean>;
  onProgress?: RunOptions["onProgress"];
};

export type RecipeRunResult = { report: RunReport; recipe: Recipe; problem?: string };

const NON_FAULT = new Set(["cancelled", "declined", "accessibility_off", "blocked_app"]);

/** Pure bookkeeping, exported for tests: how one run changes a recipe's health. */
export function updateStatsAfterRun(recipe: Recipe, report: RunReport): Recipe {
  const stats = { ...recipe.stats, runs: recipe.stats.runs + 1 };
  let status = recipe.status;
  if (report.ok) {
    stats.successes += 1;
    stats.consecutiveFailures = 0;
    stats.lastError = undefined;
    status = "verified";
  } else if (!NON_FAULT.has(report.reason ?? "")) {
    // User cancellations / refusals / missing permissions say nothing about the recipe's health.
    stats.consecutiveFailures += 1;
    stats.lastError = `${report.reason ?? "failed"} at step ${(report.completed ?? 0) + 1}`;
    if (stats.consecutiveFailures >= 2) status = "needs_repair";
  } else {
    stats.runs = recipe.stats.runs; // not counted
  }
  return { ...recipe, stats, status };
}

/**
 * Runs a recipe with the same safety rules as voice commands, plus the self-learning loop:
 *  - draft recipes are shown to the user (plain-language step list) and need approval before their first run
 *  - sensitive labels need confirmation (upfront + at the moment of the tap)
 *  - the outcome updates the recipe: draft -> verified on success; 2 failures in a row -> needs_repair
 */
export async function runRecipe(
  recipe: Recipe,
  values: Record<string, string>,
  deps: RecipeRunDeps = {},
): Promise<RecipeRunResult> {
  const confirm = deps.confirm ?? confirmDialog;
  const refused = (reason: string, problem: string): RecipeRunResult => ({
    report: { ok: false, completed: 0, total: recipe.steps.length, reason, log: [] },
    recipe,
    problem,
  });

  if (recipe.status === "draft") {
    const ok = await confirm({
      title: `Run "${recipe.name}" for the first time?`,
      message: `Kabir learned this routine${recipe.source === "tutorial" ? " from a tutorial" : " from you"} and hasn't run it yet:\n\n${describeRecipe(recipe)}`,
    });
    if (!ok) return refused("declined", "Okay, I didn't run it.");
  }

  let steps;
  try {
    steps = applyParams(recipe, values);
  } catch {
    return refused("invalid_params", "Those details don't fit this routine.");
  }

  const approved = await approvePlan(steps, confirm);
  if (!approved) return refused("declined", "Okay, I didn't do it.");

  const report = await runSteps(steps, { signal: deps.signal, confirm, approved, onProgress: deps.onProgress });
  const updated = updateStatsAfterRun(recipe, report);
  if (updated !== recipe) await saveRecipe(updated);

  let problem: string | undefined;
  if (!report.ok) {
    problem =
      report.reason === "cancelled" ? "Stopped."
      : report.reason === "declined" ? "Okay, I didn't do it."
      : updated.status === "needs_repair" ? `"${recipe.name}" stopped working twice in a row. It needs to be repaired or taught again.`
      : `"${recipe.name}" stopped at step ${report.completed + 1} (${report.reason ?? "failed"}).`;
  }
  return { report, recipe: updated, problem };
}
