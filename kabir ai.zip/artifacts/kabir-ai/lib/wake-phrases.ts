import type { WakePhrase } from "@/context/KabirContext";

function normalizePhrase(value: string) {
  return value
    .normalize("NFC")
    .toLocaleLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function matchWakePhrase(transcript: string, phrases: WakePhrase[]) {
  const normalizedTranscript = normalizePhrase(transcript);
  if (!normalizedTranscript) return null;

  return (
    phrases.find((phrase) => {
      const normalizedTrigger = normalizePhrase(phrase.text);
      return normalizedTrigger.length > 0 && normalizedTranscript.includes(normalizedTrigger);
    }) ?? null
  );
}
