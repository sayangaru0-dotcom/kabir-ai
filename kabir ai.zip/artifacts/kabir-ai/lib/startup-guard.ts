/**
 * Last line of defence for startup. It is imported FIRST (from index.js), before anything else in the app can fail, and it depends
 * only on react-native.
 *
 * Why it exists: in a release build a fatal JavaScript error ends the process with no explanation ("Kabir AI keeps stopping"), and
 * the app's own error monitor was installed from a useEffect, which runs only after the first render. So anything that failed while
 * loading, or during the first render, left no trace. This module:
 *   1. keeps the first fatal JavaScript error and shows it on screen instead of letting the process die silently;
 *   2. registers a minimal fallback root component so a failure while loading the app shows a message, not a black screen.
 */
import { AppRegistry } from "react-native";

export type StartupFault = {
  /** Where it happened, in plain words. */
  source: string;
  message: string;
  /** Stack trace (redacted, shortened). */
  details: string;
  at: string;
  fatal: boolean;
  /** How many faults arrived after the first one (the first is usually the root cause). */
  more: number;
};

type Listener = () => void;

let fault: StartupFault | null = null;
const listeners = new Set<Listener>();

const MAX_DETAILS = 4000;
const MAX_MESSAGE = 800;

/** Removes things that must never be shown or copied around: API keys and bearer tokens. */
export function redact(text: string): string {
  return text
    .replace(/sk-[A-Za-z0-9_-]{8,}/g, "sk-[hidden]")
    .replace(/Bearer\s+[A-Za-z0-9._~+/=-]{8,}/gi, "Bearer [hidden]")
    .replace(/(api[_-]?key|token|secret|password)(["']?\s*[:=]\s*["']?)[^\s"',;]{6,}/gi, "$1$2[hidden]");
}

function describe(error: unknown): { message: string; details: string } {
  if (error instanceof Error) {
    return { message: error.message || error.name || "Unknown error", details: error.stack ?? "" };
  }
  if (typeof error === "string") return { message: error, details: "" };
  if (error === null || error === undefined) return { message: "Unknown error", details: "" };
  try {
    return { message: JSON.stringify(error), details: "" };
  } catch {
    return { message: String(error), details: "" };
  }
}

/** Builds a fault object WITHOUT storing it (for an error boundary that already has the error in hand). */
export function makeStartupFault(error: unknown, source: string, fatal = true): StartupFault {
  const d = describe(error);
  return {
    source,
    message: redact(d.message).slice(0, MAX_MESSAGE),
    details: redact(d.details).slice(0, MAX_DETAILS),
    at: new Date().toISOString(),
    fatal,
    more: 0,
  };
}

export function getStartupFault(): StartupFault | null {
  return fault;
}

export function subscribeStartupFault(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function notify() {
  listeners.forEach((l) => {
    try {
      l();
    } catch {
      /* a broken listener must never break error reporting */
    }
  });
}

/** Records a fault. The FIRST one is kept as the root cause; later ones only increase the counter. */
export function reportStartupFault(error: unknown, source: string, fatal = true): void {
  if (fault) {
    fault = { ...fault, more: fault.more + 1 };
    notify();
    return;
  }
  fault = makeStartupFault(error, source, fatal);
  notify();
}

/** Called by "Try again": forget the fault so the app can show itself again. */
export function clearStartupFault(): void {
  fault = null;
  notify();
}

type ErrorUtilsLike = {
  getGlobalHandler?: () => ((error: unknown, isFatal?: boolean) => void) | undefined;
  setGlobalHandler?: (handler: (error: unknown, isFatal?: boolean) => void) => void;
};

let installed = false;

/**
 * Takes over React Native's global error handler.
 *  - fatal error, release build: remember it and keep the process alive so it can be shown (Try again / Restart);
 *  - fatal error, development:   remember it AND keep React Native's own red box;
 *  - non-fatal error:            behave exactly as before.
 * Safe to call more than once.
 */
export function installEarlyErrorGuard(): void {
  if (installed) return;
  installed = true;
  const errorUtils = (globalThis as { ErrorUtils?: ErrorUtilsLike }).ErrorUtils;
  if (!errorUtils || typeof errorUtils.setGlobalHandler !== "function") return;
  const previous = typeof errorUtils.getGlobalHandler === "function" ? errorUtils.getGlobalHandler() : undefined;
  const dev = typeof __DEV__ !== "undefined" && __DEV__ === true;

  errorUtils.setGlobalHandler((error, isFatal) => {
    if (isFatal) {
      reportStartupFault(error, "Fatal JavaScript error", true);
      if (dev) {
        try {
          previous?.(error, isFatal);
        } catch {
          /* ignore */
        }
      }
      return;
    }
    try {
      previous?.(error, isFatal);
    } catch {
      /* ignore */
    }
  });
}

/**
 * Registers a minimal root under the name Android starts ("main") BEFORE the real app registers itself. If the real app registers
 * normally, it replaces this one. If loading it throws, this one stays and shows the error instead of a black screen.
 */
export function registerFallbackRoot(component: () => unknown): void {
  try {
    (AppRegistry as unknown as { registerComponent: (name: string, provider: () => unknown) => void }).registerComponent(
      "main",
      () => component,
    );
  } catch {
    /* nothing more can be done */
  }
}

/** Test helper: back to a clean state. */
export function __resetStartupGuardForTests(): void {
  fault = null;
  installed = false;
  listeners.clear();
}
