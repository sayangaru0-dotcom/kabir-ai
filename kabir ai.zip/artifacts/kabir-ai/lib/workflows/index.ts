import type { WorkflowName } from "@/lib/screen-commands/steps";
import { youtubeSearchPlay } from "./youtube";
import type { WorkflowContext, WorkflowResult } from "./types";

export type { WorkflowContext, WorkflowResult } from "./types";

/** Registry of the built-in workflows. Names must also be listed in steps.ts WORKFLOW_NAMES (the whitelist). */
export const WORKFLOWS: Record<WorkflowName, (query: string, ctx: WorkflowContext) => Promise<WorkflowResult>> = {
  "youtube.searchPlay": youtubeSearchPlay,
};
