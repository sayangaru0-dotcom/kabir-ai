import * as Agent from "@/modules/kabir-screen-agent";
import type { UiNode } from "@/modules/kabir-screen-agent";
import {
  findBest,
  sleep,
  throwIfAborted,
  waitFor,
  waitForChange,
  waitForSettle,
} from "@/lib/screen-commands/precise-touch";
import type { WorkflowContext, WorkflowResult } from "./types";

/**
 * YouTube: open the app, tap search, type the query, submit, pick the right video, play it.
 *
 * YouTube's real accessibility labels vary by version and language, so nothing here hard-codes one label:
 *  - the search entry is found by (label | text | view id) matching /search/ in en/hi/bn, in the top part of the screen
 *  - a result is chosen by matching the query words against each result's description, skipping ads and Shorts
 * Every stage has a fallback and a precise failure reason, so a break shows up as "search_not_found" etc.
 */

const SEARCH_RE = /search|खोज|সার্চ|অনুসন্ধান/i;
const AD_RE = /\b(sponsored|advert(isement)?|promoted|ad)\b|विज्ञापन|বিজ্ঞাপন|\bshorts?\b/i;
const PLAYER_RE = /\b(pause|minimi[sz]e|mini ?player|player|autoplay|fullscreen)\b|रोकें|পজ/i;

const norm = (s: string) => s.toLowerCase().replace(/\s+/g, " ").trim();
const tokensOf = (q: string) => norm(q).split(/[\s,.;:!?()"'।|\-]+/).filter((t) => t.length >= 2);

export function findSearchEntry(nodes: UiNode[], screenH: number): UiNode | null {
  const c = nodes.filter(
    (n) =>
      n.enabled &&
      (n.clickable || n.editable) &&
      n.bounds.height > 0 &&
      n.bounds.top < screenH * 0.25 &&
      SEARCH_RE.test(`${n.description} ${n.text} ${n.viewId}`),
  );
  // An already-open search box beats the search icon; otherwise the top-most control wins.
  c.sort((a, b) => Number(b.editable) - Number(a.editable) || a.bounds.top - b.bounds.top);
  return c[0] ?? null;
}

export function firstEditable(nodes: UiNode[]): UiNode | null {
  return nodes.find((n) => n.editable && n.enabled && n.bounds.height > 0) ?? null;
}

export type ResultPick = { node: UiNode; score: number; matchedBy: "query" | "top_result" };

/**
 * Picks the video to open from the results list.
 * Candidates: clickable, labelled, big enough to be a result row, below the search bar, not an ad/Short.
 * Best = highest share of query words found in the row's text, ties broken top-to-bottom.
 * If nothing matches well, fall back to the top non-ad result (YouTube's own ranking) and say so.
 */
export function pickBestResult(nodes: UiNode[], query: string, screenH: number): ResultPick | null {
  const tokens = tokensOf(query);
  const rows = nodes.filter((n) => {
    const label = `${n.text} ${n.description}`.trim();
    return (
      n.enabled && n.clickable && label.length > 0 &&
      n.bounds.top > screenH * 0.1 &&
      n.bounds.height >= screenH * 0.05 &&
      !AD_RE.test(label)
    );
  });
  if (rows.length === 0) return null;
  const scored = rows
    .map((n) => {
      const hay = norm(`${n.text} ${n.description}`);
      const hits = tokens.filter((t) => hay.includes(t)).length;
      return { node: n, score: tokens.length ? hits / tokens.length : 0 };
    })
    .sort((a, b) => b.score - a.score || a.node.bounds.top - b.node.bounds.top);
  if (scored[0].score >= 0.6) return { ...scored[0], matchedBy: "query" };
  const top = [...rows].sort((a, b) => a.bounds.top - b.bounds.top)[0];
  return { node: top, score: 0, matchedBy: "top_result" };
}

const snapshotNodes = () => Agent.getScreenSnapshot({ includeNodes: true, includeOcr: false }).nodes;
const centerOf = (n: UiNode) => ({ x: n.bounds.centerX, y: n.bounds.centerY });
const dist = (a: { x: number; y: number }, b: { x: number; y: number }) => Math.hypot(a.x - b.x, a.y - b.y);

async function tapNode(n: UiNode, signal?: AbortSignal): Promise<boolean> {
  const seq = Agent.getChangeSeq();
  const { x, y } = centerOf(n);
  const r = await Agent.tap(x, y);
  if (!r.ok) return false;
  await waitForChange(seq, 800, signal);
  return true;
}

export async function youtubeSearchPlay(query: string, ctx: WorkflowContext = {}): Promise<WorkflowResult> {
  const { signal } = ctx;
  const fail = (detail: string): WorkflowResult => ({ ok: false, detail });
  const { screenHeight: screenH } = Agent.getStatus();

  // 1 ── open YouTube
  const opened = Agent.openApp("YouTube");
  if (!opened.ok) return fail(opened.reason ?? "app_not_found");
  await waitForSettle({ quietMs: 500, timeoutMs: 6000, signal });

  // 2 ── find and tap the search entry (cold start can be slow; if we landed inside a video, step back once)
  let entry = await waitFor(() => findSearchEntry(snapshotNodes(), screenH), 5000, signal);
  if (!entry) {
    await Agent.globalAction("back");
    await waitForSettle({ quietMs: 400, timeoutMs: 2500, signal });
    entry = await waitFor(() => findSearchEntry(snapshotNodes(), screenH), 3000, signal);
  }
  if (!entry) return fail("search_not_found");
  if (!entry.editable || !snapshotNodes().some((n) => n.editable)) {
    if (!(await tapNode(entry, signal))) return fail("tap_failed");
    await waitForSettle({ quietMs: 350, timeoutMs: 3000, signal });
  }

  // 3 ── type the query (virtual input); if no field has focus yet, tap the first input and retry
  let typed = await Agent.typeText(query, false);
  if (!typed.ok) {
    const field = await waitFor(() => firstEditable(snapshotNodes()), 2500, signal);
    if (!field) return fail("no_input_field");
    await tapNode(field, signal);
    await sleep(300, signal);
    typed = await Agent.typeText(query, false);
    if (!typed.ok) return fail(typed.reason ?? "type_failed");
  }
  await sleep(350, signal); // let suggestions render

  // 4 ── submit: keyboard action key (Android 11+), else tap the suggestion that equals the query
  const seqBeforeSubmit = Agent.getChangeSeq();
  const enter = Agent.pressEnter();
  if (!enter.ok) {
    const suggestion = findBest(query, 0.7);
    if (!suggestion) return fail("submit_failed");
    await Agent.tap(suggestion.x, suggestion.y);
  }
  await waitForChange(seqBeforeSubmit, 3000, signal);
  await waitForSettle({ quietMs: 600, timeoutMs: 6000, signal });

  // 5 ── choose the video (scroll a little if the first screen has nothing usable)
  let pick: ResultPick | null = null;
  for (let attempt = 0; attempt < 4; attempt++) {
    throwIfAborted(signal);
    pick = pickBestResult(snapshotNodes(), query, screenH);
    if (pick && (pick.matchedBy === "query" || attempt >= 2)) break;
    if (attempt < 3) {
      await Agent.scroll("down");
      await waitForSettle({ quietMs: 300, timeoutMs: 2000, signal });
    }
  }
  if (!pick) return fail("no_results");

  // 6 ── precision: only tap once the row has stopped moving (results load and shift)
  let target = pick.node;
  for (let i = 0; i < 5; i++) {
    await sleep(80, signal);
    const again = pickBestResult(snapshotNodes(), query, screenH);
    if (again && dist(centerOf(again.node), centerOf(target)) <= 8) { target = again.node; break; }
    if (again) target = again.node;
  }
  if (!(await tapNode(target, signal))) return fail("tap_failed");
  await waitForSettle({ quietMs: 700, timeoutMs: 6000, signal });

  // 7 ── best-effort check that a player is on screen
  const playing = snapshotNodes().some((n) => PLAYER_RE.test(`${n.description} ${n.text}`));
  return {
    ok: true,
    verified: playing,
    note: playing
      ? pick.matchedBy === "query" ? "playing matched result" : "playing top result (no close title match)"
      : "tapped the result but could not confirm playback",
  };
}
