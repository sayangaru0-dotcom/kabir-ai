export type WorkflowContext = { signal?: AbortSignal };
export type WorkflowResult = { ok: boolean; detail?: string; verified?: boolean; note?: string };
