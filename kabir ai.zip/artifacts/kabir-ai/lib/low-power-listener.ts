import type { AppStateStatus } from "react-native";

export const LOW_POWER_WAKE_POLICY = {
  capturePreset: "low-quality",
  initialWindowMs: 7_000,
  quietWindowStepMs: 1_000,
  maxWindowMs: 12_000,
  maxQuietWindows: 5,
  uploadSilentClips: false,
  pauseOutsideForeground: true,
} as const;

export type WakeListeningWindow = {
  shouldCapture: boolean;
  durationMs: number;
};

export function getWakeListeningWindow(
  appState: AppStateStatus,
  consecutiveQuietWindows: number,
): WakeListeningWindow {
  if (appState !== "active") {
    return { shouldCapture: false, durationMs: 0 };
  }

  const quietCount = Math.max(
    0,
    Math.min(Math.floor(consecutiveQuietWindows), LOW_POWER_WAKE_POLICY.maxQuietWindows),
  );
  const durationMs = Math.min(
    LOW_POWER_WAKE_POLICY.initialWindowMs +
      quietCount * LOW_POWER_WAKE_POLICY.quietWindowStepMs,
    LOW_POWER_WAKE_POLICY.maxWindowMs,
  );

  return { shouldCapture: true, durationMs };
}

export function nextQuietWindowCount(
  hadSpeech: boolean,
  currentCount: number,
): number {
  if (hadSpeech) return 0;
  return Math.min(currentCount + 1, LOW_POWER_WAKE_POLICY.maxQuietWindows);
}
