export type CleanKnowledgeEntry = {
  id: string;
  title: string;
  summary: string;
  actions: string[];
  createdAt: string;
};

export type CollectiveKnowledgeBundle = {
  schema: "kabir.collective-knowledge";
  schemaVersion: 1;
  exportedAt: string;
  entries: CleanKnowledgeEntry[];
};

export const COLLECTIVE_KNOWLEDGE_JSON_SCHEMA = {
  $schema: "https://json-schema.org/draft/2020-12/schema",
  $id: "urn:kabir:collective-knowledge:v1",
  title: "Kabir Collective Knowledge Bundle",
  description:
    "Noise-filtered learning entries only. Original recordings and raw transcripts are not part of this export.",
  type: "object",
  additionalProperties: false,
  required: ["schema", "schemaVersion", "exportedAt", "entries"],
  properties: {
    schema: { const: "kabir.collective-knowledge" },
    schemaVersion: { const: 1 },
    exportedAt: { type: "string", format: "date-time" },
    entries: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["id", "title", "summary", "actions", "createdAt"],
        properties: {
          id: { type: "string", minLength: 1 },
          title: { type: "string", minLength: 1, maxLength: 160 },
          summary: { type: "string", maxLength: 2000 },
          actions: {
            type: "array",
            minItems: 1,
            items: { type: "string", minLength: 1, maxLength: 500 },
          },
          createdAt: { type: "string", format: "date-time" },
        },
      },
    },
  },
} as const;

export function createCollectiveKnowledgeBundle(
  entries: readonly CleanKnowledgeEntry[],
): CollectiveKnowledgeBundle {
  const exportedAt = new Date().toISOString();
  const cleanEntries = entries.flatMap((entry) => {
    const id = entry.id.trim();
    const actions = entry.actions
      .filter((action) => typeof action === "string")
      .map((action) => action.trim().slice(0, 500))
      .filter(Boolean);
    if (!id || actions.length === 0) return [];

    const parsedDate = new Date(entry.createdAt);
    return [
      {
        id: id.slice(0, 128),
        title: entry.title.trim().slice(0, 160) || "Learning note",
        summary: entry.summary.trim().slice(0, 2000),
        actions,
        createdAt: Number.isNaN(parsedDate.getTime())
          ? exportedAt
          : parsedDate.toISOString(),
      },
    ];
  });

  return {
    schema: "kabir.collective-knowledge",
    schemaVersion: 1,
    exportedAt,
    entries: cleanEntries,
  };
}
