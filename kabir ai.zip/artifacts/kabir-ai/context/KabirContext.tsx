import AsyncStorage from "@react-native-async-storage/async-storage";
import { recordAppError } from "@/lib/error-monitor";
import {
  CUSTOMIZATION_COLOR_KEYS,
  DEFAULT_APPEARANCE,
  isHexColor,
  isLogoVariant,
  THEME_PRESETS,
  type AppearancePreferences,
  type CustomizationColorKey,
  type LogoVariant,
  type ThemeId,
} from "@/constants/themes";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type PropsWithChildren,
} from "react";

const STORAGE_KEY = "@kabir/local-data/v1";
const MAX_WAKE_PHRASES = 4;

export type ResponseLanguage = "Bengali" | "Hindi" | "English";
export type KabirStatus = "Active" | "Sleeping" | "Learning";

export type WakePhrase = {
  id: string;
  text: string;
  createdAt: string;
};

export type LearningEntry = {
  id: string;
  title: string;
  summary: string;
  actions: string[];
  createdAt: string;
};

type PersistedData = {
  responseLanguage: ResponseLanguage;
  wakePhrases: WakePhrase[];
  learningEntries: LearningEntry[];
  appearance: AppearancePreferences;
};

type KabirContextValue = PersistedData & {
  ready: boolean;
  storageError: string | null;
  status: KabirStatus;
  setStatus: (status: KabirStatus) => void;
  setResponseLanguage: (language: ResponseLanguage) => void;
  setThemePreset: (themeId: ThemeId) => void;
  setColorOverride: (key: CustomizationColorKey, color: string | null) => void;
  resetCustomColors: () => void;
  setLogoVariant: (variant: LogoVariant) => void;
  setBrandName: (name: string) => void;
  addWakePhrase: (text: string) => void;
  removeWakePhrase: (id: string) => void;
  addLearningEntry: (entry: Omit<LearningEntry, "id" | "createdAt">) => void;
  removeLearningEntry: (id: string) => void;
};

const initialData: PersistedData = {
  responseLanguage: "English",
  wakePhrases: [],
  learningEntries: [],
  appearance: DEFAULT_APPEARANCE,
};

const KabirContext = createContext<KabirContextValue | null>(null);

function createId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function readPersistedData(value: string | null): PersistedData {
  if (!value) return initialData;

  const saved = JSON.parse(value) as Partial<PersistedData>;
  const responseLanguage =
    saved.responseLanguage === "Bengali" ||
    saved.responseLanguage === "Hindi" ||
    saved.responseLanguage === "English"
      ? saved.responseLanguage
      : initialData.responseLanguage;

  const wakePhrases = Array.isArray(saved.wakePhrases)
    ? saved.wakePhrases
        .filter(
          (item): item is WakePhrase =>
            typeof item?.id === "string" &&
            typeof item?.text === "string" &&
            typeof item?.createdAt === "string",
        )
        .slice(0, MAX_WAKE_PHRASES)
    : [];

  const learningEntries = Array.isArray(saved.learningEntries)
    ? saved.learningEntries
        .filter(
          (item): item is LearningEntry =>
            typeof item?.id === "string" &&
            typeof item?.title === "string" &&
            typeof item?.summary === "string" &&
            Array.isArray(item?.actions) &&
            item.actions.every((action) => typeof action === "string") &&
            typeof item?.createdAt === "string",
        )
        .slice(0, 500)
    : [];

  const rawAppearance =
    saved.appearance && typeof saved.appearance === "object"
      ? (saved.appearance as Partial<AppearancePreferences>)
      : {};
  const themeId = THEME_PRESETS.some((theme) => theme.id === rawAppearance.themeId)
    ? (rawAppearance.themeId as ThemeId)
    : DEFAULT_APPEARANCE.themeId;
  const colorOverrides: AppearancePreferences["colorOverrides"] = {};
  for (const key of CUSTOMIZATION_COLOR_KEYS) {
    const value = rawAppearance.colorOverrides?.[key];
    if (typeof value === "string" && isHexColor(value)) {
      colorOverrides[key] = value.toUpperCase();
    }
  }
  const appearance: AppearancePreferences = {
    themeId,
    colorOverrides,
    logoVariant:
      typeof rawAppearance.logoVariant === "string" && isLogoVariant(rawAppearance.logoVariant)
        ? rawAppearance.logoVariant
        : DEFAULT_APPEARANCE.logoVariant,
    brandName:
      typeof rawAppearance.brandName === "string"
        ? rawAppearance.brandName.slice(0, 28)
        : DEFAULT_APPEARANCE.brandName,
  };

  return { responseLanguage, wakePhrases, learningEntries, appearance };
}

export function KabirProvider({ children }: PropsWithChildren) {
  const [data, setData] = useState<PersistedData>(initialData);
  const [ready, setReady] = useState(false);
  const [canPersist, setCanPersist] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [status, setStatus] = useState<KabirStatus>("Sleeping");

  useEffect(() => {
    let cancelled = false;

    AsyncStorage.getItem(STORAGE_KEY)
      .then((value) => {
        if (cancelled) return;
        setData(readPersistedData(value));
        setCanPersist(true);
        setReady(true);
      })
      .catch((caught) => {
        if (cancelled) return;
        setStorageError("Kabir could not load saved settings from this device.");
        setReady(true);
        void recordAppError(caught, "Local storage read");
      });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!ready || !canPersist) return;

    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data)).catch((caught) => {
      setStorageError("Kabir could not save your latest changes on this device.");
      void recordAppError(caught, "Local storage write");
    });
  }, [canPersist, data, ready]);

  const setResponseLanguage = useCallback((responseLanguage: ResponseLanguage) => {
    setData((current) => ({ ...current, responseLanguage }));
  }, []);

  const setThemePreset = useCallback((themeId: ThemeId) => {
    setData((current) => ({
      ...current,
      appearance: { ...current.appearance, themeId, colorOverrides: {} },
    }));
  }, []);

  const setColorOverride = useCallback(
    (key: CustomizationColorKey, color: string | null) => {
      if (color !== null && !isHexColor(color)) return;
      setData((current) => {
        const colorOverrides = { ...current.appearance.colorOverrides };
        if (color === null) {
          delete colorOverrides[key];
        } else {
          colorOverrides[key] = color.toUpperCase();
        }
        return {
          ...current,
          appearance: { ...current.appearance, colorOverrides },
        };
      });
    },
    [],
  );

  const resetCustomColors = useCallback(() => {
    setData((current) => ({
      ...current,
      appearance: { ...current.appearance, colorOverrides: {} },
    }));
  }, []);

  const setLogoVariant = useCallback((logoVariant: LogoVariant) => {
    setData((current) => ({
      ...current,
      appearance: { ...current.appearance, logoVariant },
    }));
  }, []);

  const setBrandName = useCallback((brandName: string) => {
    setData((current) => ({
      ...current,
      appearance: { ...current.appearance, brandName: brandName.slice(0, 28) },
    }));
  }, []);

  const addWakePhrase = useCallback((text: string) => {
    const cleanText = text.trim().replace(/\s+/g, " ");
    if (!cleanText) return;

    setData((current) => {
      if (
        current.wakePhrases.length >= MAX_WAKE_PHRASES ||
        current.wakePhrases.some(
          (phrase) => phrase.text.toLocaleLowerCase() === cleanText.toLocaleLowerCase(),
        )
      ) {
        return current;
      }
      return {
        ...current,
        wakePhrases: [
          ...current.wakePhrases,
          { id: createId(), text: cleanText, createdAt: new Date().toISOString() },
        ],
      };
    });
  }, []);

  const removeWakePhrase = useCallback((id: string) => {
    setData((current) => ({
      ...current,
      wakePhrases: current.wakePhrases.filter((phrase) => phrase.id !== id),
    }));
  }, []);

  const addLearningEntry = useCallback((entry: Omit<LearningEntry, "id" | "createdAt">) => {
    const cleanActions = entry.actions.map((action) => action.trim()).filter(Boolean);
    if (cleanActions.length === 0) return;

    setData((current) => ({
      ...current,
      learningEntries: [
        {
          ...entry,
          title: entry.title.trim() || "Learning note",
          summary: entry.summary.trim(),
          actions: cleanActions,
          id: createId(),
          createdAt: new Date().toISOString(),
        },
        ...current.learningEntries,
      ].slice(0, 500),
    }));
  }, []);

  const removeLearningEntry = useCallback((id: string) => {
    setData((current) => ({
      ...current,
      learningEntries: current.learningEntries.filter((entry) => entry.id !== id),
    }));
  }, []);

  const value = useMemo<KabirContextValue>(
    () => ({
      ...data,
      ready,
      storageError,
      status,
      setStatus,
      setResponseLanguage,
      setThemePreset,
      setColorOverride,
      resetCustomColors,
      setLogoVariant,
      setBrandName,
      addWakePhrase,
      removeWakePhrase,
      addLearningEntry,
      removeLearningEntry,
    }),
    [
      data,
      ready,
      storageError,
      status,
      setResponseLanguage,
      setThemePreset,
      setColorOverride,
      resetCustomColors,
      setLogoVariant,
      setBrandName,
      addWakePhrase,
      removeWakePhrase,
      addLearningEntry,
      removeLearningEntry,
    ],
  );

  return <KabirContext.Provider value={value}>{children}</KabirContext.Provider>;
}

export function useKabir() {
  const context = useContext(KabirContext);
  if (!context) {
    throw new Error("useKabir must be used inside KabirProvider.");
  }
  return context;
}

export function useKabirOptional() {
  return useContext(KabirContext);
}
