#!/usr/bin/env python3
"""
Static guards for the app's startup path (package.json entry, index.js, _layout.tsx, error monitor, native wrapper, hooks).
Each check encodes a startup-crash hazard found by review, so it cannot silently return. Usage: python3 tests/startup_static_check.py
"""
import json, os, re, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
APP = os.path.join(ROOT, "artifacts", "kabir-ai")
def rd(*p): return open(os.path.join(APP, *p)).read()
passed = failed = 0
def check(name, ok, detail=""):
    global passed, failed
    if ok: passed += 1; print("  ok  ", name)
    else: failed += 1; print("  FAIL", name, "-", detail)

print("entry point")
pkg = json.load(open(os.path.join(APP, "package.json")))
check('package.json "main" is the custom entry index.js', pkg.get("main") == "index.js", str(pkg.get("main")))
idx = rd("index.js")
check("index.js exists and uses require() (static imports are hoisted above the guard)", "require(" in idx and not re.search(r"^\s*import\s", idx, re.M))
g = idx.find("installEarlyErrorGuard()"); f = idx.find("registerFallbackRoot("); e = idx.find('require("expo-router/entry")')
check("guard is installed and the fallback root registered BEFORE expo-router is loaded", -1 < g < e and -1 < f < e, f"{g} {f} {e}")
check("loading expo-router is wrapped in try/catch and reports the failure", re.search(r"try\s*\{\s*require\(\"expo-router/entry\"\);\s*\}\s*catch\s*\(error\)\s*\{\s*guard\.reportStartupFault", idx) is not None)

print("root layout")
lay = rd("app", "_layout.tsx")
check("_layout exports an ErrorBoundary (expo-router wraps the layout itself with it)", re.search(r"export function ErrorBoundary\(", lay) is not None)
check("splash preventAutoHideAsync() rejection is handled", re.search(r"preventAutoHideAsync\(\)\.catch\(", lay) is not None)
check("splash hideAsync() rejection is handled, and no bare hideAsync() remains", re.search(r"hideAsync\(\)\.catch\(", lay) is not None and not re.search(r"hideAsync\(\);", lay))
check("font loading has a timeout (no endless blank screen)", "FONT_WAIT_MS" in lay and "fontsGaveUp" in lay and "if (!fontsReady) return null" in lay)
check("the whole app tree sits inside StartupFaultGate", "<StartupFaultGate>" in lay and "</StartupFaultGate>" in lay)
check("installGlobalErrorMonitoring() is inside try/catch", re.search(r"try\s*\{\s*return installGlobalErrorMonitoring\(\);\s*\}\s*catch", lay) is not None)
check("setBaseUrl() is inside try/catch", re.search(r"try\s*\{\s*if \(process\.env\.EXPO_PUBLIC_DOMAIN\) \{\s*setBaseUrl", lay) is not None)
check("the app's own ErrorBoundary is renamed so it does not clash with the router export", "ErrorBoundary as AppErrorBoundary" in lay)

print("error monitor")
mon = rd("lib", "error-monitor.ts")
check("window event API is feature-detected before use", 'typeof window.addEventListener === "function"' in mon and "hasWindowEvents" in mon)
check("handler installation is wrapped in try/catch", re.search(r"try\s*\{\s*if \(previousHandler && errorUtils\?\.setGlobalHandler\)", mon) is not None)

print("startup screen and guard have no app dependencies")
def imports(src): return re.findall(r"from\s+[\"']([^\"']+)[\"']", src)
scr = imports(rd("components", "StartupErrorScreen.tsx")); grd = imports(rd("lib", "startup-guard.ts"))
check("StartupErrorScreen imports only react, react-native and the guard (no theme/providers/router/alias)", set(scr) <= {"react", "react-native", "../lib/startup-guard"}, str(scr))
check("startup-guard imports only react-native", set(grd) <= {"react-native"}, str(grd))

print("native wrapper and hooks")
nat = rd("modules", "kabir-screen-agent", "index.ts")
check("native module loading is wrapped in try/catch (loadNative)", re.search(r"function loadNative\(\)[^{]*\{\s*try\s*\{", nat) is not None)
for fn in ("getStatus", "getChangeSeq"):
    m = re.search(r"export const %s = [^{]*\{\s*try\s*\{" % fn, nat); check(f"{fn}() cannot throw", m is not None)
check("addScreenAgentListener() cannot throw", re.search(r"function addScreenAgentListener[\s\S]*?try\s*\{[\s\S]*?catch", nat) is not None)
vc = rd("hooks", "useVoiceCommands.ts")
ar = vc[vc.index("function useAgentReady"): vc.index("function confirmDialog") if "function confirmDialog" in vc else vc.index("function problemText")]
check("useAgentReady guards native calls with try/catch and defers the first one", "try {" in ar and "setTimeout(check, 800)" in ar and "alive" in ar)
check("useVoiceCommands returns a memoised object (stable identity)", "return useMemo(" in vc)
sa = rd("hooks", "useScreenAgent.ts")
check("useScreenAgent.refresh() cannot throw from a timer", re.search(r"const refresh = useCallback\(\(\) => \{[\s\S]*?try\s*\{[\s\S]*?setStatus\(getStatus\(\)\)", sa) is not None)

print(f"\n{passed} passed, {failed} failed"); sys.exit(1 if failed else 0)
