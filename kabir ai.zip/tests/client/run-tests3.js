// Diagnostics: runs the project's REAL lib/error-monitor.ts (with the new automation rules) and the reporting bridge.
const Module = require("module"); const path = require("path");
const store = new Map();
const mocks = {
  "react-native": { Alert: { alert() {} }, Platform: { OS: "android", Version: 34 } },
  "react": { useState: (i) => [i, () => {}], useEffect: () => {} },
  "@react-native-async-storage/async-storage": { __esModule: true, default: {
    getItem: async (k) => store.get(k) ?? null, setItem: async (k, v) => { store.set(k, v); }, removeItem: async (k) => { store.delete(k); } } },
};
const orig = Module._load;
Module._load = function (req, ...r) {
  if (mocks[req]) return mocks[req];
  if (req.startsWith("@/")) return orig.call(this, path.resolve("dist", req.slice(2)), ...r);
  return orig.call(this, req, ...r);
};
const { recordAppError } = require("./dist/lib/error-monitor.js");
const { reportAutomationIssue } = require("./dist/lib/screen-commands/diagnostics.js");
let pass = 0, failc = 0;
const t = async (n, f) => { try { await f(); pass++; console.log("  ok  ", n); } catch (e) { failc++; console.log("  FAIL", n, "-", e.message); } };
const eq = (a, b) => { if (a !== b) throw new Error(`expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); };
const diag = async (msg, source = "Test", extra) => recordAppError(extra ?? new Error(msg), source);
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  console.log("new automation rules");
  await t("native module missing", async () => eq((await diag("KabirScreenAgent native module is unavailable. It needs Android and a development build")).title, "Screen control isn't in this build"));
  await t("accessibility off (E_A11Y_OFF)", async () => { const r = await diag("Kabir's Accessibility Service is not enabled. [E_A11Y_OFF]"); eq(r.title, "Screen access is off"); eq(r.requiresDeviceSettings, true); if (!r.steps.some((s) => /Allow restricted settings/.test(s))) throw new Error("missing sideload tip"); });
  await t("accessibility_off from a routine run", async () => eq((await diag("Turn on Kabir's accessibility service so I can use the screen. [accessibility_off]", "Routine")).title, "Screen access is off"));
  await t("notification permission", async () => eq((await diag("Notification permission is required so the 'Kabir is reading your screen' indicator is visible.")).title, "Screen reading needs permission"));
  await t("capture failed", async () => eq((await diag("capture: capture failed", "Screen agent")).title, "Screen reading needs permission"));
  await t("blocked app", async () => eq((await diag("That app is on your blocked list, so I left it alone. [blocked_app]")).title, "That app is on your blocked list"));
  await t("needs repair", async () => eq((await diag(`"Lofi" stopped working twice in a row. It needs to be repaired or taught again.`, "Routine")).title, "A routine needs repair"));
  await t("not found on screen", async () => eq((await diag(`I couldn't find it on the screen (tap "Send"). [not_found]`, "Screen command")).title, "Kabir couldn't find that on the screen"));
  await t("youtube search_not_found", async () => eq((await diag("youtube.searchPlay \"lofi\" [search_not_found]", "Screen command")).title, "Kabir couldn't find that on the screen"));
  await t("every new rule keeps helpUrl null (passes the record validator)", async () => { const r = await diag("another accessibility problem here"); eq(r.helpUrl, null); });

  console.log("existing rules unchanged");
  await t("microphone permission", async () => eq((await diag("Microphone permission was denied.", "Microphone recording")).title, "Microphone permission"));
  await t("401 -> AI credentials", async () => eq((await diag("bad", "Voice request", Object.assign(new Error("Unauthorized"), { status: 401 }))).title, "AI service credentials"));
  await t("429 -> usage limit", async () => eq((await diag("rate", "Voice request", Object.assign(new Error("Too many"), { status: 429 }))).title, "AI usage limit"));
  await t("network -> connection issue", async () => eq((await diag("Network request failed", "Voice request")).title, "Connection issue"));
  await t("unknown -> generic", async () => eq((await diag("something odd 123", "Other")).title, "Kabir encountered an error"));
  await t("API keys are still redacted in diagnostics", async () => { const r = await diag("failed with sk-abcdefghijklmnop1234 key", "Voice request"); if (/sk-abcdef/.test(r.message + r.details)) throw new Error("key leaked"); });

  console.log("reporting bridge");
  const count = () => JSON.parse(store.get("@kabir/diagnostics/v1") || "[]").length;
  await t("real fault is recorded", async () => { const n = count(); reportAutomationIssue("Routine", "bridge fault one", "not_found"); await wait(60); eq(count(), n + 1); });
  await t("cancelled / declined are NOT recorded (user choices)", async () => { const n = count(); reportAutomationIssue("Routine", "user stopped it", "cancelled"); reportAutomationIssue("Routine", "user said no", "declined"); await wait(60); eq(count(), n); });
  await t("reason is appended for the rules to match", async () => { reportAutomationIssue("Screen command", "plain text", "search_not_found"); await wait(60); const last = JSON.parse(store.get("@kabir/diagnostics/v1"))[0]; eq(last.title, "Kabir couldn't find that on the screen"); });

  console.log(`\n${pass} passed, ${failc} failed`); process.exit(failc ? 1 : 0);
})();
