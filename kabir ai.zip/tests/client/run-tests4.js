// Startup resilience: the early error guard, the custom entry file (index.js), and the native-module wrapper, under simulated failures.
const Module = require("module"); const path = require("path");
const registry = { registered: {}, registerComponent(name, provider) { this.registered[name] = provider; } };
let nativeMode = "ok";            // ok | throws-on-load | missing | throws-calls
let entryMode = "ok";             // ok | throws | throws-string
let entryLog = [];
const fakeNative = {
  getStatus: () => { if (nativeMode === "throws-calls") throw new Error("native boom"); return { accessibilityEnabled: true, apiLevel: 34 }; },
  getChangeSeq: () => { if (nativeMode === "throws-calls") throw new Error("native boom"); return 42; },
  addListener: () => { if (nativeMode === "throws-calls") throw new Error("native boom"); return { remove() {} }; },
};
const mocks = {
  "react-native": { AppRegistry: registry, Platform: { OS: "android", Version: 34 }, PermissionsAndroid: {} },
  "expo-modules-core": { requireOptionalNativeModule: () => { if (nativeMode === "throws-on-load") throw new Error("cannot load"); return nativeMode === "missing" ? null : fakeNative; } },
  "./components/StartupErrorScreen": { StartupErrorRoot: function StartupErrorRoot() {} },
  "expo-router/entry": null,
};
const orig = Module._load;
Module._load = function (req, ...r) {
  if (req === "expo-router/entry") {
    entryLog.push({ mainRegisteredBeforeEntry: !!registry.registered.main, handlerIsGuard: globalThis.ErrorUtils && globalThis.ErrorUtils.handler && globalThis.ErrorUtils.handler.__isTest !== true });
    if (entryMode === "throws") throw new Error("Invariant Violation: TurboModuleRegistry.getEnforcing(...): 'SomeModule' could not be found");
    if (entryMode === "throws-string") throw "plain string failure";
    registry.registerComponent("main", () => "REAL_APP"); return {};
  }
  if (mocks[req]) return mocks[req];
  if (req.startsWith("@/")) return orig.call(this, path.resolve("dist", req.slice(2)), ...r);
  return orig.call(this, req, ...r);
};
const guardPath = "./dist/lib/startup-guard.js";
const fresh = (p) => { delete require.cache[require.resolve(p)]; return require(p); };
function setupErrorUtils() {
  const eu = { handler: null, calls: [], getGlobalHandler() { return this.handler; }, setGlobalHandler(h) { this.handler = h; } };
  eu.handler = (error, isFatal) => eu.calls.push({ error, isFatal }); eu.handler.__isTest = true;
  globalThis.ErrorUtils = eu; return eu;
}
let pass = 0, failc = 0;
const t = (name, fn) => { try { fn(); pass++; console.log("  ok  ", name); } catch (e) { failc++; console.log("  FAIL", name, "-", e.message); } };
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m || ""} expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); };
const ok = (c, m) => { if (!c) throw new Error(m || "assertion failed"); };

console.log("early error guard");
t("release build: a FATAL error is kept for the screen and the process is NOT killed (previous handler not called)", () => {
  globalThis.__DEV__ = false; const g = fresh(guardPath); g.__resetStartupGuardForTests(); const eu = setupErrorUtils(); g.installEarlyErrorGuard();
  eu.handler(new Error("kaboom at startup"), true);
  const f = g.getStartupFault(); ok(f && f.message === "kaboom at startup" && f.fatal === true && f.source === "Fatal JavaScript error", JSON.stringify(f));
  eq(eu.calls.length, 0, "previous handler (which would end the process) must not run");
});
t("development build: fatal error is kept AND React Native's own red box still runs", () => {
  globalThis.__DEV__ = true; const g = fresh(guardPath); g.__resetStartupGuardForTests(); const eu = setupErrorUtils(); g.installEarlyErrorGuard();
  eu.handler(new Error("dev boom"), true); ok(g.getStartupFault().message === "dev boom"); eq(eu.calls.length, 1);
});
t("non-fatal errors behave exactly as before: forwarded, never shown as a startup fault", () => {
  globalThis.__DEV__ = false; const g = fresh(guardPath); g.__resetStartupGuardForTests(); const eu = setupErrorUtils(); g.installEarlyErrorGuard();
  eu.handler(new Error("just a warning"), false); eq(g.getStartupFault(), null); eq(eu.calls.length, 1); eq(eu.calls[0].isFatal, false);
});
t("the FIRST fatal error is kept as the root cause; later ones are only counted", () => {
  globalThis.__DEV__ = false; const g = fresh(guardPath); g.__resetStartupGuardForTests(); const eu = setupErrorUtils(); g.installEarlyErrorGuard();
  eu.handler(new Error("root cause"), true); eu.handler(new Error("consequence 1"), true); eu.handler(new Error("consequence 2"), true);
  const f = g.getStartupFault(); eq([f.message, f.more], ["root cause", 2]);
});
t("installing twice does not wrap twice", () => {
  globalThis.__DEV__ = false; const g = fresh(guardPath); g.__resetStartupGuardForTests(); const eu = setupErrorUtils(); g.installEarlyErrorGuard(); const h1 = eu.handler; g.installEarlyErrorGuard();
  ok(eu.handler === h1, "handler replaced on second install"); eu.handler(new Error("w"), false); eq(eu.calls.length, 1);
});
t("works when ErrorUtils is missing or incomplete (never throws)", () => {
  const g = fresh(guardPath); g.__resetStartupGuardForTests(); delete globalThis.ErrorUtils; g.installEarlyErrorGuard();
  const g2 = fresh(guardPath); g2.__resetStartupGuardForTests(); globalThis.ErrorUtils = {}; g2.installEarlyErrorGuard();
});
t("subscribers are notified on report and clear; unsubscribe works; a throwing subscriber cannot break reporting", () => {
  const g = fresh(guardPath); g.__resetStartupGuardForTests(); let n = 0, m = 0;
  const off = g.subscribeStartupFault(() => { n++; throw new Error("bad listener"); }); g.subscribeStartupFault(() => { m++; });
  g.reportStartupFault(new Error("a"), "t"); eq([n, m], [1, 1]); g.clearStartupFault(); eq([n, m], [2, 2]); eq(g.getStartupFault(), null);
  off(); g.reportStartupFault(new Error("b"), "t"); eq([n, m], [2, 3]);
});
t("secrets never reach the screen: API keys, bearer tokens, api_key=... are redacted in message AND stack", () => {
  const g = fresh(guardPath); g.__resetStartupGuardForTests();
  const e = new Error("request failed with sk-abcdefghijklmnop1234 and Bearer eyJhbGciOiJIUzI1NiJ9.abc.def"); e.stack = "at x\napi_key=SUPERSECRET123 at y";
  g.reportStartupFault(e, "t"); const f = g.getStartupFault();
  ok(!/sk-abcdef|eyJhbGci|SUPERSECRET/.test(f.message + f.details), f.message + f.details); ok(/\[hidden\]/.test(f.message));
});
t("non-Error values are described safely (string, object, null, circular)", () => {
  const g = fresh(guardPath);
  for (const [v, want] of [["plain", "plain"], [null, "Unknown error"], [undefined, "Unknown error"], [{ code: 7 }, '{"code":7}']]) { g.__resetStartupGuardForTests(); g.reportStartupFault(v, "t"); eq(g.getStartupFault().message, want); }
  const c = {}; c.self = c; g.__resetStartupGuardForTests(); g.reportStartupFault(c, "t"); ok(typeof g.getStartupFault().message === "string");
});
t("huge errors are truncated (message 800, details 4000)", () => {
  const g = fresh(guardPath); g.__resetStartupGuardForTests(); const e = new Error("m".repeat(5000)); e.stack = "s".repeat(20000); g.reportStartupFault(e, "t");
  const f = g.getStartupFault(); ok(f.message.length <= 800 && f.details.length <= 4000, `${f.message.length}/${f.details.length}`);
});
t("makeStartupFault builds a fault WITHOUT storing it", () => { const g = fresh(guardPath); g.__resetStartupGuardForTests(); const f = g.makeStartupFault(new Error("x"), "boundary"); eq([f.message, f.source], ["x", "boundary"]); eq(g.getStartupFault(), null); });
t("registerFallbackRoot registers 'main' and survives AppRegistry failing", () => {
  const g = fresh(guardPath); registry.registered = {}; g.registerFallbackRoot(function Fallback() {}); ok(typeof registry.registered.main === "function");
  const orig = registry.registerComponent; registry.registerComponent = () => { throw new Error("registry down"); }; g.registerFallbackRoot(() => {}); registry.registerComponent = orig;
});

console.log("custom entry point (index.js)");
function runEntry(mode) {
  globalThis.__DEV__ = false; entryMode = mode; entryLog = []; registry.registered = {}; setupErrorUtils();
  delete require.cache[require.resolve(guardPath)]; const g = require(guardPath); g.__resetStartupGuardForTests();
  delete require.cache[require.resolve("./dist/index.js")]; let threw = null;
  try { require("./dist/index.js"); } catch (e) { threw = e; }
  return { g, threw, mainIsReal: registry.registered.main && registry.registered.main() === "REAL_APP" };
}
t("normal start: the guard and the fallback root exist BEFORE the real app loads, and the real app then takes over", () => {
  const r = runEntry("ok"); ok(!r.threw && r.mainIsReal, "real app should own 'main'"); eq(entryLog[0].mainRegisteredBeforeEntry, true); eq(r.g.getStartupFault(), null);
  ok(globalThis.ErrorUtils.handler.__isTest !== true, "guard handler must be installed before the app loads");
});
t("the app throws while LOADING: nothing escapes, the error is recorded, and the fallback screen stays registered (no black screen, no crash)", () => {
  const r = runEntry("throws"); ok(!r.threw, "index.js must not throw"); const f = r.g.getStartupFault();
  ok(f && f.source === "The app failed to load" && /TurboModuleRegistry/.test(f.message), JSON.stringify(f));
  ok(!r.mainIsReal && typeof registry.registered.main === "function", "fallback root must remain registered");
});
t("the app throws a non-Error while loading: still handled", () => { const r = runEntry("throws-string"); ok(!r.threw); eq(r.g.getStartupFault().message, "plain string failure"); });
t("a fatal error AFTER a good start is shown instead of killing the process", () => {
  const r = runEntry("ok"); globalThis.ErrorUtils.handler(new Error("late fatal"), true); eq(r.g.getStartupFault().message, "late fatal"); eq(globalThis.ErrorUtils.calls.length, 0);
});

console.log("native module wrapper (cannot take the app down)");
function loadAgent(mode) { nativeMode = mode; return fresh("./dist/modules/kabir-screen-agent/index.js"); }
t("the native module throws while LOADING: the app still starts, the agent is just 'unsupported'", () => {
  const a = loadAgent("throws-on-load"); eq(a.isScreenAgentSupported, false);
  eq(a.getStatus().accessibilityEnabled, false); eq(a.getChangeSeq(), 0); const sub = a.addScreenAgentListener("onServiceState", () => {}); sub.remove();
});
t("native module absent (Expo Go / other platform): same safe behaviour", () => { const a = loadAgent("missing"); eq(a.isScreenAgentSupported, false); eq(a.getStatus(), a.OFFLINE_STATUS); eq(a.getChangeSeq(), 0); });
t("native calls that throw at runtime (status, change counter, listener) are swallowed and return safe defaults", () => {
  const a = loadAgent("throws-calls"); eq(a.isScreenAgentSupported, true); eq(a.getStatus(), a.OFFLINE_STATUS); eq(a.getChangeSeq(), 0); a.addScreenAgentListener("onServiceState", () => {}).remove();
});
t("healthy native module: values pass straight through", () => { const a = loadAgent("ok"); eq(a.isScreenAgentSupported, true); eq(a.getStatus().apiLevel, 34); eq(a.getChangeSeq(), 42); });
t("actions (tap, scroll, ...) still fail loudly when the module is unavailable, so a command never 'succeeds' silently", () => {
  const a = loadAgent("missing"); let msg = ""; try { a.pressEnter(); } catch (e) { msg = e.message; } ok(/unavailable/.test(msg), msg);
});

console.log(`\n${pass} passed, ${failc} failed`); process.exit(failc ? 1 : 0);
