// Fake phone: a list "screen" that scrolls, buttons that react to taps.
const state = { seq: 0, foreground: "com.kabir", own: "com.kabir", accessibility: true,
  scrollPos: 0, endAt: 4, screen: "kabir", taps: [], nodeClicks: 0, jitterUntil: 0, tapReacts: true, opened: [] };
const bump = (ms=15) => setTimeout(() => { state.seq++; }, ms);
const targetsFor = (q) => {
  q = q.toLowerCase();
  const t = [];
  if (state.screen === "home" && q === "settings") t.push({ x: 200, y: 400, label: "Settings", confidence: 0.95, source: "node", bounds: {} });
  if (state.screen === "settings") {
    if (q === "wi-fi") t.push({ x: 300 + (Date.now() < state.jitterUntil ? Math.random()*80 : 0), y: 500, label: "Wi-Fi", confidence: 0.95, source: "node", bounds: {} });
    if (q === "bluetooth" && state.scrollPos >= 3) t.push({ x: 300, y: 700, label: "Bluetooth", confidence: 0.9, source: "ocr", bounds: {} });
    if (q === "delete") t.push({ x: 100, y: 900, label: "Delete all", confidence: 0.9, source: "node", bounds: {} });
    if (q === "ok") t.push({ x: 100, y: 950, label: "Delete all", confidence: 0.8, source: "node", bounds: {} });
  }
  return t;
};
module.exports = {
  isScreenAgentSupported: true,
  state,
  getStatus: () => ({ accessibilityEnabled: state.accessibility, foregroundPackage: state.foreground, ownPackage: state.own }),
  getChangeSeq: () => state.seq,
  minimizeApp: () => { state.foreground = "com.android.launcher"; state.screen = "home"; bump(); return true; },
  openApp: (name) => { state.opened.push(name); if (name === "Settings") { state.foreground = "com.settings"; state.screen = "settings"; bump(); return { ok: true }; } return { ok: false, reason: "app_not_found" }; },
  findTargets: (q) => targetsFor(q),
  tap: async (x, y) => { state.taps.push([x, y]); if (state.tapReacts) bump(); return { ok: true }; },
  longPress: async () => ({ ok: true }),
  tapText: async () => { state.nodeClicks++; bump(); return { ok: true }; },
  scroll: async () => { if (state.scrollPos < state.endAt) { state.scrollPos++; bump(); } return { ok: true }; },
  typeText: async () => ({ ok: true }),
  globalAction: async () => ({ ok: true }),
};
