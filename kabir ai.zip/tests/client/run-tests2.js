const Module = require("module"); const path = require("path");
const phone = require("./mock-phone.js");
const store = new Map();
let fetchHandler = async () => ({});
const mocks = {
  "@/modules/kabir-screen-agent": phone,
  "react-native": { Alert: { alert() {} }, Platform: { OS: "android", Version: 34 }, PermissionsAndroid: {} },
  "@react-native-async-storage/async-storage": { __esModule: true, default: { getItem: async (k) => store.get(k) ?? null, setItem: async (k, v) => { store.set(k, v); } } },
  "@workspace/api-client-react": { customFetch: (...a) => fetchHandler(...a) },
};
const orig = Module._load;
Module._load = function (req, ...r) {
  if (mocks[req]) return mocks[req];
  if (req.startsWith("@/")) return orig.call(this, path.resolve("dist", req.slice(2)), ...r);
  return orig.call(this, req, ...r);
};
const steps = require("./dist/lib/screen-commands/steps.js");
const grid = require("./dist/lib/screen-commands/grid.js");
const { runSteps } = require("./dist/lib/screen-commands/executor.js");
const yt = require("./dist/lib/workflows/youtube.js");
const recipe = require("./dist/lib/learning/recipe.js");
const { demoToRecipe } = require("./dist/lib/learning/demo-to-steps.js");
const { runRecipe, updateStatsAfterRun } = require("./dist/lib/learning/run-recipe.js");
const rstore = require("./dist/lib/learning/recipe-store.js");
const learner = require("./dist/lib/learning/tutorial-learner.js");

let pass = 0, failc = 0;
const t = async (name, fn) => { try { await fn(); pass++; console.log("  ok  ", name); } catch (e) { failc++; console.log("  FAIL", name, "-", e.message); } };
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m || ""} expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); };
const ok = (c, m) => { if (!c) throw new Error(m || "assertion failed"); };
const throws = (fn, m) => { try { fn(); } catch { return; } throw new Error(m || "did not throw"); };
const reset = (o = {}) => Object.assign(phone.state, { seq: 0, screen: "kabir", foreground: "com.kabir", focused: true, api30: true, ytInstalled: true, ytBroken: false,
  query: "", taps: [], swipes: [], scrolls: 0, opened: [], tapReacts: true, shiftUntil: 0, playedTitle: null, backs: 0 }, o);
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  console.log("new step types: validation");
  await t("accepts tapAt/dragAt/pinch/pressEnter/boardMove/workflow", () => eq(steps.parseSteps([
    { type: "tapAt", x: 0.5, y: 0.4 }, { type: "dragAt", x1: 0.1, y1: 0.2, x2: 0.8, y2: 0.2 }, { type: "pinch", x: 0.5, y: 0.5, from: 0.5, to: 0.2 },
    { type: "pressEnter" }, { type: "boardMove", from: "e2", to: "e4" }, { type: "workflow", name: "youtube.searchPlay", query: "lofi" }]).length, 6));
  await t("rejects tapAt outside 0-1", () => throws(() => steps.parseSteps([{ type: "tapAt", x: 1.5, y: 0.2 }])));
  await t("rejects bad squares / same square", () => { throws(() => steps.parseSteps([{ type: "boardMove", from: "e9", to: "e4" }])); throws(() => steps.parseSteps([{ type: "boardMove", from: "e2", to: "e2" }])); });
  await t("rejects unknown workflow name", () => throws(() => steps.parseSteps([{ type: "workflow", name: "bank.transfer", query: "x" }])));
  await t("recipes may be longer than voice plans (40 vs 25)", () => { const s = Array(30).fill({ type: "wait", ms: 100 }); throws(() => steps.parseSteps(s)); eq(steps.parseSteps(s, 40).length, 30); });

  console.log("grid / board geometry");
  const bnodes = [{ bounds: { left: 0, top: 400, width: 1080, height: 1080 } }, { bounds: { left: 0, top: 0, width: 1080, height: 300 } }];
  await t("detects the square board", () => eq(grid.detectSquareBoard(bnodes, 1080), { left: 0, top: 400, size: 1080 }));
  await t("no board when nothing is square-and-wide", () => eq(grid.detectSquareBoard([bnodes[1]], 1080), null));
  await t("e2 / e4 centres (white at bottom)", () => { const b = { left: 0, top: 400, size: 1080 }; eq(grid.squareCenter(b, "e2"), { x: 607.5, y: 1277.5 }); eq(grid.squareCenter(b, "e4"), { x: 607.5, y: 1007.5 }); });
  await t("black at bottom mirrors both axes", () => eq(grid.squareCenter({ left: 0, top: 400, size: 1080 }, "e2", "black"), { x: 472.5, y: 602.5 }));
  await t("a1 is bottom-left, h8 top-right (white)", () => { const b = { left: 0, top: 0, size: 800 }; eq(grid.squareCenter(b, "a1"), { x: 50, y: 750 }); eq(grid.squareCenter(b, "h8"), { x: 750, y: 50 }); });

  console.log("YouTube workflow (fake YouTube app)");
  await t("happy path: opens, searches, skips the ad, plays the matching video", async () => {
    reset(); const r = await yt.youtubeSearchPlay("lofi hip hop beats");
    ok(r.ok, JSON.stringify(r)); eq(r.verified, true); eq(phone.state.screen, "player"); eq(phone.state.playedTitle, "lofi"); eq(phone.state.query, "lofi hip hop beats");
  });
  await t("does not tap while results are still shifting (lands on final position)", async () => {
    reset(); await yt.youtubeSearchPlay("lofi hip hop beats");
    const last = phone.state.taps[phone.state.taps.length - 1]; ok(last[1] >= 1230 && last[1] <= 1230 + 1, `tapped y=${last[1]} (settled centre is 1230)`);
  });
  await t("fallbacks: no focus + no Enter API -> taps field, types, taps suggestion", async () => {
    reset({ focused: false, api30: false }); const r = await yt.youtubeSearchPlay("lofi hip hop beats");
    ok(r.ok, JSON.stringify(r)); eq(phone.state.playedTitle, "lofi");
  });
  await t("YouTube not installed -> app_not_found", async () => { reset({ ytInstalled: false }); const r = await yt.youtubeSearchPlay("x y"); eq(r.ok, false); eq(r.detail, "app_not_found"); });
  await t("search UI missing -> search_not_found (after one back attempt)", async () => { reset({ ytBroken: true }); const r = await yt.youtubeSearchPlay("x y"); eq(r.ok, false); eq(r.detail, "search_not_found"); ok(phone.state.backs >= 1); });
  await t("no title match -> plays top non-ad result and says so", async () => {
    reset(); const r = await yt.youtubeSearchPlay("quantum chess openings"); ok(r.ok, JSON.stringify(r)); ok(/top result/.test(r.note), r.note); eq(phone.state.playedTitle, "lofi");
  });
  await t("pickBestResult ignores ads and filter chips", () => {
    const n = (d, top, h, c = true) => ({ text: "", description: d, clickable: c, enabled: true, bounds: { top, height: h, left: 0, width: 1080, centerX: 540, centerY: top + h / 2 } });
    const pick = yt.pickBestResult([n("All", 300, 100), n("Sponsored - lofi beats", 450, 500), n("lofi beats mix", 980, 500)], "lofi beats", 2400);
    eq(pick.node.description, "lofi beats mix"); eq(pick.matchedBy, "query");
  });

  console.log("executor: workflow + board moves");
  await t("workflow step runs through the executor", async () => {
    reset(); const r = await runSteps([{ type: "workflow", name: "youtube.searchPlay", query: "lofi hip hop beats" }]); eq(r.ok, true); eq(phone.state.playedTitle, "lofi");
  });
  await t("boardMove taps from-square then to-square at exact pixels", async () => {
    reset({ screen: "chess", foreground: "org.chess" }); const r = await runSteps([{ type: "boardMove", from: "e2", to: "e4" }]);
    eq(r.ok, true); eq(phone.state.taps, [[607.5, 1277.5], [607.5, 1007.5]]);
  });
  await t("boardMove respects black orientation", async () => {
    reset({ screen: "chess", foreground: "org.chess" }); await runSteps([{ type: "boardMove", from: "e2", to: "e4", orientation: "black" }]);
    eq(phone.state.taps[0], [472.5, 602.5]);
  });
  await t("boardMove retries as a drag when taps do nothing", async () => {
    reset({ screen: "chess", foreground: "org.chess", tapReacts: false }); const r = await runSteps([{ type: "boardMove", from: "g1", to: "f3" }]);
    eq(r.ok, true); eq(phone.state.swipes.length, 1);
  });
  await t("boardMove with no detectable board fails clearly", async () => { reset({ screen: "launcher" }); const r = await runSteps([{ type: "boardMove", from: "e2", to: "e4" }]); eq(r.reason, "board_not_found"); });
  await t("tapAt converts fractions to real pixels", async () => { reset({ screen: "yt_home", foreground: "x" }); await runSteps([{ type: "tapAt", x: 0.5, y: 0.25 }]); eq(phone.state.taps[0], [540, 600]); });

  console.log("learning by demonstration");
  const ev = (o) => ({ at: 0, package: "com.google.android.youtube", label: "", viewId: "", className: "", xFrac: -1, yFrac: -1, text: "", secret: false, dir: "", appLabel: "", ...o });
  const demo = [
    ev({ kind: "window", appLabel: "YouTube", at: 100 }),
    ev({ kind: "click", label: "Search", at: 500 }),
    ev({ kind: "text", viewId: "q", text: "l", at: 900 }), ev({ kind: "text", viewId: "q", text: "lo", at: 950 }), ev({ kind: "text", viewId: "q", text: "lofi", at: 1000 }),
    ev({ kind: "click", label: "", xFrac: 0.5004, yFrac: 0.4, at: 1500 }),
    ev({ kind: "scroll", dir: "down", at: 2000 }), ev({ kind: "scroll", dir: "down", at: 2100 }), ev({ kind: "scroll", dir: "down", at: 2250 }),
    ev({ kind: "scroll", dir: "up", at: 4000 }),
    ev({ kind: "text", viewId: "pw", text: "", secret: true, at: 4500 }),
    ev({ kind: "longClick", label: "", at: 4700 }),
    ev({ kind: "click", label: "Kabir own button", package: "com.kabir", at: 4800 }),
  ];
  const { recipe: learned, warnings } = demoToRecipe(demo, { name: "Lofi routine", ownPackage: "com.kabir" });
  await t("demonstration -> clean steps (typing merged, scroll bursts merged, own app ignored)", () => eq(learned.steps, [
    { type: "openApp", name: "YouTube" }, { type: "tapText", text: "Search" }, { type: "typeText", text: "{{text1}}" },
    { type: "tapAt", x: 0.5, y: 0.4 }, { type: "scroll", direction: "down" }, { type: "scroll", direction: "up" }]));
  await t("typed text becomes a parameter with the demo value as default", () => eq(learned.params, [{ name: "text1", example: "lofi" }]));
  await t("password typing is skipped and warned about", () => ok(warnings.some((w) => /password/i.test(w))));
  await t("position-only taps and unlabeled long-press are warned about", () => { ok(warnings.some((w) => /position/.test(w))); ok(warnings.some((w) => /long-press/.test(w))); });
  await t("a learned recipe starts as draft", () => eq([learned.status, learned.revision, learned.source], ["draft", 1, "demonstration"]));
  await t("applyParams: default, override, and brace-stripping of injected placeholders", () => {
    eq(recipe.applyParams(learned, {})[2].text, "lofi"); eq(recipe.applyParams(learned, { text1: "jazz" })[2].text, "jazz");
    eq(recipe.applyParams(learned, { text1: "a {{text1}} b" })[2].text, "a text1 b");
  });
  await t("assertRecipeSound rejects undeclared placeholders", () => throws(() => recipe.assertRecipeSound([{ type: "typeText", text: "{{nope}}" }], [])));

  console.log("recipe lifecycle (store, approval, self-assessment)");
  const mk = (stepsArr, o = {}) => ({ ...learned, id: "r1", params: [], steps: stepsArr, status: "draft", stats: { runs: 0, successes: 0, consecutiveFailures: 0 }, ...o });
  await t("draft recipe asks first; declining runs nothing", async () => {
    reset(); let asked = null; const r = mk([{ type: "tapAt", x: 0.5, y: 0.5 }]);
    const res = await runRecipe(r, {}, { confirm: async (q) => { asked = q; return false; } });
    eq(res.report.reason, "declined"); eq(phone.state.taps.length, 0); ok(/Tap the screen/.test(asked.message), "plain-language step list shown");
  });
  await t("approved draft runs and becomes verified; stats stored", async () => {
    reset(); await rstore.saveRecipe(mk([{ type: "wait", ms: 50 }]));
    const res = await runRecipe(mk([{ type: "wait", ms: 50 }]), {}, { confirm: async () => true });
    eq(res.report.ok, true); eq(res.recipe.status, "verified"); eq(res.recipe.stats.runs, 1);
    eq((await rstore.listRecipes())[0].status, "verified");
  });
  await t("verified recipes run without asking again", async () => {
    reset(); let asked = false; const res = await runRecipe(mk([{ type: "wait", ms: 50 }], { status: "verified" }), {}, { confirm: async () => { asked = true; return true; } });
    eq(res.report.ok, true); eq(asked, false);
  });
  await t("two real failures in a row -> needs_repair; one failure does not", async () => {
    reset({ screen: "yt_home", foreground: "yt" }); let r = mk([{ type: "tapText", text: "Nonexistent" }], { status: "verified" });
    let res = await runRecipe(r, {}, { confirm: async () => true }); eq(res.recipe.status, "verified"); eq(res.recipe.stats.consecutiveFailures, 1);
    res = await runRecipe(res.recipe, {}, { confirm: async () => true }); eq(res.recipe.status, "needs_repair"); ok(/repair|taught again/i.test(res.problem));
  });
  await t("cancel / decline do NOT count against a recipe", () => {
    const base = mk([{ type: "wait", ms: 50 }], { status: "verified" });
    for (const reason of ["cancelled", "declined", "blocked_app", "accessibility_off"]) {
      const u = updateStatsAfterRun(base, { ok: false, completed: 0, total: 1, reason, log: [] }); eq([u.stats.runs, u.stats.consecutiveFailures, u.status], [0, 0, "verified"], reason);
    }
  });
  await t("a success after failures resets the failure streak", () => {
    const failing = mk([], { status: "verified", stats: { runs: 3, successes: 2, consecutiveFailures: 1 } });
    const u = updateStatsAfterRun(failing, { ok: true, completed: 1, total: 1, log: [] }); eq(u.stats.consecutiveFailures, 0);
  });
  await t("malformed recipes in storage are dropped, not executed", async () => {
    store.set("@kabir/recipes/v1", JSON.stringify([mk([{ type: "wait", ms: 50 }]), { ...mk([]), id: "evil", steps: [{ type: "shell", cmd: "rm -rf /" }] }]));
    const all = await rstore.listRecipes(); eq(all.map((x) => x.id), ["r1"]);
  });

  console.log("tutorial learner + self-repair (mocked server)");
  const raw = (o = {}) => ({ name: "Trim clip", description: "d", app: "CapCut", params: [{ name: "clip", example: "intro" }],
    steps: [{ type: "openApp", name: "CapCut" }, { type: "tapText", text: "{{clip}}" }], assumptions: ["English UI"], warnings: ["timing is manual"], confidence: 0.5, ...o });
  await t("tutorial -> draft recipe with warnings (low confidence adds a guess warning)", async () => {
    fetchHandler = async () => raw(); const r = await learner.learnFromText({ text: "x".repeat(40), responseLanguage: "English" });
    eq([r.status, r.source, r.steps.length], ["draft", "tutorial", 2]); ok(r.warnings.some((w) => /guess/.test(w)) && r.warnings.some((w) => /Assumed/.test(w)));
  });
  await t("server output with a bad step is rejected client-side", async () => {
    fetchHandler = async () => raw({ steps: [{ type: "shell", cmd: "x" }] }); let threw = false;
    try { await learner.learnFromText({ text: "x".repeat(40), responseLanguage: "English" }); } catch { threw = true; } ok(threw);
  });
  await t("undeclared placeholder from server is rejected", async () => {
    fetchHandler = async () => raw({ steps: [{ type: "tapText", text: "{{ghost}}" }] }); let threw = false;
    try { await learner.learnFromText({ text: "x".repeat(40), responseLanguage: "English" }); } catch { threw = true; } ok(threw);
  });
  await t("repair keeps earlier steps, replaces from the failing one, returns a new draft revision", async () => {
    const base = mk([{ type: "openApp", name: "CapCut" }, { type: "tapText", text: "Old" }, { type: "tapText", text: "Export" }], { status: "needs_repair", revision: 2 });
    fetchHandler = async () => ({ steps: [{ type: "tapText", text: "New" }], note: "button renamed" });
    const p = await learner.proposeRepair(base, 1, "not_found", ["New"], "English");
    eq(p.recipe.steps.map((s) => s.text ?? s.name), ["CapCut", "New"]); eq([p.recipe.status, p.recipe.revision], ["draft", 3]);
  });
  await t("garbage repair output returns null (nothing changes)", async () => {
    fetchHandler = async () => ({ steps: "nope" }); eq(await learner.proposeRepair(mk([{ type: "wait", ms: 50 }]), 0, "x", [], "English"), null);
  });

  console.log(`\n${pass} passed, ${failc} failed`); process.exit(failc ? 1 : 0);
})();
