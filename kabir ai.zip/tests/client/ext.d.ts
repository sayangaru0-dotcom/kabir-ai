declare module "react-native" {
  export const Platform: { OS: string; Version: number | string };
  export const PermissionsAndroid: { request(p: string): Promise<string>; PERMISSIONS: { POST_NOTIFICATIONS: string } };
  export const AppRegistry: { registerComponent(name: string, provider: () => unknown): void };
  export const Alert: { alert(t: string, m?: string, b?: { text: string; style?: string; onPress?: () => void }[], o?: { cancelable?: boolean; onDismiss?: () => void }): void };
}
declare module "expo-modules-core" { export function requireOptionalNativeModule<T>(n: string): T | null; }
declare module "@workspace/api-client-react" { export function customFetch<T>(url: string, o?: any): Promise<T>; }
declare module "@react-native-async-storage/async-storage" { const S: { getItem(k: string): Promise<string | null>; setItem(k: string, v: string): Promise<void>; removeItem(k: string): Promise<void> }; export default S; }
declare module "react" {
  export function useState<T>(i: T | (() => T)): [T, (v: T | ((p: T) => T)) => void];
  export function useEffect(f: () => void | (() => void), d?: any[]): void;
  export function useRef<T>(i: T): { current: T };
  export function useMemo<T>(f: () => T, d: any[]): T;
  export function useCallback<T extends (...a: any[]) => any>(f: T, d: any[]): T;
}

declare const __DEV__: boolean;
