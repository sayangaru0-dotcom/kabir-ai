// A stateful fake phone with a fake YouTube app and a fake chessboard.
const SW = 1080, SH = 2400;
const state = {
  seq: 0, screen: "kabir", foreground: "com.kabir", focused: true, api30: true, ytInstalled: true, ytBroken: false,
  query: "", taps: [], swipes: [], scrolls: 0, opened: [], tapReacts: true, shiftUntil: 0, playedTitle: null,
  demonstrating: false, backs: 0,
};
const bump = (ms = 20) => setTimeout(() => { state.seq++; }, ms);
const box = (left, top, w, h) => ({ left, top, right: left + w, bottom: top + h, width: w, height: h, centerX: left + w / 2, centerY: top + h / 2 });
const node = (o) => ({ text: "", description: "", viewId: "", className: "android.view.View", package: "com.google.android.youtube",
  clickable: false, editable: false, scrollable: false, enabled: true, depth: 0, ...o });

function nodes() {
  const shift = Date.now() < state.shiftUntil ? 70 : 0;
  switch (state.screen) {
    case "yt_home":
      return state.ytBroken ? [node({ text: "Home" })] : [
        node({ description: "Search", viewId: "com.google.android.youtube:id/menu_item_view", clickable: true, bounds: box(900, 120, 140, 140),
          onTap: () => { state.screen = "yt_search"; } }),
        node({ description: "Subscriptions", clickable: true, bounds: box(300, 2200, 200, 120) }),
      ];
    case "yt_search": {
      const out = [node({ description: "Search YouTube", editable: true, clickable: true, bounds: box(100, 100, 800, 140), onTap: () => { state.focused = true; } })];
      if (state.query) out.push(node({ text: state.query, clickable: true, bounds: box(0, 400, 1080, 160), onTap: () => { state.screen = "yt_results"; state.shiftUntil = Date.now() + 350; } }));
      return out;
    }
    case "yt_results":
      return [
        node({ text: "All", clickable: true, bounds: box(20, 300, 160, 100) }),
        node({ description: "Sponsored - Buy cheap speakers now - 0:30 - play video", clickable: true, bounds: box(0, 450 + shift, 1080, 500) }),
        node({ description: "Lofi hip hop beats to relax - 3 hours - Chill Channel - 2M views - play video", clickable: true, bounds: box(0, 980 + shift, 1080, 500),
          onTap: () => { state.screen = "player"; state.playedTitle = "lofi"; } }),
        node({ description: "Random cooking show episode 4 - play video", clickable: true, bounds: box(0, 1510 + shift, 1080, 500),
          onTap: () => { state.screen = "player"; state.playedTitle = "cooking"; } }),
      ];
    case "player":
      return [node({ description: "Pause video", clickable: true, bounds: box(500, 600, 100, 100) })];
    case "chess":
      return [node({ className: "Board", clickable: true, package: "org.chess", bounds: box(0, 400, 1080, 1080) })];
    default:
      return [];
  }
}
const strip = ({ onTap, ...rest }) => rest;
const hit = (x, y) => nodes().filter((n) => n.clickable && n.bounds && x >= n.bounds.left && x < n.bounds.right && y >= n.bounds.top && y < n.bounds.bottom).pop();

module.exports = {
  isScreenAgentSupported: true, state, SW, SH,
  getStatus: () => ({ accessibilityEnabled: true, foregroundPackage: state.foreground, ownPackage: "com.kabir", screenWidth: SW, screenHeight: SH, demonstrating: state.demonstrating, demoEventCount: 0 }),
  getChangeSeq: () => state.seq,
  minimizeApp: () => { state.foreground = "com.android.launcher"; state.screen = "launcher"; bump(); return true; },
  openApp: (name) => {
    state.opened.push(name);
    if (name === "YouTube" && state.ytInstalled) { state.screen = "yt_home"; state.foreground = "com.google.android.youtube"; bump(); return { ok: true }; }
    return { ok: false, reason: "app_not_found" };
  },
  getScreenSnapshot: () => ({ nodes: nodes().filter((n) => n.bounds).map(strip), ocr: [], foregroundPackage: state.foreground, screenWidth: SW, screenHeight: SH, ocrAgeMs: null }),
  findTargets: (q) => nodes().filter((n) => n.bounds && `${n.text} ${n.description}`.toLowerCase().includes(q.toLowerCase()))
    .map((n) => ({ x: n.bounds.centerX, y: n.bounds.centerY, label: n.text || n.description, confidence: 0.9, source: "node", bounds: n.bounds })),
  tap: async (x, y) => { state.taps.push([x, y]); const n = hit(x, y); if (n && n.onTap) n.onTap(); if (state.tapReacts || (n && n.onTap)) bump(); return { ok: true }; },
  longPress: async () => ({ ok: true }),
  swipe: async (x1, y1, x2, y2) => { state.swipes.push([x1, y1, x2, y2]); bump(); return { ok: true }; },
  pinch: async () => ({ ok: true }),
  tapText: async () => { bump(); return { ok: true }; },
  scroll: async () => { state.scrolls++; bump(); return { ok: true }; },
  typeText: async (text) => {
    if (state.screen === "yt_search" && state.focused) { state.query = text; bump(); return { ok: true }; }
    return { ok: false, reason: "no_focused_input" };
  },
  pressEnter: () => {
    if (state.api30 && state.screen === "yt_search" && state.query) { state.screen = "yt_results"; state.shiftUntil = Date.now() + 350; bump(); return { ok: true }; }
    return { ok: false, reason: state.api30 ? "no_focused_input" : "unsupported_api" };
  },
  globalAction: async (name) => { if (name === "back") { state.backs++; state.screen = "yt_home"; bump(); } return { ok: true }; },
};
