const Module = require("module"); const path = require("path");
const mock = require("./mock-agent.js");
const orig = Module._resolveFilename;
Module._resolveFilename = function (req, ...r) {
  if (req === "@/modules/kabir-screen-agent") return path.resolve("mock-agent.js");
  if (req.startsWith("@/")) return orig.call(this, path.resolve("dist", req.slice(2)), ...r);
  return orig.call(this, req, ...r);
};
const steps = require("./dist/lib/screen-commands/steps.js");
const { runSteps } = require("./dist/lib/screen-commands/executor.js");
const { scrollUntilVisible } = require("./dist/lib/screen-commands/precise-touch.js");
let pass = 0, failc = 0;
const t = async (name, fn) => { try { await fn(); pass++; console.log("  ok  ", name); } catch (e) { failc++; console.log("  FAIL", name, "-", e.message); } };
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m||""} expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); };
const reset = (o={}) => Object.assign(mock.state, { seq:0, foreground:"com.kabir", screen:"kabir", scrollPos:0, taps:[], nodeClicks:0, jitterUntil:0, tapReacts:true, opened:[], accessibility:true }, o);

(async () => {
  console.log("validation");
  await t("accepts a valid plan", () => eq(steps.parseSteps([{type:"openApp",name:"Settings"},{type:"tapText",text:"Wi-Fi"}]).length, 2));
  await t("rejects unknown step type", () => { try { steps.parseSteps([{type:"shell",cmd:"rm -rf /"}]); throw new Error("accepted"); } catch(e){ if(e.message==="accepted") throw e; } });
  await t("rejects whole plan if one step is bad", () => { try { steps.parseSteps([{type:"tapText",text:"ok"},{type:"scroll",direction:"sideways"}]); throw new Error("accepted"); } catch(e){ if(e.message==="accepted") throw e; } });
  await t("rejects >25 steps and empty plans", () => { for (const p of [Array(26).fill({type:"wait",ms:100}), []]) { try { steps.parseSteps(p); throw new Error("accepted"); } catch(e){ if(e.message==="accepted") throw e; } } });
  await t("clamps numbers (wait 999999 -> 8000)", () => eq(steps.parseSteps([{type:"wait",ms:999999}])[0].ms, 8000));
  console.log("sensitive labels");
  for (const [l, want] of [["Delete all",true],["Pay now",true],["Allow",true],["Factory reset",true],["পেমেন্ট করুন",true],["भुगतान करें".replace("भु","भु"),true],["Wi-Fi",false],["Settings",false],["Send",false],["Information",false],["Bluetooth",false]])
    await t(`"${l}" -> ${want}`, () => eq(steps.isSensitiveLabel(l), want));

  console.log("executor");
  await t("full flow: minimize? no - openApp first, then tap Wi-Fi verified", async () => {
    reset(); const r = await runSteps(steps.parseSteps([{type:"openApp",name:"Settings"},{type:"tapText",text:"Wi-Fi"}]));
    eq(r.ok, true); eq(mock.state.opened, ["Settings"]); eq(mock.state.taps.length, 1); eq(r.log[1].verified, true);
  });
  await t("steps aside first when Kabir is foreground and plan starts with a tap", async () => {
    reset({ screen:"home" }); mock.state.foreground = "com.kabir";
    const r = await runSteps([{type:"tapText",text:"Settings"}]);
    eq(r.ok, true); eq(mock.state.foreground, "com.android.launcher");
  });
  await t("waits for a moving target to stabilise before tapping", async () => {
    reset({ foreground:"com.settings", screen:"settings" }); mock.state.jitterUntil = Date.now() + 350;
    const r = await runSteps([{type:"tapText",text:"Wi-Fi"}]);
    eq(r.ok, true); if (mock.state.taps[0][0] > 380 || mock.state.taps[0][0] < 300) throw new Error("bad x");
    if (Date.now() < mock.state.jitterUntil - 1) throw new Error("tapped while still moving");
  });
  await t("scrollUntilVisible finds Bluetooth after scrolling", async () => {
    reset({ foreground:"com.settings", screen:"settings" });
    const r = await scrollUntilVisible("Bluetooth", { maxScrolls: 6 }); eq(r.found, true); eq(r.scrolls, 3);
  });
  await t("scrollUntilVisible stops at end of list", async () => {
    reset({ foreground:"com.settings", screen:"settings" });
    const r = await scrollUntilVisible("Nonexistent", { maxScrolls: 10 }); eq(r.found, false); eq(r.reason, "end_of_content");
  });
  await t("unverified tap on a clickable node retries once via node action", async () => {
    reset({ foreground:"com.settings", screen:"settings", tapReacts:false });
    const r = await runSteps([{type:"tapText",text:"Wi-Fi"}]);
    eq(r.ok, true); eq(mock.state.nodeClicks, 1); eq(mock.state.taps.length, 1);
  });
  await t("sensitive tap WITHOUT confirm callback is refused", async () => {
    reset({ foreground:"com.settings", screen:"settings" });
    const r = await runSteps([{type:"tapText",text:"Delete"}]); eq(r.ok, false); eq(r.reason, "declined"); eq(mock.state.taps.length, 0);
  });
  await t("harmless planned text resolving to 'Delete all' still asks (guards resolved label)", async () => {
    reset({ foreground:"com.settings", screen:"settings" }); let asked = null;
    const r = await runSteps([{type:"tapText",text:"OK"}], { confirm: async (q) => { asked = q.message; return false; } });
    eq(r.reason, "declined"); if (!/Delete all/.test(asked)) throw new Error("did not mention resolved label"); eq(mock.state.taps.length, 0);
  });
  await t("sensitive tap proceeds when user confirms", async () => {
    reset({ foreground:"com.settings", screen:"settings" });
    const r = await runSteps([{type:"tapText",text:"Delete"}], { confirm: async () => true }); eq(r.ok, true); eq(mock.state.taps.length, 1);
  });
  await t("accessibility off -> clear failure, nothing executed", async () => {
    reset({ accessibility:false }); const r = await runSteps([{type:"tapText",text:"Wi-Fi"}]); eq(r.reason, "accessibility_off"); eq(mock.state.taps.length, 0);
  });
  await t("optional step that is not found is skipped", async () => {
    reset({ foreground:"com.settings", screen:"settings" });
    const r = await runSteps([{type:"tapText",text:"Dismiss",optional:true},{type:"tapText",text:"Wi-Fi"}]); eq(r.ok, true); eq(mock.state.taps.length, 1);
  });
  await t("abort signal cancels mid-run", async () => {
    reset({ foreground:"com.settings", screen:"settings" }); const c = new AbortController(); setTimeout(() => c.abort(), 100);
    const r = await runSteps([{type:"wait",ms:3000},{type:"tapText",text:"Wi-Fi"}], { signal: c.signal });
    eq(r.reason, "cancelled"); eq(mock.state.taps.length, 0);
  });
  console.log(`\n${pass} passed, ${failc} failed`); process.exit(failc ? 1 : 0);
})();
