export type ResponseLanguage = "Bengali" | "Hindi" | "English";
export type LearningEntry = { id: string; title: string; summary: string; actions: string[]; createdAt: string };
export function useKabir(): { responseLanguage: ResponseLanguage; learningEntries: LearningEntry[] } { throw new Error(); }
