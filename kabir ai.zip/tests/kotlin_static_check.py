#!/usr/bin/env python3
"""
Static guard for the native Kotlin module. It is NOT a compiler (none is available offline); it encodes, as checks, every class of
compile error that a real build has already reported or that I found by review, so they cannot silently come back.
Usage: python3 tests/kotlin_static_check.py        (also run by tests/run-all.sh)
"""
import glob, os, re, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
MOD = os.path.join(ROOT, "artifacts", "kabir-ai", "modules", "kabir-screen-agent", "android")
KT = os.path.join(MOD, "src", "main", "java", "expo", "modules", "kabirscreenagent")
passed = failed = 0
def check(name, ok, detail=""):
    global passed, failed
    if ok: passed += 1; print("  ok  ", name)
    else: failed += 1; print("  FAIL", name, "-", detail)

def strip(s):
    s = re.sub(r"/\*.*?\*/", "", s, flags=re.S); s = re.sub(r"//[^\n]*", "", s)
    return re.sub(r'"(?:\\.|[^"\\])*"', '""', s)
files = {os.path.basename(f): open(f).read() for f in sorted(glob.glob(os.path.join(KT, "*.kt")))}
code = {n: strip(t) for n, t in files.items()}
check("the nine expected Kotlin files exist", len(files) == 9 and "KabirScreenAgentModule.kt" in files, str(list(files)))

print("syntax shape")
for n, t in code.items():
    check(f"balanced braces/parentheses/brackets: {n}", t.count("{") == t.count("}") and t.count("(") == t.count(")") and t.count("[") == t.count("]"))

print("errors reported by the first real build (regression guards)")
svc = code["ScreenCaptureService.kt"]
m = re.search(r"getMediaProjection\([^)]*\)([^\n]*\n[^\n]*)", svc)
check("MediaProjectionManager.getMediaProjection() result is null-checked (error: nullable receiver 'MediaProjection?')",
      bool(m) and "?:" in m.group(1), m.group(1) if m else "call not found")
mod = code["KabirScreenAgentModule.kt"]
check("every map literal in the bridge states its types: no bare mapOf( (error: new inference, Map vs List)",
      not re.search(r"(?<![A-Za-z<])mapOf\(", mod), str(re.findall(r".*(?<![A-Za-z<])mapOf\(.*", mod)[:2]))
check("no unconstrained emptyList()/emptyMap() in the bridge", not re.search(r"empty(List|Map)\(\)", mod), str(re.findall(r".*empty(?:List|Map)\(\).*", mod)))
snap = re.search(r'Function\("getScreenSnapshot"\).*?\n    }\n', files["KabirScreenAgentModule.kt"], re.S)
check("getScreenSnapshot builds typed locals, not an `if` inside the map literal",
      bool(snap) and "val result: Map<String, Any?>" in snap.group(0) and "val nodes: List<Map<String, Any?>>" in snap.group(0), "")

print("other version-sensitive constructs")
allcode = "\n".join(code.values())
check("no underscore catch parameter (older Kotlin rejects `catch (_: ...)`)", "catch (_" not in allcode)
check("nested callback class is fully qualified (AccessibilityService.GestureResultCallback)", "object : GestureResultCallback" not in allcode)
check("no member named `context` in the Expo module (can collide with a base-class member)", not re.search(r"\bval context\b|\bprivate val context\b", mod))
check("onStartCommand does not rely on `intent?.action` smart-casting `intent`", "if (intent == null) { shutdown(); return START_NOT_STICKY }" in files["ScreenCaptureService.kt"])
check("no lintOptions block in the module's Gradle file (removed in newer Android Gradle Plugin versions)",
      "lintOptions" not in open(os.path.join(MOD, "build.gradle")).read())

print("resources and manifest")
res = open(os.path.join(MOD, "src", "main", "res", "values", "strings.xml")).read()
used = set(re.findall(r"R\.string\.(\w+)", allcode))
check("every R.string.* used in Kotlin exists in strings.xml", all(f'name="{u}"' in res for u in used), str([u for u in used if f'name="{u}"' not in res]))
man = open(os.path.join(MOD, "src", "main", "AndroidManifest.xml")).read()
check("every service/receiver declared in the manifest has a Kotlin class", all(f"class {c}" in allcode for c in re.findall(r'android:name="\.(\w+)"', man)),
      str(re.findall(r'android:name="\.(\w+)"', man)))
xml = open(os.path.join(MOD, "src", "main", "res", "xml", "kabir_accessibility_config.xml")).read()
check("accessibility config references a string that exists", all(f'name="{n}"' in res for n in re.findall(r"@string/(\w+)", xml)))

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
