declare module "express" { export type IRouter = any; export function Router(): any; }
declare const Buffer: any;
