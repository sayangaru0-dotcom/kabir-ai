export function getOpenAIClient(): any { throw new Error("stub"); }
export function sendFailure(res: any, e: unknown, op: string): any { return res.status(502).json({ message: String(e) }); }
