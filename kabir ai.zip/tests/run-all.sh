#!/bin/bash
# Runs every automated check: TypeScript type-check + client tests (executor, workflows/learning, diagnostics) + server tests.
# Needs: node 20+ and a global `tsc` (npm i -g typescript). No Android SDK needed. Usage: bash tests/run-all.sh
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; T="$ROOT/tests"; W="$(mktemp -d)"; A="$ROOT/artifacts/kabir-ai"
echo "workspace: $W"

# ── client ──
C="$W/client"; mkdir -p "$C/src/hooks" "$C/src/modules" "$C/src/context" "$C/stubs"
# Only this package's own files: the stubs don't cover the rest of your app.
mkdir -p "$C/src/lib"
cp -r "$A/lib/screen-commands" "$A/lib/workflows" "$A/lib/learning" "$C/src/lib/"
cp "$A/hooks/useScreenAgent.ts" "$A/hooks/useVoiceCommands.ts" "$A/hooks/useWorkflows.ts" "$C/src/hooks/"
cp "$A/lib/error-monitor.ts" "$C/src/lib/error-monitor.ts"   # the project's real diagnostic system
cp -r "$A/modules/kabir-screen-agent" "$C/src/modules/"; rm -rf "$C/src/modules/kabir-screen-agent/android"
cp "$T/client/ext.d.ts" "$C/stubs/"; cp "$T/client/KabirContext.ts" "$C/src/context/"
cp "$T/client/tsconfig.json" "$T"/client/mock-*.js "$T"/client/run-tests*.js "$C/"
(cd "$C" && echo "== type-check ==" && tsc -p . && echo "ok" \
  && tsc -p . --noEmit false --outDir dist --rootDir src --module commonjs --moduleResolution node10 --ignoreDeprecations 6.0 \
  && echo "== client tests: core executor ==" && node run-tests.js | tail -1 \
  && echo "== client tests: workflows / learning ==" && node run-tests2.js | tail -1 \
  && echo "== client tests: diagnostics ==" && node run-tests3.js | tail -1)

# ── server ──
S="$W/server"; mkdir -p "$S/src"
cp "$ROOT"/artifacts/api-server/src/routes/{step-schema,command,learn-workflow}.ts "$S/src/"
cp "$T/server/kabir.stub.ts" "$S/src/kabir.ts"; cp "$T/server/stubs.d.ts" "$T/server/tsconfig.json" "$T/server/test.js" "$S/" 2>/dev/null || true
mv "$S/stubs.d.ts" "$S/src/stubs.d.ts"
(cd "$S" && echo "== server tests ==" && (tsc -p . >/dev/null 2>&1 || true) && node test.js | tail -1)
# ── CI workflow shell logic (needs python3 + PyYAML; skipped if PyYAML is missing) ──
if python3 -c "import yaml" 2>/dev/null; then
  echo "== GitHub Actions workflow tests ==" && python3 "$T/ci/test_workflow.py" | tail -1
else
  echo "== GitHub Actions workflow tests: skipped (pip install pyyaml to enable) =="
fi
# ── Native Kotlin static guards (no compiler offline; encodes the compile errors a real build already reported) ──
echo "== Kotlin static checks =="
KOUT="$(python3 "$T/kotlin_static_check.py")" && echo "$KOUT" | tail -1 || { echo "$KOUT"; exit 1; }
echo "ALL DONE"
